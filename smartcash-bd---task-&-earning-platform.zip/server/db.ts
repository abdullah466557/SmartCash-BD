import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

export interface User {
  id: string;
  telegramId: string;
  username: string;
  firstName: string;
  lastName: string;
  photoUrl: string;
  balancePoisha: number; // 100 poisha = 1 BDT
  totalEarnedPoisha: number;
  taskEarnedPoisha: number;
  adEarnedPoisha: number;
  spinEarnedPoisha: number;
  referralEarnedPoisha: number;
  pendingWithdrawPoisha: number;
  referralCode: string;
  referredByTelegramId: string | null;
  referralsCount: number;
  lastSpinDate: string | null; // YYYY-MM-DD in Asia/Dhaka
  isBlocked: boolean;
  createdAt: string;
  updatedAt: string;
  lastActiveAt: string;
  deviceMeta?: string;
}

export interface AdminUser {
  id: string;
  username: string;
  passwordHash: string;
  role: 'superadmin' | 'admin';
  createdAt: string;
  lastLoginAt: string;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  instructions: string;
  category: 'youtube' | 'telegram' | 'facebook' | 'survey' | 'visit' | 'app';
  targetUrl: string;
  rewardPoisha: number;
  durationSeconds: number;
  adCountdownSeconds: number;
  dailyLimit: number;
  completedCount: number;
  isActive: boolean;
  createdAt: string;
}

export interface TaskSession {
  sessionId: string;
  userId: string;
  taskId: string;
  startedAt: number;
  durationSeconds: number;
  adCountdownSeconds: number;
  countdownCompleted: boolean;
  expiresAt: number;
}

export interface SpinRecord {
  id: string;
  userId: string;
  telegramId: string;
  rewardPoisha: number;
  rewardLabel: string;
  dateDhaka: string;
  createdAt: string;
}

export interface AdRewardRecord {
  id: string;
  userId: string;
  telegramId: string;
  placementId: string;
  provider: 'Adsterra' | 'Monetag';
  rewardPoisha: number;
  createdAt: string;
}

export interface WithdrawalRequest {
  id: string;
  userId: string;
  telegramId: string;
  userName: string;
  method: 'bKash' | 'Nagad';
  accountType: 'Personal' | 'Merchant';
  accountNumber: string;
  amountPoisha: number;
  feePoisha: number;
  netAmountPoisha: number;
  status: 'Pending' | 'Approved' | 'Rejected' | 'Paid';
  rejectionReason?: string;
  payoutReference?: string;
  adminNote?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Transaction {
  id: string;
  userId: string;
  telegramId: string;
  type: 'task' | 'spin' | 'video_ad' | 'referral_bonus' | 'withdrawal_request' | 'withdrawal_refund' | 'admin_adjustment';
  amountPoisha: number;
  balanceAfterPoisha: number;
  description: string;
  referenceId?: string;
  createdAt: string;
}

export interface Referral {
  id: string;
  referrerTelegramId: string;
  referredTelegramId: string;
  referredName: string;
  referralCode: string;
  status: 'active' | 'completed';
  rewardPoisha: number;
  createdAt: string;
}

export interface AdminAuditLog {
  id: string;
  adminUsername: string;
  action: string;
  targetId?: string;
  details: string;
  ip?: string;
  createdAt: string;
}

export interface VideoAd {
  id: string;
  title: string;
  description?: string;
  rewardPoisha: number; // e.g. 100 = 1.00 BDT
  durationSeconds: number; // e.g. 15s
  videoUrl?: string;
  dailyLimit: number;
  viewsCount: number;
  isActive: boolean;
  createdAt: string;
}

export interface AppSettings {
  appName: string;
  telegramBotUsername: string;
  supportTelegram: string;
  whatsappSupport: string; // WhatsApp Support Link/Number
  imoSupport: string; // IMO Support Link/Number
  telegramChannel: string; // Official Telegram Channel
  minWithdrawalPoisha: number; // e.g. 5000 = 50 BDT
  withdrawalFeePercent: number; // e.g. 2%
  referralRewardPoisha: number; // e.g. 1000 = 10 BDT
  referralCommissionPercent: number; // e.g. 5%
  dailyAdLimit: number;
  adRewardPoisha: number; // e.g. 100 = 1 BDT
  adCooldownSeconds: number; // e.g. 45s
  adCountdownDuration: number; // 10s mandatory ad countdown
  adsEnabled: boolean;
  announcementText: string;
  maintenanceMode: boolean;
}

export interface SpinOption {
  id: number;
  label: string;
  rewardPoisha: number;
  color: string;
  probabilityWeight: number; // relative weight for RNG
}

export interface DatabaseSchema {
  users: Record<string, User>; // key: telegramId
  adminUsers: Record<string, AdminUser>;
  tasks: Record<string, Task>;
  videoAds: Record<string, VideoAd>;
  taskSessions: Record<string, TaskSession>;
  appSettings: AppSettings;
  spinOptions: SpinOption[];
  referrals: Referral[];
  spinRecords: SpinRecord[];
  adRewardRecords: AdRewardRecord[];
  withdrawalRequests: WithdrawalRequest[];
  transactions: Transaction[];
  telegramUpdates: Record<string, { updateId: number; processedAt: string; command: string }>;
  adminAuditLogs: AdminAuditLog[];
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'smartcash_db.json');
const BACKUP_DIR = path.join(DATA_DIR, 'backups');

// Password hashing helper using SHA-256 with salt
export function hashPassword(password: string): string {
  const salt = 'smartcash_bd_secure_salt_2026';
  return crypto.createHash('sha256').update(password + salt).digest('hex');
}

// Bangladesh time calculation (UTC+6)
export function getDhakaDateString(date = new Date()): string {
  const utcTime = date.getTime() + date.getTimezoneOffset() * 60000;
  const dhakaTime = new Date(utcTime + 6 * 3600000);
  return dhakaTime.toISOString().split('T')[0];
}

const DEFAULT_SPIN_OPTIONS: SpinOption[] = [
  { id: 1, label: '৳ 0.50', rewardPoisha: 50, color: '#10B981', probabilityWeight: 30 },
  { id: 2, label: '৳ 1.00', rewardPoisha: 100, color: '#059669', probabilityWeight: 25 },
  { id: 3, label: '৳ 2.00', rewardPoisha: 200, color: '#047857', probabilityWeight: 18 },
  { id: 4, label: '৳ 5.00', rewardPoisha: 500, color: '#3B82F6', probabilityWeight: 10 },
  { id: 5, label: '৳ 0.00', rewardPoisha: 0, color: '#64748B', probabilityWeight: 8 },
  { id: 6, label: '৳ 10.00', rewardPoisha: 1000, color: '#F59E0B', probabilityWeight: 5 },
  { id: 7, label: '৳ 15.00', rewardPoisha: 1500, color: '#8B5CF6', probabilityWeight: 3 },
  { id: 8, label: '৳ 3.00', rewardPoisha: 300, color: '#EC4899', probabilityWeight: 15 },
];

const DEFAULT_TASKS: Task[] = [
  {
    id: 'task_yt_sub',
    title: 'Subscribe SmartCash BD Official YouTube',
    description: 'Subscribe to our official channel and ring the bell notification icon to stay updated with payment proofs.',
    instructions: '1. Click Start Task. 2. Watch the sponsor ad for 10 seconds. 3. Visit the channel and subscribe. 4. Return to claim your reward.',
    category: 'youtube',
    targetUrl: 'https://youtube.com/@smartcashbd_official',
    rewardPoisha: 350, // 3.50 BDT
    durationSeconds: 20,
    adCountdownSeconds: 10,
    dailyLimit: 1,
    completedCount: 248,
    isActive: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'task_tg_channel',
    title: 'Join SmartCash BD Official Telegram Channel',
    description: 'Join our channel for daily promo codes, bonus drops, and instant payment receipts.',
    instructions: '1. Watch the 10-second sponsor ad. 2. Click join channel on Telegram. 3. Return to claim your BDT reward.',
    category: 'telegram',
    targetUrl: 'https://t.me/smartcashbd_channel',
    rewardPoisha: 500, // 5.00 BDT
    durationSeconds: 15,
    adCountdownSeconds: 10,
    dailyLimit: 1,
    completedCount: 890,
    isActive: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'task_fb_page',
    title: 'Follow SmartCash BD Facebook Page',
    description: 'Like and follow our official Facebook page to participate in weekly giveaways.',
    instructions: '1. Watch sponsor ad. 2. Follow page. 3. Claim your reward once countdown finishes.',
    category: 'facebook',
    targetUrl: 'https://facebook.com/smartcashbd',
    rewardPoisha: 250, // 2.50 BDT
    durationSeconds: 15,
    adCountdownSeconds: 10,
    dailyLimit: 1,
    completedCount: 432,
    isActive: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'task_visit_blog',
    title: 'Read Daily Financial News Article',
    description: 'Visit our sponsored partner article and scroll to the bottom for at least 30 seconds.',
    instructions: '1. Watch 10s ad. 2. Stay on page for 30s timer. 3. Claim your reward.',
    category: 'visit',
    targetUrl: 'https://smartcashbd.example/news/bd-economy-2026',
    rewardPoisha: 200, // 2.00 BDT
    durationSeconds: 30,
    adCountdownSeconds: 10,
    dailyLimit: 3,
    completedCount: 651,
    isActive: true,
    createdAt: new Date().toISOString(),
  },
];

const DEFAULT_VIDEO_ADS: VideoAd[] = [
  {
    id: 'vad_1',
    title: 'Sponsor Video Ad #1 - E-Commerce Shopping Bonus',
    description: 'Watch the 15-second sponsor video to claim your BDT reward',
    rewardPoisha: 100, // 1.00 BDT
    durationSeconds: 15,
    videoUrl: 'https://smartcashbd.example/video1',
    dailyLimit: 10,
    viewsCount: 142,
    isActive: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'vad_2',
    title: 'Sponsor Video Ad #2 - Instant Mobile Recharge Cashback',
    description: 'Watch 20-second promotion video for quick BDT cash',
    rewardPoisha: 150, // 1.50 BDT
    durationSeconds: 20,
    videoUrl: 'https://smartcashbd.example/video2',
    dailyLimit: 8,
    viewsCount: 289,
    isActive: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'vad_3',
    title: 'Sponsor Video Ad #3 - Smart Online Services Promo',
    description: 'Watch 15-second sponsor video to boost your daily earnings',
    rewardPoisha: 100, // 1.00 BDT
    durationSeconds: 15,
    videoUrl: 'https://smartcashbd.example/video3',
    dailyLimit: 10,
    viewsCount: 95,
    isActive: true,
    createdAt: new Date().toISOString(),
  },
];

class Database {
  private data: DatabaseSchema;
  private saveTimeout: NodeJS.Timeout | null = null;

  constructor() {
    this.ensureDirs();
    this.data = this.loadDatabase();
    this.seedAdminAndDefaults();
  }

  private ensureDirs() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(BACKUP_DIR)) {
      fs.mkdirSync(BACKUP_DIR, { recursive: true });
    }
  }

  private getInitialData(): DatabaseSchema {
    return {
      users: {},
      adminUsers: {},
      tasks: {},
      videoAds: {},
      taskSessions: {},
      appSettings: {
        appName: 'SmartCash BD',
        telegramBotUsername: '@smartcashbd_bot',
        supportTelegram: '@smartcashbd_support',
        whatsappSupport: 'https://wa.me/8801819234567',
        imoSupport: '+8801819234567',
        telegramChannel: 'https://t.me/smartcashbd_channel',
        minWithdrawalPoisha: 5000, // 50.00 BDT
        withdrawalFeePercent: 2, // 2%
        referralRewardPoisha: 1000, // 10.00 BDT
        referralCommissionPercent: 5, // 5%
        dailyAdLimit: 15,
        adRewardPoisha: 100, // 1.00 BDT per video ad
        adCooldownSeconds: 45,
        adCountdownDuration: 10,
        adsEnabled: true,
        announcementText: '🔥 Eid Bonus Active: 10 BDT instant referral bonus! Minimum withdrawal only 50 BDT via bKash & Nagad.',
        maintenanceMode: false,
      },
      spinOptions: DEFAULT_SPIN_OPTIONS,
      referrals: [],
      spinRecords: [],
      adRewardRecords: [],
      withdrawalRequests: [],
      transactions: [],
      telegramUpdates: {},
      adminAuditLogs: [],
    };
  }

  private loadDatabase(): DatabaseSchema {
    try {
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        return {
          ...this.getInitialData(),
          ...parsed,
          appSettings: { ...this.getInitialData().appSettings, ...(parsed.appSettings || {}) },
        };
      }
    } catch (err) {
      console.error('Failed to parse database file, restoring defaults:', err);
    }
    const initial = this.getInitialData();
    this.saveImmediate(initial);
    return initial;
  }

  private seedAdminAndDefaults() {
    // Seed requested admin credentials if no admin user exists
    const adminUsername = 'Abdullah@2008';
    const adminPasswordHash = hashPassword('352560');

    if (!this.data.adminUsers || Object.keys(this.data.adminUsers).length === 0) {
      this.data.adminUsers = {
        [adminUsername]: {
          id: 'admin_' + crypto.randomUUID().slice(0, 8),
          username: adminUsername,
          passwordHash: adminPasswordHash,
          role: 'superadmin',
          createdAt: new Date().toISOString(),
          lastLoginAt: new Date().toISOString(),
        },
      };
      this.save();
    }

    // Seed default tasks if empty
    if (Object.keys(this.data.tasks).length === 0) {
      for (const task of DEFAULT_TASKS) {
        this.data.tasks[task.id] = task;
      }
      this.save();
    }

    // Seed default video ads if empty
    if (!this.data.videoAds || Object.keys(this.data.videoAds).length === 0) {
      this.data.videoAds = {};
      for (const ad of DEFAULT_VIDEO_ADS) {
        this.data.videoAds[ad.id] = ad;
      }
      this.save();
    }

    // Ensure support channels exist in appSettings
    if (!this.data.appSettings.whatsappSupport) {
      this.data.appSettings.whatsappSupport = 'https://wa.me/8801819234567';
    }
    if (!this.data.appSettings.imoSupport) {
      this.data.appSettings.imoSupport = '+8801819234567';
    }
    if (!this.data.appSettings.telegramChannel) {
      this.data.appSettings.telegramChannel = 'https://t.me/smartcashbd_channel';
    }

    // Create a demo user starting with 0 BDT balance
    if (Object.keys(this.data.users).length === 0) {
      const demoTelegramId = '8801900123';
      this.data.users[demoTelegramId] = {
        id: 'user_demo_1',
        telegramId: demoTelegramId,
        username: 'tanvir_hasan',
        firstName: 'Tanvir',
        lastName: 'Hasan',
        photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
        balancePoisha: 0, // Starts at 0.00 BDT!
        totalEarnedPoisha: 0,
        taskEarnedPoisha: 0,
        adEarnedPoisha: 0,
        spinEarnedPoisha: 0,
        referralEarnedPoisha: 0,
        pendingWithdrawPoisha: 0,
        referralCode: 'SCBD8801',
        referredByTelegramId: null,
        referralsCount: 0,
        lastSpinDate: null,
        isBlocked: false,
        createdAt: new Date(Date.now() - 7 * 86400000).toISOString(),
        updatedAt: new Date().toISOString(),
        lastActiveAt: new Date().toISOString(),
        deviceMeta: 'Mozilla/5.0 (Linux; Android 14) Telegram/10.9',
      };

      // Add a couple of initial sample transactions and withdrawals for realistic preview
      this.data.transactions.push({
        id: 'txn_init_bonus',
        userId: 'user_demo_1',
        telegramId: demoTelegramId,
        type: 'referral_bonus',
        amountPoisha: 1000,
        balanceAfterPoisha: 1000,
        description: 'Welcome Sign-up Bonus',
        createdAt: new Date(Date.now() - 6 * 86400000).toISOString(),
      });

      this.data.transactions.push({
        id: 'txn_init_task',
        userId: 'user_demo_1',
        telegramId: demoTelegramId,
        type: 'task',
        amountPoisha: 500,
        balanceAfterPoisha: 1500,
        description: 'Completed Telegram Channel Task',
        createdAt: new Date(Date.now() - 5 * 86400000).toISOString(),
      });

      this.data.withdrawalRequests.push({
        id: 'wd_demo_paid_1',
        userId: 'user_demo_1',
        telegramId: demoTelegramId,
        userName: 'Tanvir Hasan',
        method: 'bKash',
        accountType: 'Personal',
        accountNumber: '01819234567',
        amountPoisha: 10000, // 100.00 BDT
        feePoisha: 200,
        netAmountPoisha: 9800,
        status: 'Paid',
        payoutReference: 'BKASH_TRX9938210',
        adminNote: 'Processed via bKash Personal',
        createdAt: new Date(Date.now() - 3 * 86400000).toISOString(),
        updatedAt: new Date(Date.now() - 3 * 86400000).toISOString(),
      });

      this.save();
    }
  }

  public save() {
    if (this.saveTimeout) {
      clearTimeout(this.saveTimeout);
    }
    this.saveTimeout = setTimeout(() => {
      this.saveImmediate(this.data);
    }, 150);
  }

  private saveImmediate(data: DatabaseSchema) {
    try {
      const tempPath = DB_FILE + '.tmp';
      fs.writeFileSync(tempPath, JSON.stringify(data, null, 2), 'utf-8');
      fs.renameSync(tempPath, DB_FILE);
    } catch (err) {
      console.error('Failed to write database file:', err);
    }
  }

  public getData(): DatabaseSchema {
    return this.data;
  }

  // Backup creation
  public createBackup(): string {
    const backupName = `backup_${Date.now()}_${getDhakaDateString()}.json`;
    const target = path.join(BACKUP_DIR, backupName);
    fs.writeFileSync(target, JSON.stringify(this.data, null, 2), 'utf-8');
    return backupName;
  }

  // Restore from backup
  public restoreFromData(restored: DatabaseSchema) {
    this.data = restored;
    this.saveImmediate(this.data);
  }

  // Audit Logger
  public logAudit(adminUsername: string, action: string, details: string, targetId?: string, ip?: string) {
    const log: AdminAuditLog = {
      id: 'log_' + crypto.randomUUID().slice(0, 8),
      adminUsername,
      action,
      targetId,
      details,
      ip,
      createdAt: new Date().toISOString(),
    };
    this.data.adminAuditLogs.unshift(log);
    if (this.data.adminAuditLogs.length > 500) {
      this.data.adminAuditLogs.pop();
    }
    this.save();
  }
}

export const db = new Database();
