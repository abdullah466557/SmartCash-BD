import crypto from 'crypto';
import { db, User } from './db.js';

export interface TelegramUserPayload {
  id: number | string;
  first_name: string;
  last_name?: string;
  username?: string;
  language_code?: string;
  photo_url?: string;
}

export interface TelegramInitDataParsed {
  query_id?: string;
  user?: TelegramUserPayload;
  auth_date?: number;
  hash?: string;
  start_param?: string;
}

/**
 * Validates Telegram Mini App initData against bot token
 */
export function verifyTelegramInitData(initDataString: string, botToken: string): boolean {
  if (!initDataString || !botToken) return false;
  try {
    const urlParams = new URLSearchParams(initDataString);
    const hash = urlParams.get('hash');
    if (!hash) return false;

    urlParams.delete('hash');
    const paramsList: string[] = [];
    urlParams.forEach((val, key) => {
      paramsList.push(`${key}=${val}`);
    });
    paramsList.sort();
    const dataCheckString = paramsList.join('\n');

    const secretKey = crypto.createHmac('sha256', 'WebAppData').update(botToken).digest();
    const calculatedHash = crypto.createHmac('sha256', secretKey).update(dataCheckString).digest('hex');

    return calculatedHash === hash;
  } catch (err) {
    console.error('Error verifying Telegram initData:', err);
    return false;
  }
}

/**
 * Parse initData querystring safely
 */
export function parseInitData(initDataString: string): TelegramInitDataParsed | null {
  try {
    const params = new URLSearchParams(initDataString);
    const result: any = {};
    for (const [key, val] of params.entries()) {
      if (key === 'user') {
        try {
          result.user = JSON.parse(val);
        } catch {
          result.user = val;
        }
      } else {
        result[key] = val;
      }
    }
    return result as TelegramInitDataParsed;
  } catch (err) {
    return null;
  }
}

/**
 * Generate a unique 8-char referral code
 */
export function generateReferralCode(telegramId: string): string {
  const hash = crypto.createHash('md5').update(telegramId + 'smartcash_salt').digest('hex');
  return 'SC' + hash.slice(0, 6).toUpperCase();
}

/**
 * Automatically creates or retrieves a user from Telegram identity
 * NO registration form, NO password, NO email.
 */
export function getOrCreateTelegramUser(
  telegramUser: TelegramUserPayload,
  referralCodeParam?: string,
  deviceMeta?: string
): { user: User; isNew: boolean } {
  const telegramIdStr = String(telegramUser.id);
  const data = db.getData();

  if (data.users[telegramIdStr]) {
    // Existing user - update activity and profile info if changed
    const user = data.users[telegramIdStr];
    user.lastActiveAt = new Date().toISOString();
    if (telegramUser.first_name) user.firstName = telegramUser.first_name;
    if (telegramUser.last_name !== undefined) user.lastName = telegramUser.last_name;
    if (telegramUser.username !== undefined) user.username = telegramUser.username;
    if (telegramUser.photo_url) user.photoUrl = telegramUser.photo_url;
    if (deviceMeta) user.deviceMeta = deviceMeta;
    db.save();
    return { user, isNew: false };
  }

  // Brand new account creation
  const referralCode = generateReferralCode(telegramIdStr);
  let referredByTelegramId: string | null = null;

  // Check referral code
  if (referralCodeParam) {
    const cleanRefCode = referralCodeParam.trim().toUpperCase();
    for (const existingUser of Object.values(data.users)) {
      if (existingUser.referralCode === cleanRefCode && existingUser.telegramId !== telegramIdStr) {
        referredByTelegramId = existingUser.telegramId;
        break;
      }
    }
  }

  const initialBonusPoisha = 0; // Starts with 0 BDT balance
  const newUser: User = {
    id: 'usr_' + crypto.randomUUID().slice(0, 8),
    telegramId: telegramIdStr,
    username: telegramUser.username || `user_${telegramIdStr.slice(-4)}`,
    firstName: telegramUser.first_name || 'SmartCash',
    lastName: telegramUser.last_name || 'User',
    photoUrl: telegramUser.photo_url || '',
    balancePoisha: 0,
    totalEarnedPoisha: 0,
    taskEarnedPoisha: 0,
    adEarnedPoisha: 0,
    spinEarnedPoisha: 0,
    referralEarnedPoisha: 0,
    pendingWithdrawPoisha: 0,
    referralCode,
    referredByTelegramId,
    referralsCount: 0,
    lastSpinDate: null,
    isBlocked: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    lastActiveAt: new Date().toISOString(),
    deviceMeta: deviceMeta || 'Telegram Client',
  };

  data.users[telegramIdStr] = newUser;

  // Credit Referrer if valid referral
  if (referredByTelegramId && data.users[referredByTelegramId]) {
    const referrer = data.users[referredByTelegramId];
    const refRewardPoisha = data.appSettings.referralRewardPoisha || 1000; // 10.00 BDT

    referrer.balancePoisha += refRewardPoisha;
    referrer.totalEarnedPoisha += refRewardPoisha;
    referrer.referralEarnedPoisha += refRewardPoisha;
    referrer.referralsCount += 1;
    referrer.updatedAt = new Date().toISOString();

    // Record Referral in db
    data.referrals.unshift({
      id: 'ref_' + crypto.randomUUID().slice(0, 8),
      referrerTelegramId: referrer.telegramId,
      referredTelegramId: newUser.telegramId,
      referredName: `${newUser.firstName} ${newUser.lastName}`.trim(),
      referralCode: referrer.referralCode,
      status: 'completed',
      rewardPoisha: refRewardPoisha,
      createdAt: new Date().toISOString(),
    });

    // Record Transaction for referrer
    data.transactions.unshift({
      id: 'txn_' + crypto.randomUUID().slice(0, 8),
      userId: referrer.id,
      telegramId: referrer.telegramId,
      type: 'referral_bonus',
      amountPoisha: refRewardPoisha,
      balanceAfterPoisha: referrer.balancePoisha,
      description: `Referral Bonus for inviting ${newUser.firstName} (৳${(refRewardPoisha / 100).toFixed(2)})`,
      referenceId: newUser.telegramId,
      createdAt: new Date().toISOString(),
    });
  }

  db.save();
  return { user: newUser, isNew: true };
}

/**
 * Handle incoming Telegram Bot webhook update
 */
export async function processTelegramWebhookUpdate(update: any, appUrl: string): Promise<{ success: boolean; replyText?: string; buttons?: any[] }> {
  if (!update || !update.update_id) {
    return { success: false };
  }

  const updateId = Number(update.update_id);
  const data = db.getData();

  // Deduplication check
  if (data.telegramUpdates[String(updateId)]) {
    return { success: true, replyText: 'Update already processed.' };
  }

  const message = update.message || update.edited_message;
  if (!message || !message.from) {
    data.telegramUpdates[String(updateId)] = {
      updateId,
      processedAt: new Date().toISOString(),
      command: 'non_message_update',
    };
    db.save();
    return { success: true };
  }

  const from = message.from;
  const text: string = (message.text || '').trim();
  const parts = text.split(' ');
  const command = parts[0].toLowerCase();
  const param = parts[1] || '';

  // Get or auto-create account
  const { user, isNew } = getOrCreateTelegramUser(from, param);

  let replyText = '';
  let inlineKeyboard: any[] = [];
  const cleanAppUrl = appUrl.replace(/\/$/, '');
  const miniAppUrl = `${cleanAppUrl}?tgWebAppStartParam=${user.referralCode}`;

  switch (command) {
    case '/start':
      if (isNew) {
        replyText = `🎉 *Welcome to SmartCash BD, ${user.firstName}!* 🇧🇩\n\n` +
          `Your account has been created automatically with your Telegram ID!\n` +
          `💰 *Initial Balance:* ৳0.00 BDT\n\n` +
          `Earn BDT by completing tasks, watching video ads, spinning the wheel, and inviting friends! Withdraw instantly via *bKash* or *Nagad*.\n\n` +
          `👥 *Your Referral Code:* \`${user.referralCode}\``;
      } else {
        replyText = `👋 *Welcome back, ${user.firstName}!* 🇧🇩\n\n` +
          `💰 *Available Balance:* ৳${(user.balancePoisha / 100).toFixed(2)} BDT\n` +
          `👥 *Total Referrals:* ${user.referralsCount} users\n` +
          `🏆 *Lifetime Earnings:* ৳${(user.totalEarnedPoisha / 100).toFixed(2)} BDT\n\n` +
          `Click below to open the SmartCash BD Mini App and continue earning!`;
      }
      inlineKeyboard = [
        [{ text: '🚀 Open SmartCash BD App', web_app: { url: cleanAppUrl } }],
        [
          { text: '💰 My Balance', callback_data: 'cmd_balance' },
          { text: '👥 Invite & Earn', callback_data: 'cmd_refer' },
        ],
        [
          { text: '📋 View Tasks', callback_data: 'cmd_tasks' },
          { text: '💸 Withdraw BDT', callback_data: 'cmd_withdraw' },
        ],
      ];
      break;

    case '/balance':
      replyText = `💳 *SmartCash BD Wallet Summary*\n\n` +
        `👤 User: *${user.firstName}* (@${user.username})\n` +
        `💵 Available Balance: *৳${(user.balancePoisha / 100).toFixed(2)} BDT*\n` +
        `⏳ Pending Withdrawal: ৳${(user.pendingWithdrawPoisha / 100).toFixed(2)} BDT\n` +
        `🏆 Total Lifetime Earned: ৳${(user.totalEarnedPoisha / 100).toFixed(2)} BDT\n\n` +
        `Minimum withdrawal is ৳${(data.appSettings.minWithdrawalPoisha / 100).toFixed(2)} BDT.`;
      inlineKeyboard = [
        [{ text: '🚀 Open Wallet & Withdraw', web_app: { url: `${cleanAppUrl}#wallet` } }],
      ];
      break;

    case '/tasks':
      const activeTasks = Object.values(data.tasks).filter(t => t.isActive);
      replyText = `📋 *SmartCash BD Task Marketplace*\n\n` +
        `Currently available tasks: *${activeTasks.length}*\n\n` +
        activeTasks.slice(0, 3).map((t, idx) => `${idx + 1}. *${t.title}* — Reward: ৳${(t.rewardPoisha / 100).toFixed(2)}`).join('\n') +
        `\n\nOpen the app to start earning rewards now!`;
      inlineKeyboard = [
        [{ text: '🎯 Open Tasks in App', web_app: { url: `${cleanAppUrl}#tasks` } }],
      ];
      break;

    case '/refer':
      const refLink = `https://t.me/${data.appSettings.telegramBotUsername.replace('@', '')}?start=${user.referralCode}`;
      replyText = `👥 *SmartCash BD Referral Program*\n\n` +
        `Share your link with friends. When they start the bot, your account is credited *৳${(data.appSettings.referralRewardPoisha / 100).toFixed(2)} BDT* immediately!\n\n` +
        `🔗 *Your Unique Referral Link:*\n\`${refLink}\`\n\n` +
        `📊 *Your Referral Stats:*\n` +
        `• Friends Invited: ${user.referralsCount}\n` +
        `• Total Referral Income: ৳${(user.referralEarnedPoisha / 100).toFixed(2)} BDT`;
      inlineKeyboard = [
        [{ text: '📢 Share on Telegram', url: `https://t.me/share/url?url=${encodeURIComponent(refLink)}&text=${encodeURIComponent('Join SmartCash BD and earn free BDT daily via bKash/Nagad!')}` }],
        [{ text: '🚀 Open App', web_app: { url: cleanAppUrl } }],
      ];
      break;

    case '/withdraw':
      replyText = `💸 *SmartCash BD Withdrawal Center*\n\n` +
        `💵 Available Balance: *৳${(user.balancePoisha / 100).toFixed(2)} BDT*\n` +
        `📌 Minimum Withdrawal: *৳${(data.appSettings.minWithdrawalPoisha / 100).toFixed(2)} BDT*\n` +
        `⚡ Supported Methods: *bKash* and *Nagad*\n\n` +
        (user.balancePoisha >= data.appSettings.minWithdrawalPoisha
          ? `✅ You have enough balance to request a withdrawal!`
          : `⚠️ You need ৳${((data.appSettings.minWithdrawalPoisha - user.balancePoisha) / 100).toFixed(2)} more BDT to withdraw.`);
      inlineKeyboard = [
        [{ text: '💳 Request Withdrawal Now', web_app: { url: `${cleanAppUrl}#wallet` } }],
      ];
      break;

    case '/help':
    default:
      replyText = `ℹ️ *SmartCash BD Support & Commands*\n\n` +
        `Available Bot Commands:\n` +
        `• /start - Launch or view account status\n` +
        `• /balance - Check current BDT wallet balance\n` +
        `• /tasks - View and complete tasks\n` +
        `• /refer - Get personal referral link\n` +
        `• /withdraw - Request bKash or Nagad payout\n` +
        `• /help - Support guidelines\n\n` +
        `💬 Need direct support? Contact: ${data.appSettings.supportTelegram}`;
      inlineKeyboard = [
        [{ text: '🚀 Open SmartCash BD App', web_app: { url: cleanAppUrl } }],
        [{ text: '📞 Contact Support', url: `https://t.me/${data.appSettings.supportTelegram.replace('@', '')}` }],
      ];
      break;
  }

  // Mark update as processed
  data.telegramUpdates[String(updateId)] = {
    updateId,
    processedAt: new Date().toISOString(),
    command,
  };
  db.save();

  return {
    success: true,
    replyText,
    buttons: inlineKeyboard,
  };
}
