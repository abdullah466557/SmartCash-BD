import { Router, Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import { db, hashPassword, getDhakaDateString, Task, User } from './db.js';
import { getOrCreateTelegramUser, processTelegramWebhookUpdate, parseInitData, verifyTelegramInitData } from './telegram.js';

export const apiRouter = Router();

// In-memory admin sessions: token -> { username, role, expiresAt }
const adminSessions: Record<string, { username: string; role: string; expiresAt: number }> = {};

// Clean up expired sessions periodically
setInterval(() => {
  const now = Date.now();
  for (const token in adminSessions) {
    if (adminSessions[token].expiresAt < now) {
      delete adminSessions[token];
    }
  }
}, 60000);

// Admin auth middleware
export function requireAdminAuth(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized: Admin session required' });
  }

  const token = authHeader.split(' ')[1];
  const session = adminSessions[token];
  if (!session || session.expiresAt < Date.now()) {
    return res.status(401).json({ error: 'Unauthorized: Session expired or invalid' });
  }

  (req as any).adminUser = session;
  next();
}

// User auth middleware helper (reads x-telegram-id header)
export function getUserFromReq(req: Request): User | null {
  const telegramId = req.headers['x-telegram-id'] as string;
  if (!telegramId) return null;
  const data = db.getData();
  const user = data.users[telegramId];
  if (user && !user.isBlocked) {
    return user;
  }
  return null;
}

/* ==========================================================================
   1. TELEGRAM AUTHENTICATION & BOT WEBHOOK
   ========================================================================== */

/**
 * Auto Telegram Auth or 1-Click Registration (NO FORM REQUIRED)
 */
apiRouter.post('/telegram/auth-or-register', (req: Request, res: Response) => {
  try {
    const { initData, mockUser, referralCode } = req.body;
    let telegramUser: any = null;
    let refParam = referralCode;

    // Check if real initData from Telegram Mini App is provided
    if (initData) {
      const parsed = parseInitData(initData);
      if (parsed?.user) {
        telegramUser = parsed.user;
        if (parsed.start_param && !refParam) {
          refParam = parsed.start_param;
        }
      }
    }

    // Fallback to mock/test user (e.g. preview mode or direct web emulator)
    if (!telegramUser && mockUser) {
      telegramUser = mockUser;
    }

    if (!telegramUser || !telegramUser.id) {
      return res.status(400).json({ error: 'Invalid Telegram identity payload' });
    }

    const deviceMeta = req.headers['user-agent'] || 'Telegram WebApp';
    const { user, isNew } = getOrCreateTelegramUser(telegramUser, refParam, deviceMeta);

    if (user.isBlocked) {
      return res.status(403).json({ error: 'Account is blocked by administrator' });
    }

    return res.json({
      success: true,
      user,
      isNew,
      token: user.telegramId, // Simplified token for applet environment
    });
  } catch (err: any) {
    console.error('Auth error:', err);
    return res.status(500).json({ error: 'Failed to process Telegram authentication' });
  }
});

/**
 * Official Telegram Webhook
 */
apiRouter.post('/telegram/webhook', async (req: Request, res: Response) => {
  try {
    const update = req.body;
    const appUrl = (process.env.APP_URL || `${req.protocol}://${req.get('host')}`);
    const result = await processTelegramWebhookUpdate(update, appUrl);
    return res.json(result);
  } catch (err) {
    console.error('Webhook processing error:', err);
    return res.status(500).json({ error: 'Webhook processing failed' });
  }
});

/**
 * Interactive Telegram Bot Command Simulator (for testing /start, /balance, etc. directly in UI)
 */
apiRouter.post('/telegram/simulate-command', async (req: Request, res: Response) => {
  try {
    const { command, telegramUser, startParam } = req.body;
    const appUrl = (process.env.APP_URL || `${req.protocol}://${req.get('host')}`);

    const simulatedUpdate = {
      update_id: Math.floor(Date.now() / 1000) + Math.floor(Math.random() * 10000),
      message: {
        message_id: Math.floor(Math.random() * 9000) + 1000,
        from: {
          id: telegramUser.id,
          first_name: telegramUser.first_name,
          last_name: telegramUser.last_name || '',
          username: telegramUser.username || '',
        },
        chat: {
          id: telegramUser.id,
          type: 'private',
        },
        date: Math.floor(Date.now() / 1000),
        text: startParam ? `${command} ${startParam}` : command,
      },
    };

    const result = await processTelegramWebhookUpdate(simulatedUpdate, appUrl);
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Simulation failed' });
  }
});

/* ==========================================================================
   2. PUBLIC USER & SYSTEM ENDPOINTS
   ========================================================================== */

/**
 * Get current user profile and live balance
 */
apiRouter.get('/user/me', (req: Request, res: Response) => {
  const user = getUserFromReq(req);
  if (!user) {
    return res.status(401).json({ error: 'User not found or blocked' });
  }
  return res.json({ success: true, user });
});

/**
 * Get user transaction history
 */
apiRouter.get('/user/transactions', (req: Request, res: Response) => {
  const user = getUserFromReq(req);
  if (!user) return res.status(401).json({ error: 'User not found' });

  const data = db.getData();
  const txns = data.transactions
    .filter(t => t.telegramId === user.telegramId)
    .slice(0, 50);

  return res.json({ success: true, transactions: txns });
});

/**
 * Get general app settings
 */
apiRouter.get('/settings', (_req: Request, res: Response) => {
  const data = db.getData();
  const { appSettings } = data;
  return res.json({
    success: true,
    settings: {
      appName: appSettings.appName,
      telegramBotUsername: appSettings.telegramBotUsername,
      supportTelegram: appSettings.supportTelegram,
      whatsappSupport: appSettings.whatsappSupport || 'https://wa.me/8801819234567',
      imoSupport: appSettings.imoSupport || '+8801819234567',
      telegramChannel: appSettings.telegramChannel || 'https://t.me/smartcashbd_channel',
      minWithdrawalPoisha: appSettings.minWithdrawalPoisha,
      withdrawalFeePercent: appSettings.withdrawalFeePercent,
      referralRewardPoisha: appSettings.referralRewardPoisha,
      referralCommissionPercent: appSettings.referralCommissionPercent,
      announcementText: appSettings.announcementText,
      maintenanceMode: appSettings.maintenanceMode,
      adsEnabled: appSettings.adsEnabled,
      dailyAdLimit: appSettings.dailyAdLimit,
      adRewardPoisha: appSettings.adRewardPoisha,
      adCountdownDuration: appSettings.adCountdownDuration,
    },
  });
});

/* ==========================================================================
   3. TASK MARKETPLACE WITH MANDATORY 10s AD COUNTDOWN
   ========================================================================== */

/**
 * List active tasks
 */
apiRouter.get('/tasks', (req: Request, res: Response) => {
  const data = db.getData();
  const tasks = Object.values(data.tasks).filter(t => t.isActive);
  return res.json({ success: true, tasks });
});

/**
 * Step 1: Start a task session (initializes server-side verification)
 */
apiRouter.post('/tasks/start', (req: Request, res: Response) => {
  const user = getUserFromReq(req);
  if (!user) return res.status(401).json({ error: 'User not authenticated' });

  const { taskId } = req.body;
  const data = db.getData();
  const task = data.tasks[taskId];
  if (!task || !task.isActive) {
    return res.status(404).json({ error: 'Task not found or inactive' });
  }

  const sessionId = 'tsess_' + crypto.randomUUID().slice(0, 10);
  const now = Date.now();

  const session = {
    sessionId,
    userId: user.id,
    taskId: task.id,
    startedAt: now,
    durationSeconds: task.durationSeconds,
    adCountdownSeconds: task.adCountdownSeconds || data.appSettings.adCountdownDuration || 10,
    countdownCompleted: false,
    expiresAt: now + (task.durationSeconds + 120) * 1000,
  };

  data.taskSessions[sessionId] = session;
  db.save();

  return res.json({
    success: true,
    sessionId,
    adCountdownSeconds: session.adCountdownSeconds,
    taskDurationSeconds: session.durationSeconds,
  });
});

/**
 * Step 2: Confirm mandatory 10-second sponsor ad countdown completed
 */
apiRouter.post('/tasks/ad-countdown-complete', (req: Request, res: Response) => {
  const user = getUserFromReq(req);
  if (!user) return res.status(401).json({ error: 'User not authenticated' });

  const { sessionId } = req.body;
  const data = db.getData();
  const session = data.taskSessions[sessionId];

  if (!session || session.userId !== user.id) {
    return res.status(400).json({ error: 'Invalid or expired task session' });
  }

  const elapsedSeconds = (Date.now() - session.startedAt) / 1000;
  // Anti-cheat: Check if user waited at least the countdown duration (with 1s network tolerance)
  if (elapsedSeconds < session.adCountdownSeconds - 1) {
    delete data.taskSessions[sessionId];
    db.save();
    return res.status(400).json({ error: 'Sponsor ad countdown skipped. Task cancelled.' });
  }

  session.countdownCompleted = true;
  db.save();

  return res.json({ success: true, message: 'Ad countdown verified. You may now perform the task.' });
});

/**
 * Step 3: Complete task & claim reward
 */
apiRouter.post('/tasks/claim', (req: Request, res: Response) => {
  const user = getUserFromReq(req);
  if (!user) return res.status(401).json({ error: 'User not authenticated' });

  const { sessionId } = req.body;
  const data = db.getData();
  const session = data.taskSessions[sessionId];

  if (!session || session.userId !== user.id) {
    return res.status(400).json({ error: 'Invalid task session' });
  }

  if (!session.countdownCompleted) {
    return res.status(400).json({ error: 'Mandatory ad countdown was not completed' });
  }

  const totalRequiredSeconds = session.adCountdownSeconds + session.durationSeconds;
  const totalElapsed = (Date.now() - session.startedAt) / 1000;

  if (totalElapsed < totalRequiredSeconds - 2) {
    return res.status(400).json({
      error: `Please finish the task instructions. Required time: ${totalRequiredSeconds}s`,
    });
  }

  const task = data.tasks[session.taskId];
  if (!task) {
    return res.status(404).json({ error: 'Task no longer exists' });
  }

  // Credit reward exactly once
  const rewardPoisha = task.rewardPoisha;
  user.balancePoisha += rewardPoisha;
  user.totalEarnedPoisha += rewardPoisha;
  user.taskEarnedPoisha += rewardPoisha;
  user.updatedAt = new Date().toISOString();

  task.completedCount += 1;

  // Add transaction
  data.transactions.unshift({
    id: 'txn_' + crypto.randomUUID().slice(0, 8),
    userId: user.id,
    telegramId: user.telegramId,
    type: 'task',
    amountPoisha: rewardPoisha,
    balanceAfterPoisha: user.balancePoisha,
    description: `Task Completed: ${task.title}`,
    referenceId: task.id,
    createdAt: new Date().toISOString(),
  });

  // Invalidate session
  delete data.taskSessions[sessionId];
  db.save();

  return res.json({
    success: true,
    rewardPoisha,
    rewardBdt: (rewardPoisha / 100).toFixed(2),
    newBalanceBdt: (user.balancePoisha / 100).toFixed(2),
  });
});

/* ==========================================================================
   4. DAILY SPIN WHEEL (ASIA/DHAKA TIMEZONE)
   ========================================================================== */

apiRouter.get('/spin/status', (req: Request, res: Response) => {
  const user = getUserFromReq(req);
  if (!user) return res.status(401).json({ error: 'User not authenticated' });

  const data = db.getData();
  const dhakaToday = getDhakaDateString();
  const hasSpunToday = user.lastSpinDate === dhakaToday;

  return res.json({
    success: true,
    hasSpunToday,
    dhakaToday,
    spinOptions: data.spinOptions,
  });
});

apiRouter.post('/spin/play', (req: Request, res: Response) => {
  const user = getUserFromReq(req);
  if (!user) return res.status(401).json({ error: 'User not authenticated' });

  const data = db.getData();
  const dhakaToday = getDhakaDateString();

  if (user.lastSpinDate === dhakaToday) {
    return res.status(400).json({ error: 'You have already completed your daily spin today. Resets at midnight (Dhaka time).' });
  }

  // Server-side weighted RNG calculation
  const options = data.spinOptions;
  const totalWeight = options.reduce((sum, opt) => sum + opt.probabilityWeight, 0);
  let randomVal = Math.random() * totalWeight;
  let selectedOption = options[0];

  for (const opt of options) {
    if (randomVal <= opt.probabilityWeight) {
      selectedOption = opt;
      break;
    }
    randomVal -= opt.probabilityWeight;
  }

  // Apply reward
  const rewardPoisha = selectedOption.rewardPoisha;
  user.balancePoisha += rewardPoisha;
  user.totalEarnedPoisha += rewardPoisha;
  user.spinEarnedPoisha += rewardPoisha;
  user.lastSpinDate = dhakaToday;
  user.updatedAt = new Date().toISOString();

  // Record spin
  data.spinRecords.unshift({
    id: 'spin_' + crypto.randomUUID().slice(0, 8),
    userId: user.id,
    telegramId: user.telegramId,
    rewardPoisha,
    rewardLabel: selectedOption.label,
    dateDhaka: dhakaToday,
    createdAt: new Date().toISOString(),
  });

  if (rewardPoisha > 0) {
    data.transactions.unshift({
      id: 'txn_' + crypto.randomUUID().slice(0, 8),
      userId: user.id,
      telegramId: user.telegramId,
      type: 'spin',
      amountPoisha: rewardPoisha,
      balanceAfterPoisha: user.balancePoisha,
      description: `Daily Spin Reward: ${selectedOption.label}`,
      createdAt: new Date().toISOString(),
    });
  }

  db.save();

  return res.json({
    success: true,
    optionId: selectedOption.id,
    label: selectedOption.label,
    rewardPoisha,
    rewardBdt: (rewardPoisha / 100).toFixed(2),
    newBalanceBdt: (user.balancePoisha / 100).toFixed(2),
  });
});

/* ==========================================================================
   5. VIDEO ADS (CLEAN & DIRECT SPONSOR VIDEO ADS)
   ========================================================================== */

apiRouter.get('/video-ads', (req: Request, res: Response) => {
  const user = getUserFromReq(req);
  const data = db.getData();
  const dhakaToday = getDhakaDateString();

  const userAdsToday = user
    ? data.adRewardRecords.filter(r => r.telegramId === user.telegramId && r.createdAt.startsWith(dhakaToday))
    : [];

  const lastAd = userAdsToday[0];
  let cooldownRemainingSeconds = 0;
  if (lastAd) {
    const elapsed = (Date.now() - new Date(lastAd.createdAt).getTime()) / 1000;
    const cooldown = data.appSettings.adCooldownSeconds || 45;
    if (elapsed < cooldown) {
      cooldownRemainingSeconds = Math.ceil(cooldown - elapsed);
    }
  }

  const ads = Object.values(data.videoAds || {}).filter(a => a.isActive);

  return res.json({
    success: true,
    ads,
    adsCompletedToday: userAdsToday.length,
    dailyLimit: data.appSettings.dailyAdLimit || 15,
    adRewardPoisha: data.appSettings.adRewardPoisha || 100,
    cooldownRemainingSeconds,
    adsEnabled: data.appSettings.adsEnabled !== false,
  });
});

apiRouter.post('/video-ads/claim', (req: Request, res: Response) => {
  const user = getUserFromReq(req);
  if (!user) return res.status(401).json({ error: 'User not authenticated' });

  const data = db.getData();
  if (data.appSettings.adsEnabled === false) {
    return res.status(400).json({ error: 'Video ads are currently disabled by administrator.' });
  }

  const { adId } = req.body;
  const ad = (data.videoAds || {})[adId];
  if (!ad || !ad.isActive) {
    return res.status(404).json({ error: 'Video ad not found or inactive' });
  }

  const dhakaToday = getDhakaDateString();
  const userAdsToday = data.adRewardRecords.filter(
    r => r.telegramId === user.telegramId && r.createdAt.startsWith(dhakaToday)
  );

  const limit = data.appSettings.dailyAdLimit || 15;
  if (userAdsToday.length >= limit) {
    return res.status(400).json({ error: `Daily video ad limit reached (${limit} ads/day).` });
  }

  const lastAd = userAdsToday[0];
  if (lastAd) {
    const elapsed = (Date.now() - new Date(lastAd.createdAt).getTime()) / 1000;
    const cooldown = data.appSettings.adCooldownSeconds || 45;
    if (elapsed < cooldown) {
      return res.status(400).json({
        error: `Please wait ${Math.ceil(cooldown - elapsed)}s before watching the next ad.`,
      });
    }
  }

  const rewardPoisha = ad.rewardPoisha || 100;
  user.balancePoisha += rewardPoisha;
  user.totalEarnedPoisha += rewardPoisha;
  user.adEarnedPoisha += rewardPoisha;
  user.updatedAt = new Date().toISOString();

  ad.viewsCount = (ad.viewsCount || 0) + 1;

  // Record ad view
  data.adRewardRecords.unshift({
    id: 'ad_' + crypto.randomUUID().slice(0, 8),
    userId: user.id,
    telegramId: user.telegramId,
    placementId: ad.id,
    provider: 'Adsterra',
    rewardPoisha,
    createdAt: new Date().toISOString(),
  });

  // Record transaction
  data.transactions.unshift({
    id: 'txn_' + crypto.randomUUID().slice(0, 8),
    userId: user.id,
    telegramId: user.telegramId,
    type: 'video_ad',
    amountPoisha: rewardPoisha,
    balanceAfterPoisha: user.balancePoisha,
    description: `Watched Video Ad: ${ad.title}`,
    createdAt: new Date().toISOString(),
  });

  db.save();

  return res.json({
    success: true,
    rewardPoisha,
    rewardBdt: (rewardPoisha / 100).toFixed(2),
    newBalanceBdt: (user.balancePoisha / 100).toFixed(2),
  });
});

// Backwards compatibility endpoint
apiRouter.get('/ads/status', (req: Request, res: Response) => {
  const user = getUserFromReq(req);
  const data = db.getData();
  const dhakaToday = getDhakaDateString();
  const userAdsToday = user ? data.adRewardRecords.filter(r => r.telegramId === user.telegramId && r.createdAt.startsWith(dhakaToday)) : [];
  return res.json({
    success: true,
    adsCompletedToday: userAdsToday.length,
    dailyLimit: data.appSettings.dailyAdLimit || 15,
    rewardPoisha: data.appSettings.adRewardPoisha || 100,
    cooldownRemainingSeconds: 0,
    adsEnabled: data.appSettings.adsEnabled !== false,
  });
});

/* ==========================================================================
   6. WALLET & BKASH / NAGAD WITHDRAWALS
   ========================================================================== */

/**
 * Request a withdrawal via bKash or Nagad
 */
apiRouter.post('/withdrawals/create', (req: Request, res: Response) => {
  const user = getUserFromReq(req);
  if (!user) return res.status(401).json({ error: 'User not authenticated' });

  const { method, accountType, accountNumber, amountBdt } = req.body;

  if (!method || !['bKash', 'Nagad', 'Rocket'].includes(method)) {
    return res.status(400).json({ error: 'Payment method must be bKash, Nagad, or Rocket' });
  }

  // Validate Bangladesh 11 or 12-digit mobile number (Rocket often uses 12 digits with check digit)
  const cleanNumber = String(accountNumber || '').replace(/\D/g, '');
  if (!/^01[3-9]\d{8,9}$/.test(cleanNumber)) {
    return res.status(400).json({ error: 'Please enter a valid 11 or 12-digit Bangladeshi mobile number (e.g. 01819234567)' });
  }

  const amountPoisha = Math.round(Number(amountBdt) * 100);
  const data = db.getData();
  const minPoisha = data.appSettings.minWithdrawalPoisha;

  if (isNaN(amountPoisha) || amountPoisha < minPoisha) {
    return res.status(400).json({
      error: `Minimum withdrawal amount is ৳${(minPoisha / 100).toFixed(2)} BDT`,
    });
  }

  if (amountPoisha > user.balancePoisha) {
    return res.status(400).json({
      error: `Insufficient balance. Available: ৳${(user.balancePoisha / 100).toFixed(2)} BDT`,
    });
  }

  const feePercent = data.appSettings.withdrawalFeePercent || 0;
  const feePoisha = Math.round((amountPoisha * feePercent) / 100);
  const netAmountPoisha = amountPoisha - feePoisha;

  // Deduct balance and put into pending
  user.balancePoisha -= amountPoisha;
  user.pendingWithdrawPoisha += amountPoisha;
  user.updatedAt = new Date().toISOString();

  const withdrawalId = 'wd_' + crypto.randomUUID().slice(0, 8);
  const withdrawal: any = {
    id: withdrawalId,
    userId: user.id,
    telegramId: user.telegramId,
    userName: `${user.firstName} ${user.lastName}`.trim(),
    method,
    accountType: accountType === 'Merchant' ? 'Merchant' : 'Personal',
    accountNumber: cleanNumber,
    amountPoisha,
    feePoisha,
    netAmountPoisha,
    status: 'Pending',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  data.withdrawalRequests.unshift(withdrawal);

  // Record Transaction
  data.transactions.unshift({
    id: 'txn_' + crypto.randomUUID().slice(0, 8),
    userId: user.id,
    telegramId: user.telegramId,
    type: 'withdrawal_request',
    amountPoisha: -amountPoisha,
    balanceAfterPoisha: user.balancePoisha,
    description: `Withdrawal Request via ${method} (${cleanNumber})`,
    referenceId: withdrawalId,
    createdAt: new Date().toISOString(),
  });

  db.save();

  return res.json({
    success: true,
    withdrawal,
    message: `Withdrawal request for ৳${(amountPoisha / 100).toFixed(2)} BDT submitted successfully. Our admin team reviews payouts within 1-24 hours.`,
  });
});

/**
 * Get user's personal withdrawal history
 */
apiRouter.get('/withdrawals/my', (req: Request, res: Response) => {
  const user = getUserFromReq(req);
  if (!user) return res.status(401).json({ error: 'User not authenticated' });

  const data = db.getData();
  const requests = data.withdrawalRequests.filter(w => w.telegramId === user.telegramId);

  return res.json({ success: true, withdrawals: requests });
});

/**
 * Get user's referral summary & invited list
 */
apiRouter.get('/referrals/my', (req: Request, res: Response) => {
  const user = getUserFromReq(req);
  if (!user) return res.status(401).json({ error: 'User not authenticated' });

  const data = db.getData();
  const userReferrals = data.referrals.filter(r => r.referrerTelegramId === user.telegramId);

  return res.json({
    success: true,
    referralCode: user.referralCode,
    referralsCount: user.referralsCount,
    referralEarnedPoisha: user.referralEarnedPoisha,
    botUsername: data.appSettings.telegramBotUsername,
    referrals: userReferrals,
  });
});

/* ==========================================================================
   7. SECURE ADMIN PANEL APIS
   ========================================================================== */

/**
 * Admin Login Endpoint
 * Requested default credentials: Username: Abdullah@2008 / Password: 352560
 */
apiRouter.post('/admin/login', (req: Request, res: Response) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required' });
  }

  const data = db.getData();
  const admin = data.adminUsers[username];
  const inputHash = hashPassword(password);

  if (!admin || admin.passwordHash !== inputHash) {
    return res.status(401).json({ error: 'Invalid admin credentials' });
  }

  // Create session token
  const token = 'adm_' + crypto.randomUUID().replace(/-/g, '');
  adminSessions[token] = {
    username: admin.username,
    role: admin.role,
    expiresAt: Date.now() + 24 * 3600000, // 24 hours
  };

  admin.lastLoginAt = new Date().toISOString();
  db.logAudit(admin.username, 'ADMIN_LOGIN', 'Logged into Admin Dashboard', undefined, req.ip);

  return res.json({
    success: true,
    token,
    admin: {
      username: admin.username,
      role: admin.role,
      lastLoginAt: admin.lastLoginAt,
    },
  });
});

/**
 * Verify admin session
 */
apiRouter.get('/admin/me', requireAdminAuth, (req: Request, res: Response) => {
  const session = (req as any).adminUser;
  return res.json({ success: true, admin: session });
});

/**
 * Admin Dashboard Statistics
 */
apiRouter.get('/admin/dashboard', requireAdminAuth, (_req: Request, res: Response) => {
  const data = db.getData();
  const users = Object.values(data.users);
  const now = Date.now();
  const dayAgo = now - 24 * 3600000;

  const totalUsers = users.length;
  const activeUsers24h = users.filter(u => new Date(u.lastActiveAt).getTime() > dayAgo).length;
  const linkedTelegramAccounts = users.filter(u => u.telegramId).length;

  let totalRewardsIssuedPoisha = 0;
  for (const t of data.transactions) {
    if (t.amountPoisha > 0) {
      totalRewardsIssuedPoisha += t.amountPoisha;
    }
  }

  const completedTasks = Object.values(data.tasks).reduce((sum, t) => sum + (t.completedCount || 0), 0);

  const pendingWithdrawals = data.withdrawalRequests.filter(w => w.status === 'Pending');
  const paidWithdrawals = data.withdrawalRequests.filter(w => w.status === 'Paid');

  const pendingWithdrawAmountPoisha = pendingWithdrawals.reduce((sum, w) => sum + w.amountPoisha, 0);
  const paidWithdrawAmountPoisha = paidWithdrawals.reduce((sum, w) => sum + w.amountPoisha, 0);

  return res.json({
    success: true,
    stats: {
      totalUsers,
      activeUsers24h,
      linkedTelegramAccounts,
      completedTasks,
      totalRewardsIssuedBdt: (totalRewardsIssuedPoisha / 100).toFixed(2),
      pendingWithdrawalsCount: pendingWithdrawals.length,
      pendingWithdrawAmountBdt: (pendingWithdrawAmountPoisha / 100).toFixed(2),
      paidWithdrawalsCount: paidWithdrawals.length,
      paidWithdrawAmountBdt: (paidWithdrawAmountPoisha / 100).toFixed(2),
      totalReferrals: data.referrals.length,
      totalSpins: data.spinRecords.length,
      totalAdsWatched: data.adRewardRecords.length,
    },
  });
});

/**
 * Admin: Get and search users
 */
apiRouter.get('/admin/users', requireAdminAuth, (req: Request, res: Response) => {
  const search = ((req.query.search as string) || '').toLowerCase().trim();
  const data = db.getData();
  let users = Object.values(data.users);

  if (search) {
    users = users.filter(u =>
      u.telegramId.toLowerCase().includes(search) ||
      u.username.toLowerCase().includes(search) ||
      u.firstName.toLowerCase().includes(search) ||
      u.referralCode.toLowerCase().includes(search)
    );
  }

  // Sort by recent activity
  users.sort((a, b) => new Date(b.lastActiveAt).getTime() - new Date(a.lastActiveAt).getTime());

  return res.json({ success: true, users: users.slice(0, 100) });
});

/**
 * Admin: Audited Manual Balance Adjustment
 */
apiRouter.post('/admin/users/adjust-balance', requireAdminAuth, (req: Request, res: Response) => {
  const { telegramId, amountBdt, reason, operation } = req.body;
  const adminSession = (req as any).adminUser;

  if (!telegramId || !amountBdt || !reason) {
    return res.status(400).json({ error: 'Telegram ID, Amount, and Reason are required' });
  }

  const data = db.getData();
  const user = data.users[telegramId];
  if (!user) return res.status(404).json({ error: 'User not found' });

  const poishaVal = Math.round(Math.abs(Number(amountBdt)) * 100);
  const isCredit = operation === 'credit';
  const delta = isCredit ? poishaVal : -poishaVal;

  if (!isCredit && user.balancePoisha < poishaVal) {
    return res.status(400).json({ error: 'Cannot debit more than available balance' });
  }

  user.balancePoisha += delta;
  if (isCredit) {
    user.totalEarnedPoisha += poishaVal;
  }
  user.updatedAt = new Date().toISOString();

  // Audit transaction
  data.transactions.unshift({
    id: 'txn_' + crypto.randomUUID().slice(0, 8),
    userId: user.id,
    telegramId: user.telegramId,
    type: 'admin_adjustment',
    amountPoisha: delta,
    balanceAfterPoisha: user.balancePoisha,
    description: `Admin Adjustment (${isCredit ? '+' : '-'}৳${amountBdt}): ${reason}`,
    referenceId: adminSession.username,
    createdAt: new Date().toISOString(),
  });

  // Log in admin audit logs
  db.logAudit(
    adminSession.username,
    'ADJUST_BALANCE',
    `Adjusted balance of ${user.firstName} (@${user.username || user.telegramId}) by ${isCredit ? '+' : '-'}৳${amountBdt}. Reason: ${reason}`,
    user.telegramId,
    req.ip
  );

  return res.json({
    success: true,
    user,
    message: `Balance adjusted successfully. New balance: ৳${(user.balancePoisha / 100).toFixed(2)} BDT`,
  });
});

/**
 * Admin: Block or Unblock user
 */
apiRouter.post('/admin/users/toggle-block', requireAdminAuth, (req: Request, res: Response) => {
  const { telegramId, reason } = req.body;
  const adminSession = (req as any).adminUser;
  const data = db.getData();
  const user = data.users[telegramId];

  if (!user) return res.status(404).json({ error: 'User not found' });

  user.isBlocked = !user.isBlocked;
  user.updatedAt = new Date().toISOString();

  db.logAudit(
    adminSession.username,
    user.isBlocked ? 'BLOCK_USER' : 'UNBLOCK_USER',
    `${user.isBlocked ? 'Blocked' : 'Unblocked'} user @${user.username} (${user.telegramId}). Note: ${reason || 'N/A'}`,
    user.telegramId,
    req.ip
  );

  return res.json({ success: true, isBlocked: user.isBlocked });
});

/**
 * Admin: Tasks CRUD
 */
apiRouter.get('/admin/tasks', requireAdminAuth, (_req: Request, res: Response) => {
  const data = db.getData();
  return res.json({ success: true, tasks: Object.values(data.tasks) });
});

apiRouter.post('/admin/tasks', requireAdminAuth, (req: Request, res: Response) => {
  const adminSession = (req as any).adminUser;
  const { title, description, instructions, category, targetUrl, rewardBdt, durationSeconds, adCountdownSeconds, dailyLimit } = req.body;

  if (!title || !targetUrl) {
    return res.status(400).json({ error: 'Title and target URL are required' });
  }

  const data = db.getData();
  const id = 'task_' + crypto.randomUUID().slice(0, 8);
  const task: Task = {
    id,
    title,
    description: description || '',
    instructions: instructions || 'Follow the link and return after completion.',
    category: category || 'youtube',
    targetUrl,
    rewardPoisha: Math.round(Number(rewardBdt || 1) * 100),
    durationSeconds: Number(durationSeconds || 15),
    adCountdownSeconds: Number(adCountdownSeconds || 10),
    dailyLimit: Number(dailyLimit || 1),
    completedCount: 0,
    isActive: true,
    createdAt: new Date().toISOString(),
  };

  data.tasks[id] = task;
  db.logAudit(adminSession.username, 'CREATE_TASK', `Created task "${task.title}" with reward ৳${rewardBdt}`, id);

  return res.json({ success: true, task });
});

apiRouter.put('/admin/tasks/:id', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const adminSession = (req as any).adminUser;
  const data = db.getData();
  const task = data.tasks[id];
  if (!task) return res.status(404).json({ error: 'Task not found' });

  const body = req.body;
  if (body.title !== undefined) task.title = body.title;
  if (body.description !== undefined) task.description = body.description;
  if (body.instructions !== undefined) task.instructions = body.instructions;
  if (body.targetUrl !== undefined) task.targetUrl = body.targetUrl;
  if (body.category !== undefined) task.category = body.category;
  if (body.rewardBdt !== undefined) task.rewardPoisha = Math.round(Number(body.rewardBdt) * 100);
  if (body.durationSeconds !== undefined) task.durationSeconds = Number(body.durationSeconds);
  if (body.adCountdownSeconds !== undefined) task.adCountdownSeconds = Number(body.adCountdownSeconds);
  if (body.dailyLimit !== undefined) task.dailyLimit = Number(body.dailyLimit);
  if (body.isActive !== undefined) task.isActive = Boolean(body.isActive);

  db.logAudit(adminSession.username, 'UPDATE_TASK', `Updated task "${task.title}"`, id);

  return res.json({ success: true, task });
});

apiRouter.delete('/admin/tasks/:id', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const adminSession = (req as any).adminUser;
  const data = db.getData();
  const task = data.tasks[id];
  if (!task) return res.status(404).json({ error: 'Task not found' });

  delete data.tasks[id];
  db.logAudit(adminSession.username, 'DELETE_TASK', `Deleted task "${task.title}"`, id);

  return res.json({ success: true, message: 'Task deleted' });
});

/**
 * Admin: Video Ads Management (Create unlimited ads, Edit, Toggle, Delete)
 */
apiRouter.get('/admin/video-ads', requireAdminAuth, (_req: Request, res: Response) => {
  const data = db.getData();
  return res.json({ success: true, ads: Object.values(data.videoAds || {}) });
});

apiRouter.post('/admin/video-ads', requireAdminAuth, (req: Request, res: Response) => {
  const adminSession = (req as any).adminUser;
  const { title, description, rewardBdt, durationSeconds, videoUrl, dailyLimit } = req.body;

  if (!title) {
    return res.status(400).json({ error: 'Ad title is required' });
  }

  const data = db.getData();
  if (!data.videoAds) data.videoAds = {};

  const id = 'vad_' + crypto.randomUUID().slice(0, 8);
  const newAd = {
    id,
    title,
    description: description || 'Watch video to earn reward',
    rewardPoisha: Math.round(Number(rewardBdt || 1) * 100),
    durationSeconds: Number(durationSeconds || 15),
    videoUrl: videoUrl || '',
    dailyLimit: Number(dailyLimit || 10),
    viewsCount: 0,
    isActive: true,
    createdAt: new Date().toISOString(),
  };

  data.videoAds[id] = newAd;
  db.logAudit(adminSession.username, 'CREATE_VIDEO_AD', `Created video ad "${newAd.title}" with reward ৳${rewardBdt}`, id);

  return res.json({ success: true, ad: newAd });
});

apiRouter.put('/admin/video-ads/:id', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const adminSession = (req as any).adminUser;
  const data = db.getData();
  const ad = (data.videoAds || {})[id];
  if (!ad) return res.status(404).json({ error: 'Video ad not found' });

  const body = req.body;
  if (body.title !== undefined) ad.title = body.title;
  if (body.description !== undefined) ad.description = body.description;
  if (body.rewardBdt !== undefined) ad.rewardPoisha = Math.round(Number(body.rewardBdt) * 100);
  if (body.durationSeconds !== undefined) ad.durationSeconds = Number(body.durationSeconds);
  if (body.videoUrl !== undefined) ad.videoUrl = body.videoUrl;
  if (body.dailyLimit !== undefined) ad.dailyLimit = Number(body.dailyLimit);
  if (body.isActive !== undefined) ad.isActive = Boolean(body.isActive);

  db.logAudit(adminSession.username, 'UPDATE_VIDEO_AD', `Updated video ad "${ad.title}"`, id);

  return res.json({ success: true, ad });
});

apiRouter.delete('/admin/video-ads/:id', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const adminSession = (req as any).adminUser;
  const data = db.getData();
  const ad = (data.videoAds || {})[id];
  if (!ad) return res.status(404).json({ error: 'Video ad not found' });

  delete data.videoAds[id];
  db.logAudit(adminSession.username, 'DELETE_VIDEO_AD', `Deleted video ad "${ad.title}"`, id);

  return res.json({ success: true, message: 'Video ad deleted successfully' });
});

/**
 * Admin: Withdrawal Requests Management
 */
apiRouter.get('/admin/withdrawals', requireAdminAuth, (_req: Request, res: Response) => {
  const data = db.getData();
  return res.json({ success: true, withdrawals: data.withdrawalRequests });
});

apiRouter.post('/admin/withdrawals/:id/action', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const { action, payoutReference, rejectionReason, adminNote } = req.body;
  const adminSession = (req as any).adminUser;
  const data = db.getData();

  const withdrawal = data.withdrawalRequests.find(w => w.id === id);
  if (!withdrawal) return res.status(404).json({ error: 'Withdrawal not found' });

  const user = data.users[withdrawal.telegramId];

  if (action === 'Approve') {
    withdrawal.status = 'Approved';
    if (adminNote) withdrawal.adminNote = adminNote;
    withdrawal.updatedAt = new Date().toISOString();
  } else if (action === 'Paid') {
    withdrawal.status = 'Paid';
    withdrawal.payoutReference = payoutReference || 'MANUAL_' + Date.now();
    if (adminNote) withdrawal.adminNote = adminNote;
    withdrawal.updatedAt = new Date().toISOString();

    // Deduct from pending
    if (user) {
      user.pendingWithdrawPoisha = Math.max(0, user.pendingWithdrawPoisha - withdrawal.amountPoisha);
      user.updatedAt = new Date().toISOString();
    }
  } else if (action === 'Reject') {
    withdrawal.status = 'Rejected';
    withdrawal.rejectionReason = rejectionReason || 'Information mismatch or fraud suspicion';
    withdrawal.updatedAt = new Date().toISOString();

    // Refund reserved balance
    if (user) {
      user.balancePoisha += withdrawal.amountPoisha;
      user.pendingWithdrawPoisha = Math.max(0, user.pendingWithdrawPoisha - withdrawal.amountPoisha);
      user.updatedAt = new Date().toISOString();

      data.transactions.unshift({
        id: 'txn_' + crypto.randomUUID().slice(0, 8),
        userId: user.id,
        telegramId: user.telegramId,
        type: 'withdrawal_refund',
        amountPoisha: withdrawal.amountPoisha,
        balanceAfterPoisha: user.balancePoisha,
        description: `Refund: Rejected Withdrawal #${withdrawal.id} (${withdrawal.rejectionReason})`,
        referenceId: withdrawal.id,
        createdAt: new Date().toISOString(),
      });
    }
  } else {
    return res.status(400).json({ error: 'Invalid action. Must be Approve, Paid, or Reject' });
  }

  db.logAudit(
    adminSession.username,
    `WITHDRAWAL_${action.toUpperCase()}`,
    `Marked withdrawal ${id} (${withdrawal.method} ৳${(withdrawal.amountPoisha / 100).toFixed(2)}) as ${action}. Note: ${adminNote || rejectionReason || payoutReference || ''}`,
    id,
    req.ip
  );

  return res.json({ success: true, withdrawal });
});

/**
 * Admin: Global Settings & Reward Configuration
 */
apiRouter.get('/admin/settings', requireAdminAuth, (_req: Request, res: Response) => {
  const data = db.getData();
  return res.json({
    success: true,
    settings: data.appSettings,
    spinOptions: data.spinOptions,
  });
});

apiRouter.put('/admin/settings', requireAdminAuth, (req: Request, res: Response) => {
  const adminSession = (req as any).adminUser;
  const { settings, spinOptions } = req.body;
  const data = db.getData();

  if (settings) {
    if (settings.appName !== undefined) data.appSettings.appName = settings.appName;
    if (settings.telegramBotUsername !== undefined) data.appSettings.telegramBotUsername = settings.telegramBotUsername;
    if (settings.supportTelegram !== undefined) data.appSettings.supportTelegram = settings.supportTelegram;
    if (settings.whatsappSupport !== undefined) data.appSettings.whatsappSupport = settings.whatsappSupport;
    if (settings.imoSupport !== undefined) data.appSettings.imoSupport = settings.imoSupport;
    if (settings.telegramChannel !== undefined) data.appSettings.telegramChannel = settings.telegramChannel;
    if (settings.minWithdrawalPoisha !== undefined) data.appSettings.minWithdrawalPoisha = Number(settings.minWithdrawalPoisha);
    if (settings.withdrawalFeePercent !== undefined) data.appSettings.withdrawalFeePercent = Number(settings.withdrawalFeePercent);
    if (settings.referralRewardPoisha !== undefined) data.appSettings.referralRewardPoisha = Number(settings.referralRewardPoisha);
    if (settings.referralCommissionPercent !== undefined) data.appSettings.referralCommissionPercent = Number(settings.referralCommissionPercent);
    if (settings.dailyAdLimit !== undefined) data.appSettings.dailyAdLimit = Number(settings.dailyAdLimit);
    if (settings.adRewardPoisha !== undefined) data.appSettings.adRewardPoisha = Number(settings.adRewardPoisha);
    if (settings.adCooldownSeconds !== undefined) data.appSettings.adCooldownSeconds = Number(settings.adCooldownSeconds);
    if (settings.adCountdownDuration !== undefined) data.appSettings.adCountdownDuration = Number(settings.adCountdownDuration);
    if (settings.adsEnabled !== undefined) data.appSettings.adsEnabled = Boolean(settings.adsEnabled);
    if (settings.announcementText !== undefined) data.appSettings.announcementText = settings.announcementText;
    if (settings.maintenanceMode !== undefined) data.appSettings.maintenanceMode = Boolean(settings.maintenanceMode);
  }

  if (Array.isArray(spinOptions)) {
    data.spinOptions = spinOptions;
  }

  db.logAudit(adminSession.username, 'UPDATE_SETTINGS', 'Updated app configuration and reward rules', undefined, req.ip);

  return res.json({ success: true, settings: data.appSettings, spinOptions: data.spinOptions });
});

/**
 * Admin: Audit Logs
 */
apiRouter.get('/admin/audit-logs', requireAdminAuth, (_req: Request, res: Response) => {
  const data = db.getData();
  return res.json({ success: true, logs: data.adminAuditLogs });
});

/**
 * Admin: Create & Download Full Database Backup
 */
apiRouter.get('/admin/backup', requireAdminAuth, (req: Request, res: Response) => {
  const adminSession = (req as any).adminUser;
  const backupFileName = db.createBackup();
  const data = db.getData();

  db.logAudit(adminSession.username, 'DATABASE_BACKUP', `Created database backup: ${backupFileName}`, undefined, req.ip);

  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Content-Disposition', `attachment; filename=${backupFileName}`);
  return res.send(JSON.stringify(data, null, 2));
});

/**
 * Admin: Restore Database from Backup JSON
 */
apiRouter.post('/admin/restore', requireAdminAuth, (req: Request, res: Response) => {
  const adminSession = (req as any).adminUser;
  const { backupData } = req.body;

  if (!backupData || !backupData.appSettings || !backupData.users) {
    return res.status(400).json({ error: 'Invalid backup file format' });
  }

  db.restoreFromData(backupData);
  db.logAudit(adminSession.username, 'DATABASE_RESTORE', 'Restored entire database from backup JSON');

  return res.json({ success: true, message: 'Database restored successfully' });
});

/**
 * Admin: Change Admin Credentials (Username and/or Password)
 */
const handleCredentialsChange = (req: Request, res: Response) => {
  const adminSession = (req as any).adminUser;
  const { currentPassword, newUsername, newPassword } = req.body;

  if (!currentPassword) {
    return res.status(400).json({ error: 'বর্তমান পাসওয়ার্ড প্রদান করা আবশ্যক (Current password is required)' });
  }

  const cleanNewUsername = newUsername ? String(newUsername).trim() : '';
  const cleanNewPassword = newPassword ? String(newPassword).trim() : '';

  if (!cleanNewUsername && !cleanNewPassword) {
    return res.status(400).json({ error: 'নতুন ইউজারনেম অথবা নতুন পাসওয়ার্ড প্রদান করুন (Provide new username or new password)' });
  }

  if (cleanNewUsername && cleanNewUsername.length < 3) {
    return res.status(400).json({ error: 'ইউজারনেম কমপক্ষে ৩ অক্ষরের হতে হবে (Username must be at least 3 characters)' });
  }

  if (cleanNewPassword && cleanNewPassword.length < 4) {
    return res.status(400).json({ error: 'নতুন পাসওয়ার্ড কমপক্ষে ৪ অক্ষরের হতে হবে (Password must be at least 4 characters)' });
  }

  const data = db.getData();
  const oldUsername = adminSession.username;
  const admin = data.adminUsers[oldUsername];

  if (!admin || admin.passwordHash !== hashPassword(currentPassword)) {
    return res.status(401).json({ error: 'বর্তমান পাসওয়ার্ডটি ভুল (Current password is incorrect)' });
  }

  let finalUsername = oldUsername;

  // If changing username
  if (cleanNewUsername && cleanNewUsername !== oldUsername) {
    if (data.adminUsers[cleanNewUsername]) {
      return res.status(400).json({ error: 'এই ইউজারনেমটি ইতিমধ্যে বিদ্যমান (Username is already taken)' });
    }

    admin.username = cleanNewUsername;
    data.adminUsers[cleanNewUsername] = admin;
    delete data.adminUsers[oldUsername];

    // Update active admin session(s)
    adminSession.username = cleanNewUsername;
    for (const token in adminSessions) {
      if (adminSessions[token].username === oldUsername) {
        adminSessions[token].username = cleanNewUsername;
      }
    }
    finalUsername = cleanNewUsername;
  }

  // If changing password
  if (cleanNewPassword) {
    admin.passwordHash = hashPassword(cleanNewPassword);
  }

  db.save();
  db.logAudit(
    finalUsername,
    'CHANGE_CREDENTIALS',
    `Updated admin credentials: ${cleanNewUsername ? 'Username updated ' : ''}${cleanNewPassword ? 'Password updated' : ''}`.trim(),
    undefined,
    req.ip
  );

  return res.json({
    success: true,
    message: 'এডমিন ক্রেডেনশিয়াল সফলভাবে আপডেট হয়েছে (Credentials updated successfully)',
    username: finalUsername,
  });
};

apiRouter.post('/admin/change-credentials', requireAdminAuth, handleCredentialsChange);
apiRouter.post('/admin/change-password', requireAdminAuth, handleCredentialsChange);

