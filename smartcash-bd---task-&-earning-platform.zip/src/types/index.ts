export interface User {
  id: string;
  telegramId: string;
  username: string;
  firstName: string;
  lastName: string;
  photoUrl: string;
  balancePoisha: number;
  totalEarnedPoisha: number;
  taskEarnedPoisha: number;
  adEarnedPoisha: number;
  spinEarnedPoisha: number;
  referralEarnedPoisha: number;
  pendingWithdrawPoisha: number;
  referralCode: string;
  referredByTelegramId: string | null;
  referralsCount: number;
  lastSpinDate: string | null;
  isBlocked: boolean;
  createdAt: string;
  updatedAt: string;
  lastActiveAt: string;
  deviceMeta?: string;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  instructions: string;
  category: 'youtube' | 'telegram' | 'facebook' | 'survey' | 'visit' | 'app';
  targetUrl: string;
  rewardPoisha: number;
  durationSeconds: number;
  adCountdownSeconds: number;
  dailyLimit: number;
  completedCount: number;
  isActive: boolean;
  createdAt: string;
}

export interface SpinOption {
  id: number;
  label: string;
  rewardPoisha: number;
  color: string;
  probabilityWeight: number;
}

export interface WithdrawalRequest {
  id: string;
  userId: string;
  telegramId: string;
  userName: string;
  method: 'bKash' | 'Nagad' | 'Rocket';
  accountType: 'Personal' | 'Merchant';
  accountNumber: string;
  amountPoisha: number;
  feePoisha: number;
  netAmountPoisha: number;
  status: 'Pending' | 'Approved' | 'Rejected' | 'Paid';
  rejectionReason?: string;
  payoutReference?: string;
  adminNote?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Transaction {
  id: string;
  userId: string;
  telegramId: string;
  type: 'task' | 'spin' | 'video_ad' | 'referral_bonus' | 'withdrawal_request' | 'withdrawal_refund' | 'admin_adjustment';
  amountPoisha: number;
  balanceAfterPoisha: number;
  description: string;
  referenceId?: string;
  createdAt: string;
}

export interface Referral {
  id: string;
  referrerTelegramId: string;
  referredTelegramId: string;
  referredName: string;
  referralCode: string;
  status: 'active' | 'completed';
  rewardPoisha: number;
  createdAt: string;
}

export interface VideoAd {
  id: string;
  title: string;
  description?: string;
  rewardPoisha: number;
  durationSeconds: number;
  videoUrl?: string;
  dailyLimit: number;
  viewsCount: number;
  isActive: boolean;
  createdAt: string;
}

export interface AppSettings {
  appName: string;
  telegramBotUsername: string;
  supportTelegram: string;
  whatsappSupport?: string;
  imoSupport?: string;
  telegramChannel?: string;
  minWithdrawalPoisha: number;
  withdrawalFeePercent: number;
  referralRewardPoisha: number;
  referralCommissionPercent: number;
  dailyAdLimit: number;
  adRewardPoisha: number;
  adCooldownSeconds: number;
  adCountdownDuration: number;
  adsEnabled: boolean;
  announcementText: string;
  maintenanceMode: boolean;
}

export interface AdminStats {
  totalUsers: number;
  activeUsers24h: number;
  linkedTelegramAccounts: number;
  completedTasks: number;
  totalRewardsIssuedBdt: string;
  pendingWithdrawalsCount: number;
  pendingWithdrawAmountBdt: string;
  paidWithdrawalsCount: number;
  paidWithdrawAmountBdt: string;
  totalReferrals: number;
  totalSpins: number;
  totalAdsWatched: number;
}

export interface AdminAuditLog {
  id: string;
  adminUsername: string;
  action: string;
  targetId?: string;
  details: string;
  ip?: string;
  createdAt: string;
}
