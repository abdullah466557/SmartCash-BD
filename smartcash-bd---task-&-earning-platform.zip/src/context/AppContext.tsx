import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { User, AppSettings } from '../types';
import { api, setApiTelegramId, setApiAdminToken } from '../services/api';

declare global {
  interface Window {
    Telegram?: {
      WebApp?: {
        initData: string;
        initDataUnsafe?: any;
        version: string;
        platform: string;
        colorScheme: 'light' | 'dark';
        themeParams: any;
        isExpanded: boolean;
        viewportHeight: number;
        viewportStableHeight: number;
        headerColor: string;
        backgroundColor: string;
        BackButton: {
          isVisible: boolean;
          onClick: (cb: () => void) => void;
          offClick: (cb: () => void) => void;
          show: () => void;
          hide: () => void;
        };
        MainButton: {
          text: string;
          color: string;
          textColor: string;
          isVisible: boolean;
          isActive: boolean;
          show: () => void;
          hide: () => void;
          onClick: (cb: () => void) => void;
        };
        HapticFeedback: {
          impactOccurred: (style: 'light' | 'medium' | 'heavy' | 'rigid' | 'soft') => void;
          notificationOccurred: (type: 'error' | 'success' | 'warning') => void;
          selectionChanged: () => void;
        };
        expand: () => void;
        close: () => void;
        ready: () => void;
        openTelegramLink: (url: string) => void;
        openLink: (url: string) => void;
      };
    };
  }
}

import { translations, Language, Translations } from '../i18n/translations';

export type NavTab = 'home' | 'refer' | 'support' | 'wallet' | 'profile' | 'tasks' | 'ads' | 'spin';

interface ToastState {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}

interface AppContextType {
  user: User | null;
  settings: AppSettings;
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  t: Translations;
  isLoading: boolean;
  isTelegramMiniApp: boolean;
  isAdminOpen: boolean;
  setIsAdminOpen: (open: boolean) => void;
  isSimulatorOpen: boolean;
  setIsSimulatorOpen: (open: boolean) => void;
  adminUser: { username: string; role: string } | null;
  toasts: ToastState[];
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  refreshUser: () => Promise<void>;
  refreshSettings: () => Promise<void>;
  switchUser: (telegramUser: any, referralCode?: string) => Promise<void>;
  handleAdminLoginSuccess: (token: string, admin: any) => void;
  handleAdminLogout: () => void;
  updateAdminUsername: (newUsername: string) => void;
  triggerHaptic: (type?: 'light' | 'medium' | 'success' | 'error') => void;
}

const DEFAULT_SETTINGS: AppSettings = {
  appName: 'SmartCash BD',
  telegramBotUsername: '@smartcashbd_bot',
  supportTelegram: '@smartcashbd_support',
  whatsappSupport: 'https://wa.me/8801819234567',
  imoSupport: '+8801819234567',
  telegramChannel: 'https://t.me/smartcashbd_channel',
  minWithdrawalPoisha: 5000,
  withdrawalFeePercent: 2,
  referralRewardPoisha: 1000,
  referralCommissionPercent: 5,
  dailyAdLimit: 15,
  adRewardPoisha: 100,
  adCooldownSeconds: 45,
  adCountdownDuration: 10,
  adsEnabled: true,
  announcementText: '🔥 Eid Bonus Active: 10 BDT instant referral bonus! Minimum withdrawal only 50 BDT via bKash & Nagad.',
  maintenanceMode: false,
};

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [activeTab, setActiveTab] = useState<NavTab>('home');
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('smartcash_lang') as Language;
    return saved === 'en' || saved === 'bn' || saved === 'hi' ? saved : 'bn';
  });
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isTelegramMiniApp, setIsTelegramMiniApp] = useState<boolean>(false);
  const [isAdminOpen, setIsAdminOpen] = useState<boolean>(false);
  const [isSimulatorOpen, setIsSimulatorOpen] = useState<boolean>(false);
  const [adminUser, setAdminUser] = useState<{ username: string; role: string } | null>(null);
  const [toasts, setToasts] = useState<ToastState[]>([]);

  // Show Toast
  const showToast = useCallback((message: string, type: 'success' | 'error' | 'info' = 'info') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, type, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  }, []);

  // Telegram Haptic feedback wrapper
  const triggerHaptic = useCallback((type: 'light' | 'medium' | 'success' | 'error' = 'light') => {
    try {
      if (window.Telegram?.WebApp?.HapticFeedback) {
        if (type === 'success' || type === 'error') {
          window.Telegram.WebApp.HapticFeedback.notificationOccurred(type);
        } else {
          window.Telegram.WebApp.HapticFeedback.impactOccurred(type);
        }
      }
    } catch {}
  }, []);

  // Fetch App Settings
  const refreshSettings = useCallback(async () => {
    try {
      const res = await api.getSettings();
      if (res.success && res.settings) {
        setSettings(res.settings);
      }
    } catch (err) {
      console.warn('Settings sync waiting for backend...', err);
    }
  }, []);

  // Fetch Current User
  const refreshUser = useCallback(async () => {
    try {
      const res = await api.getUserMe();
      if (res.success && res.user) {
        setUser(res.user);
      }
    } catch (err) {
      console.warn('User sync waiting for backend...', err);
    }
  }, []);

  // Switch or authenticate user
  const switchUser = useCallback(async (telegramUser: any, referralCode?: string) => {
    try {
      setIsLoading(true);
      const res = await api.authOrRegister({
        mockUser: telegramUser,
        referralCode,
      });
      if (res.success) {
        setApiTelegramId(res.user.telegramId);
        setUser(res.user);
        localStorage.setItem('smartcash_tg_id', res.user.telegramId);
        if (res.isNew) {
          showToast(`Welcome ${res.user.firstName}! ৳5.00 Welcome Bonus credited!`, 'success');
        } else {
          showToast(`Logged in as ${res.user.firstName} (@${res.user.username})`, 'info');
        }
      }
    } catch (err: any) {
      showToast(err.message || 'Authentication failed', 'error');
    } finally {
      setIsLoading(false);
    }
  }, [showToast]);

  // Handle Admin Login Success
  const handleAdminLoginSuccess = useCallback((token: string, admin: any) => {
    setApiAdminToken(token);
    setAdminUser(admin);
    showToast(`এডমিন লগইন সফল: ${admin.username}`, 'success');
  }, [showToast]);

  // Handle Admin Logout
  const handleAdminLogout = useCallback(() => {
    setApiAdminToken('');
    setAdminUser(null);
    localStorage.removeItem('smartcash_admin_token');
    sessionStorage.removeItem('smartcash_admin_token');
  }, []);

  // Update Admin Username in active session
  const updateAdminUsername = useCallback((newUsername: string) => {
    setAdminUser((prev) => (prev ? { ...prev, username: newUsername } : null));
  }, []);

  // Initial App Setup
  useEffect(() => {
    let mounted = true;

    async function init() {
      await refreshSettings();

      // Detect Telegram WebApp
      const tg = window.Telegram?.WebApp;
      if (tg && tg.initData && tg.initData.length > 0) {
        setIsTelegramMiniApp(true);
        try {
          tg.ready();
          tg.expand();
        } catch {}

        try {
          const res = await api.authOrRegister({ initData: tg.initData });
          if (res.success && mounted) {
            setApiTelegramId(res.user.telegramId);
            setUser(res.user);
            setIsLoading(false);
            return;
          }
        } catch (err) {
          console.error('Failed to auth with Telegram initData:', err);
        }
      }

      // Check URL query parameters for referral link test e.g. ?start=SCBD8801
      const urlParams = new URLSearchParams(window.location.search);
      const startRef = urlParams.get('start') || urlParams.get('tgWebAppStartParam') || undefined;

      // Fallback: Check local storage or seed default user
      const savedTelegramId = localStorage.getItem('smartcash_tg_id');
      const targetId = savedTelegramId || '8801900123';

      try {
        const res = await api.authOrRegister({
          mockUser: {
            id: targetId,
            first_name: targetId === '8801900123' ? 'Tanvir' : 'SmartCash',
            last_name: targetId === '8801900123' ? 'Hasan' : 'User',
            username: targetId === '8801900123' ? 'tanvir_hasan' : `user_${targetId.slice(-4)}`,
          },
          referralCode: startRef,
        });

        if (res.success && mounted) {
          setApiTelegramId(res.user.telegramId);
          setUser(res.user);
          localStorage.setItem('smartcash_tg_id', res.user.telegramId);
        }
      } catch (err) {
        console.error('Initial auto auth failed:', err);
      } finally {
        if (mounted) setIsLoading(false);
      }
    }

    init();

    // Check hash for initial tab e.g. #tasks or #wallet
    if (window.location.hash) {
      const hash = window.location.hash.replace('#', '') as NavTab;
      if (['home', 'tasks', 'refer', 'ads', 'spin', 'wallet', 'profile'].includes(hash)) {
        setActiveTab(hash);
      }
    }

    // Polling interval to keep balance and settings synchronized in real-time
    const interval = setInterval(() => {
      refreshUser();
      refreshSettings();
    }, 15000);

    return () => {
      mounted = false;
      clearInterval(interval);
    };
  }, [refreshSettings, refreshUser]);

  const setLanguage = useCallback((lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('smartcash_lang', lang);
  }, []);

  const t = translations[language] || translations.bn;

  return (
    <AppContext.Provider
      value={{
        user,
        settings,
        activeTab,
        setActiveTab: (tab) => {
          setActiveTab(tab);
          window.location.hash = tab;
          triggerHaptic('light');
        },
        language,
        setLanguage,
        t,
        isLoading,
        isTelegramMiniApp,
        isAdminOpen,
        setIsAdminOpen,
        isSimulatorOpen,
        setIsSimulatorOpen,
        adminUser,
        toasts,
        showToast,
        refreshUser,
        refreshSettings,
        switchUser,
        handleAdminLoginSuccess,
        handleAdminLogout,
        updateAdminUsername,
        triggerHaptic,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
