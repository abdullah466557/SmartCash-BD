export type Language = 'en' | 'bn' | 'hi';

export interface Translations {
  // Navigation
  navHome: string;
  navRefer: string;
  navSupport: string;
  navWallet: string;
  navProfile: string;

  // Home Screen
  mainBalance: string;
  pendingPayout: string;
  totalEarned: string;
  referralIncome: string;
  withdrawBdt: string;
  inviteFriends: string;
  tgConnected: string;
  waysToEarn: string;
  activeEarnings: string;
  dailySpinTitle: string;
  dailySpinDesc: string;
  tasksTitle: string;
  tasksDesc: string;
  videoAdsTitle: string;
  videoAdsDesc: string;
  referTitle: string;
  referDesc: string;
  recentPayouts: string;
  zeroRegistrationTip: string;
  startEarningHint: string;

  // Support Screen
  supportHeaderTitle: string;
  supportHeaderDesc: string;
  whatsappSupportTitle: string;
  whatsappSupportSub: string;
  imoSupportTitle: string;
  imoSupportSub: string;
  telegramChannelTitle: string;
  telegramChannelSub: string;
  chatOnWhatsapp: string;
  contactOnImo: string;
  joinTelegramChannel: string;
  supportHours: string;
  supportNotice: string;

  // Video Ads Screen
  watchVideoAds: string;
  videoAdsHeaderDesc: string;
  todayAdQuota: string;
  watched: string;
  rewardPerAd: string;
  watchAdBtn: string;
  cooldownActive: string;
  dailyLimitReached: string;
  watchingAd: string;
  adNotice: string;
  noAdsAvailable: string;

  // Profile Screen
  profileTitle: string;
  joinedOn: string;
  referralCodeLabel: string;
  accountStatus: string;
  activeGoodStanding: string;
  clientEnv: string;
  currencySystem: string;
  selectLanguage: string;
  langEnglish: string;
  langBengali: string;
  langHindi: string;
  testAccountSwitcher: string;
  switchAccount: string;

  // Wallet Screen
  walletTitle: string;
  selectGateway: string;
  personalAccount: string;
  merchantAccount: string;
  accountNumber: string;
  amountBdt: string;
  useMax: string;
  netPayout: string;
  submitWithdrawal: string;
  requestsTab: string;
  ledgerTab: string;
  withdrawTab: string;

  // Refer Screen
  referralProgram: string;
  referralEarnNotice: string;
  invitedFriends: string;
  yourDeepLink: string;
  copyLink: string;
  copied: string;
  shareTelegram: string;

  // Spin & Tasks
  spinTitle: string;
  spinBtn: string;
  comeBackTomorrow: string;
  spinning: string;
}

export const translations: Record<Language, Translations> = {
  en: {
    navHome: 'Home',
    navRefer: 'Refer',
    navSupport: 'Support',
    navWallet: 'Wallet',
    navProfile: 'Profile',

    mainBalance: 'Main BDT Balance',
    pendingPayout: 'Pending',
    totalEarned: 'Total Earned',
    referralIncome: 'Referral Inc.',
    withdrawBdt: 'Withdraw BDT',
    inviteFriends: 'Invite Friends',
    tgConnected: 'Telegram Bot Connected',
    waysToEarn: 'Ways to Earn Today',
    activeEarnings: 'Active Earnings',
    dailySpinTitle: 'Lucky Wheel Spin',
    dailySpinDesc: 'Win up to ৳15.00 BDT once per day',
    tasksTitle: 'Task Marketplace',
    tasksDesc: 'Complete simple tasks & earn BDT',
    videoAdsTitle: 'Watch Video Ads',
    videoAdsDesc: 'Watch short video ads to earn BDT',
    referTitle: 'Refer & Commission',
    referDesc: 'Earn ৳10 + 5% lifetime earnings',
    recentPayouts: 'Live bKash & Nagad Payouts',
    zeroRegistrationTip: 'Zero Registration: New accounts start with ৳0.00 balance. Complete tasks to earn BDT!',
    startEarningHint: 'New users start with ৳0.00 BDT balance. Complete tasks & watch ads to start earning!',

    supportHeaderTitle: 'Official Help & Support',
    supportHeaderDesc: 'Connect with our verified support team through WhatsApp, IMO, or our Telegram Channel.',
    whatsappSupportTitle: 'WhatsApp Support',
    whatsappSupportSub: 'Chat with our support executive directly on WhatsApp',
    imoSupportTitle: 'IMO Support',
    imoSupportSub: 'Call or message on IMO for fast payment assistance',
    telegramChannelTitle: 'Official Telegram Channel',
    telegramChannelSub: 'Daily payment proofs, promo codes, and updates',
    chatOnWhatsapp: 'Chat on WhatsApp',
    contactOnImo: 'Contact on IMO',
    joinTelegramChannel: 'Join Telegram Channel',
    supportHours: 'Active 24/7 Support Hotline',
    supportNotice: 'Always verify you are contacting our official support links listed above.',

    watchVideoAds: 'Watch Video Ads',
    videoAdsHeaderDesc: 'Watch short sponsor video impressions to earn direct BDT rewards.',
    todayAdQuota: "Today's Ad Quota",
    watched: 'watched',
    rewardPerAd: 'Reward',
    watchAdBtn: 'Watch Video & Earn',
    cooldownActive: 'Cooldown active',
    dailyLimitReached: 'Daily limit reached',
    watchingAd: 'Watching sponsor video...',
    adNotice: 'Please do not close or minimize until the video timer finishes.',
    noAdsAvailable: 'No video ads currently active. Please check back shortly.',

    profileTitle: 'User Profile & Identity',
    joinedOn: 'Joined On',
    referralCodeLabel: 'Referral Code',
    accountStatus: 'Account Status',
    activeGoodStanding: 'Active & Good Standing',
    clientEnv: 'Client Environment',
    currencySystem: 'Currency System',
    selectLanguage: 'Choose Language (ভাষা নির্বাচন)',
    langEnglish: 'English',
    langBengali: 'বাংলা',
    langHindi: 'हिन्दी',
    testAccountSwitcher: 'Test Different Telegram Accounts',
    switchAccount: 'Switch to This Telegram Account',

    walletTitle: 'BDT Financial Wallet',
    selectGateway: 'Select Payout Channel',
    personalAccount: 'Personal Account',
    merchantAccount: 'Merchant / Agent',
    accountNumber: 'Mobile Number (11 Digits)',
    amountBdt: 'Amount in BDT (৳)',
    useMax: 'Use Max',
    netPayout: 'Net Payout You Receive',
    submitWithdrawal: 'Submit Withdrawal',
    requestsTab: 'Requests',
    ledgerTab: 'Ledger',
    withdrawTab: 'Withdraw',

    referralProgram: 'Instant Referral Program',
    referralEarnNotice: 'Invite friends using your official link to earn instant BDT rewards.',
    invitedFriends: 'Invited Friends',
    yourDeepLink: 'Your Official Telegram Deep Link',
    copyLink: 'Copy Link',
    copied: 'Copied!',
    shareTelegram: 'Share Link on Telegram',

    spinTitle: 'Daily Lucky Spin Wheel',
    spinBtn: 'Spin & Win BDT',
    comeBackTomorrow: 'Spun Today (Come back tomorrow)',
    spinning: 'Spinning Wheel...',
  },

  bn: {
    navHome: 'হোম',
    navRefer: 'রেফার',
    navSupport: 'সাপোর্ট',
    navWallet: 'ওয়ালেট',
    navProfile: 'প্রোফাইল',

    mainBalance: 'বর্তমান ব্যালেন্স',
    pendingPayout: 'পেন্ডিং টাকা',
    totalEarned: 'মোট আয়',
    referralIncome: 'রেফারেল আয়',
    withdrawBdt: 'টাকা তুলুন',
    inviteFriends: 'বন্ধু ইনভাইট করুন',
    tgConnected: 'টেলিগ্রাম বট সংযুক্ত',
    waysToEarn: 'আজকের আয়ের মাধ্যম',
    activeEarnings: 'সক্রিয় অফার',
    dailySpinTitle: 'দৈনিক লাকি স্পিন',
    dailySpinDesc: 'প্রতিদিন একবার স্পিন করে জিতুন ৳১৫ পর্যন্ত',
    tasksTitle: 'টাস্ক মার্কেটপ্লেস',
    tasksDesc: 'সহজ টাস্ক সম্পন্ন করে আয় করুন টাকা',
    videoAdsTitle: 'ভিডিও অ্যাড দেখুন',
    videoAdsDesc: 'ছোট ভিডিও অ্যাড দেখে সরাসরি আয় করুন',
    referTitle: 'রেফার এবং ইনকাম',
    referDesc: 'প্রতি রেফারে ৳১০ + ৫% লাইফটাইম কমিশন',
    recentPayouts: 'সরাসরি বিকাশ ও নগদ পেমেন্ট প্রুফ',
    zeroRegistrationTip: 'নতুন একাউন্টে ব্যালেন্স শূন্য (৳০.০০)। এখান থেকে কাজ করে আয় করতে হবে!',
    startEarningHint: 'আপনার প্রাথমিক ব্যালেন্স ৳০.০০ টাকা। টাস্ক, ভিডিও অ্যাড ও স্পিন করে আয় শুরু করুন!',

    supportHeaderTitle: 'অফিসিয়াল হেল্প এবং সাপোর্ট',
    supportHeaderDesc: 'যেকোনো সমস্যায় সরাসরি আমাদের হোয়াটসঅ্যাপ, ইমো অথবা অফিশিয়াল টেলিগ্রাম চ্যানেলে যোগাযোগ করুন।',
    whatsappSupportTitle: 'হোয়াটসঅ্যাপ সাপোর্ট',
    whatsappSupportSub: 'আমাদের সাপোর্ট টিমের সাথে সরাসরি হোয়াটসঅ্যাপে চ্যাট করুন',
    imoSupportTitle: 'ইমো সাপোর্ট',
    imoSupportSub: 'পেমেন্ট ও উইথড্র সংক্রান্ত জরুরি সহায়তার জন্য ইমোতে যোগাযোগ করুন',
    telegramChannelTitle: 'অফিসিয়াল টেলিগ্রাম চ্যানেল',
    telegramChannelSub: 'দৈনিক পেমেন্ট প্রুফ, নতুন অফার ও নোটিশ পেতে যুক্ত থাকুন',
    chatOnWhatsapp: 'হোয়াটসঅ্যাপে মেসেজ দিন',
    contactOnImo: 'ইমোতে যোগাযোগ করুন',
    joinTelegramChannel: 'টেলিগ্রাম চ্যানেলে যুক্ত হোন',
    supportHours: '২৪/৭ সার্বক্ষণিক একটিভ কাস্টমার সাপোর্ট',
    supportNotice: 'নিরাপত্তার স্বার্থে সর্বদা উপরের অফিসিয়াল লিঙ্কগুলো থেকেই যোগাযোগ করবেন।',

    watchVideoAds: 'ভিডিও অ্যাড দেখুন',
    videoAdsHeaderDesc: 'স্পন্সর ভিডিও অ্যাড দেখে সরাসরি আপনার ওয়ালেটে টাকা যোগ করুন।',
    todayAdQuota: 'আজকের অ্যাডের কোটা',
    watched: 'টি দেখা হয়েছে',
    rewardPerAd: 'প্রতি অ্যাডে আয়',
    watchAdBtn: 'অ্যাড দেখুন এবং আয় করুন',
    cooldownActive: 'অপেক্ষার সময় বাকি',
    dailyLimitReached: 'আজকের লিমিট শেষ',
    watchingAd: 'ভিডিও অ্যাড চলছে...',
    adNotice: 'ভিডিওর কাউন্টডাউন শেষ না হওয়া পর্যন্ত উইন্ডো বন্ধ করবেন না।',
    noAdsAvailable: 'এই মুহূর্তে কোনো নতুন অ্যাড নেই। কিছুক্ষণ পর আবার চেষ্টা করুন।',

    profileTitle: 'ইউজার প্রোফাইল ও তথ্য',
    joinedOn: 'যোগদানের তারিখ',
    referralCodeLabel: 'রেফার কোড',
    accountStatus: 'একাউন্ট স্ট্যাটাস',
    activeGoodStanding: 'ভেরিফায়েড ও সক্রিয়',
    clientEnv: 'অ্যাপ প্ল্যাটফর্ম',
    currencySystem: 'মুদ্রা ব্যবস্থা (বাংলাদেশি টাকা)',
    selectLanguage: 'ভাষা পরিবর্তন করুন (Select Language)',
    langEnglish: 'English',
    langBengali: 'বাংলা',
    langHindi: 'हिन्दी',
    testAccountSwitcher: 'অন্যান্য টেলিগ্রাম একাউন্ট টেস্ট করুন',
    switchAccount: 'এই একাউন্টে সুইচ করুন',

    walletTitle: 'বিকাশ ও নগদ ওয়ালেট',
    selectGateway: 'পেমেন্ট মাধ্যম বেছে নিন',
    personalAccount: 'পার্সোনাল একাউন্ট',
    merchantAccount: 'মার্চেন্ট / এজেন্ট',
    accountNumber: 'মোবাইল নম্বর (১১ ডিজিট)',
    amountBdt: 'টাকার পরিমাণ (৳ BDT)',
    useMax: 'সব টাকা তুলুন',
    netPayout: 'আপনি মোট পাবেন (চার্জ বাদে)',
    submitWithdrawal: 'উইথড্র রিকোয়েস্ট পাঠান',
    requestsTab: 'রিকোয়েস্টসমূহ',
    ledgerTab: 'লেনদেন বিবরণী',
    withdrawTab: 'উইথড্র',

    referralProgram: 'ইনস্ট্যান্ট রেফারেল প্রোগ্রাম',
    referralEarnNotice: 'আপনার ব্যক্তিগত লিংক বন্ধুদের মাঝে শেয়ার করুন এবং প্রতি রেফারে সরাসরি বোনাস নিন।',
    invitedFriends: 'মোট রেফারকৃত বন্ধু',
    yourDeepLink: 'আপনার অফিসিয়াল টেলিগ্রাম ডিপ লিংক',
    copyLink: 'লিংক কপি করুন',
    copied: 'কপি হয়েছে!',
    shareTelegram: 'টেলিগ্রামে শেয়ার করুন',

    spinTitle: 'দৈনিক লাকি স্পিন হুইল',
    spinBtn: 'স্পিন করে টাকা জিতুন',
    comeBackTomorrow: 'আজকের স্পিন সম্পন্ন (আগামীকাল আবার আসুন)',
    spinning: 'হুইল ঘুরছে...',
  },

  hi: {
    navHome: 'होम',
    navRefer: 'रेफर',
    navSupport: 'सपोर्ट',
    navWallet: 'वॉलेट',
    navProfile: 'प्रोफ़ाइल',

    mainBalance: 'मुख्य बैलेंस',
    pendingPayout: 'पेंडिंग राशि',
    totalEarned: 'कुल कमाई',
    referralIncome: 'रेफरल आय',
    withdrawBdt: 'पैसे निकालें',
    inviteFriends: 'दोस्तों को जोड़ें',
    tgConnected: 'टेलीग्राम बॉट कनेक्टेड',
    waysToEarn: 'आज कमाने के तरीके',
    activeEarnings: 'सक्रिय ऑफर्स',
    dailySpinTitle: 'लकी स्पिन व्हील',
    dailySpinDesc: 'रोजाना एक बार स्पिन करें और जीतें ৳15 तक',
    tasksTitle: 'टास्क मार्केटप्लेस',
    tasksDesc: 'आसान काम पूरा करें और BDT कमाएं',
    videoAdsTitle: 'वीडियो विज्ञापन देखें',
    videoAdsDesc: 'छोटे वीडियो देखकर सीधे BDT कमाएं',
    referTitle: 'रेफर और कमीशन',
    referDesc: 'प्रति रेफर ৳10 + 5% लाइफटाइम कमाई',
    recentPayouts: 'लाइव bKash और Nagad भुगतान',
    zeroRegistrationTip: 'नए खाते का बैलेंस शून्य (৳0.00) होगा। यहां से काम करके कमाएं!',
    startEarningHint: 'आपका प्रारंभिक बैलेंस ৳0.00 है। टास्क और वीडियो देखकर कमाई शुरू करें!',

    supportHeaderTitle: 'आधिकारिक सहायता और सपोर्ट',
    supportHeaderDesc: 'किसी भी समस्या के लिए हमारे व्हाट्सएप, इमो या टेलीग्राम चैनल पर संपर्क करें।',
    whatsappSupportTitle: 'व्हाट्सएप सपोर्ट',
    whatsappSupportSub: 'सीधे व्हाट्सएप पर हमारी टीम से बात करें',
    imoSupportTitle: 'इमो सपोर्ट',
    imoSupportSub: 'भुगतान और निकासी सहायता के लिए इमो पर संपर्क करें',
    telegramChannelTitle: 'आधिकारिक टेलीग्राम चैनल',
    telegramChannelSub: 'दैनिक भुगतान प्रमाण और नए अपडेट प्राप्त करें',
    chatOnWhatsapp: 'व्हाट्सएप पर चैट करें',
    contactOnImo: 'इमो पर संपर्क करें',
    joinTelegramChannel: 'टेलीग्राम चैनल से जुड़ें',
    supportHours: '24/7 सक्रिय कस्टमर सपोर्ट',
    supportNotice: 'सुरक्षा के लिए हमेशा ऊपर दिए गए आधिकारिक लिंक पर ही संपर्क करें।',

    watchVideoAds: 'वीडियो विज्ञापन देखें',
    videoAdsHeaderDesc: 'प्रायोजित वीडियो विज्ञापन देखकर सीधे अपने वॉलेट में BDT जोड़ें।',
    todayAdQuota: 'आज का विज्ञापन कोटा',
    watched: 'देखा गया',
    rewardPerAd: 'प्रति विज्ञापन इनाम',
    watchAdBtn: 'विज्ञापन देखें और कमाएं',
    cooldownActive: 'कूलडाउन समय बाकी',
    dailyLimitReached: 'दैनिक सीमा पूरी हो गई',
    watchingAd: 'वीडियो विज्ञापन चल रहा है...',
    adNotice: 'टाइमर समाप्त होने तक कृपया विंडो बंद न करें।',
    noAdsAvailable: 'वर्तमान में कोई विज्ञापन उपलब्ध नहीं है। कृपया थोड़ी देर बाद देखें।',

    profileTitle: 'उपयोगकर्ता प्रोफ़ाइल और जानकारी',
    joinedOn: 'शामिल होने की तिथि',
    referralCodeLabel: 'रेफरल कोड',
    accountStatus: 'खाता स्थिति',
    activeGoodStanding: 'सक्रिय और सत्यापित',
    clientEnv: 'ऐप वातावरण',
    currencySystem: 'मुद्रा प्रणाली (BDT)',
    selectLanguage: 'भाषा चुनें (Select Language)',
    langEnglish: 'English',
    langBengali: 'বাংলা',
    langHindi: 'हिन्दी',
    testAccountSwitcher: 'अन्य टेलीग्राम खाते टेस्ट करें',
    switchAccount: 'इस खाते पर जाएं',

    walletTitle: 'BDT वित्तीय वॉलेट',
    selectGateway: 'भुगतान चैनल चुनें',
    personalAccount: 'व्यक्तिगत खाता',
    merchantAccount: 'मर्चेंट / एजेंट',
    accountNumber: 'मोबाइल नंबर (11 अंक)',
    amountBdt: 'राशि BDT में (৳)',
    useMax: 'अधिकतम चुनें',
    netPayout: 'आपको प्राप्त होने वाली कुल राशि',
    submitWithdrawal: 'निकासी अनुरोध भेजें',
    requestsTab: 'अनुरोध',
    ledgerTab: 'लेनदेन विवरण',
    withdrawTab: 'निकासी',

    referralProgram: 'त्वरित रेफरल कार्यक्रम',
    referralEarnNotice: 'अपने लिंक से दोस्तों को जोड़ें और तुरंत BDT बोनस पाएं।',
    invitedFriends: 'आमंत्रित मित्र',
    yourDeepLink: 'आपका आधिकारिक टेलीग्राम डीप लिंक',
    copyLink: 'लिंक कॉपी करें',
    copied: 'कॉपी हो गया!',
    shareTelegram: 'टेलीग्राम पर शेयर करें',

    spinTitle: 'दैनिक लकी स्पिन व्हील',
    spinBtn: 'स्पिन करें और BDT जीतें',
    comeBackTomorrow: 'आज का स्पिन समाप्त (कल फिर आएं)',
    spinning: 'व्हील घूम रहा है...',
  },
};
