import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { AdminStats, Task, WithdrawalRequest, User, AppSettings, SpinOption, AdminAuditLog, VideoAd } from '../../types';
import {
  ShieldCheck,
  X,
  LayoutDashboard,
  CheckSquare,
  Wallet,
  Users,
  Settings,
  Tv,
  FileText,
  Lock,
  Download,
  Upload,
  RefreshCw,
  Plus,
  Trash2,
  Edit2,
  Check,
  AlertTriangle,
  Search,
  Play,
  Pause,
} from 'lucide-react';

type AdminTab =
  | 'dashboard'
  | 'tasks'
  | 'withdrawals'
  | 'users'
  | 'rewards'
  | 'ads'
  | 'global'
  | 'security'
  | 'audit'
  | 'backup';

export const AdminPanelModal: React.FC = () => {
  const {
    isAdminOpen,
    setIsAdminOpen,
    adminUser,
    handleAdminLoginSuccess,
    handleAdminLogout,
    updateAdminUsername,
    showToast,
    refreshSettings,
    triggerHaptic,
  } = useApp();

  // Login form state (always empty by default, no prefilled credentials)
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);

  // Admin active tab
  const [currentTab, setCurrentTab] = useState<AdminTab>('dashboard');

  // Data states
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>([]);
  const [usersList, setUsersList] = useState<User[]>([]);
  const [userSearch, setUserSearch] = useState('');
  const [auditLogs, setAuditLogs] = useState<AdminAuditLog[]>([]);
  const [adminSettings, setAdminSettings] = useState<AppSettings | null>(null);
  const [spinOptions, setSpinOptions] = useState<SpinOption[]>([]);
  const [videoAdsList, setVideoAdsList] = useState<VideoAd[]>([]);
  const [isVideoAdModalOpen, setIsVideoAdModalOpen] = useState(false);
  const [newAdTitle, setNewAdTitle] = useState('');
  const [newAdRewardBdt, setNewAdRewardBdt] = useState('1.00');
  const [newAdDuration, setNewAdDuration] = useState('15');
  const [newAdDailyLimit, setNewAdDailyLimit] = useState('10');
  const [newAdUrl, setNewAdUrl] = useState('');
  const [loading, setLoading] = useState(false);

  // Task creation/edit modal state
  const [editingTask, setEditingTask] = useState<Partial<Task> | null>(null);
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);

  // User balance adjustment modal state
  const [selectedUserForAdjustment, setSelectedUserForAdjustment] = useState<User | null>(null);
  const [adjustAmountBdt, setAdjustAmountBdt] = useState('');
  const [adjustReason, setAdjustReason] = useState('');
  const [adjustOperation, setAdjustOperation] = useState<'credit' | 'debit'>('credit');

  // Withdrawal action modal
  const [selectedWithdrawal, setSelectedWithdrawal] = useState<WithdrawalRequest | null>(null);
  const [payoutReference, setPayoutReference] = useState('');
  const [rejectionReason, setRejectionReason] = useState('');
  const [actionType, setActionType] = useState<'Approve' | 'Paid' | 'Reject' | null>(null);

  // Admin credentials update state
  const [currentAdminPassword, setCurrentAdminPassword] = useState('');
  const [newAdminUsername, setNewAdminUsername] = useState('');
  const [newAdminPassword, setNewAdminPassword] = useState('');
  const [confirmAdminPassword, setConfirmAdminPassword] = useState('');
  const [isUpdatingCredentials, setIsUpdatingCredentials] = useState(false);

  // Close admin panel and strictly reset session so password is required every time
  const handleCloseAdmin = () => {
    handleAdminLogout();
    setUsername('');
    setPassword('');
    setLoginError(null);
    setCurrentAdminPassword('');
    setNewAdminUsername('');
    setNewAdminPassword('');
    setConfirmAdminPassword('');
    setIsAdminOpen(false);
  };

  // Handle Admin Credentials Update (Username & Password)
  const handleUpdateCredentials = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentAdminPassword) {
      showToast('বর্তমান পাসওয়ার্ড প্রদান করুন (Enter current password)', 'error');
      return;
    }
    const cleanUsername = newAdminUsername.trim();
    const cleanPassword = newAdminPassword.trim();
    if (!cleanUsername && !cleanPassword) {
      showToast('নতুন ইউজারনেম অথবা নতুন পাসওয়ার্ড প্রদান করুন', 'error');
      return;
    }
    if (cleanPassword && cleanPassword !== confirmAdminPassword.trim()) {
      showToast('নতুন পাসওয়ার্ড দুটি মিলছে না (Passwords do not match)', 'error');
      return;
    }
    if (cleanPassword && cleanPassword.length < 4) {
      showToast('নতুন পাসওয়ার্ড কমপক্ষে ৪ অক্ষরের হতে হবে', 'error');
      return;
    }
    if (cleanUsername && cleanUsername.length < 3) {
      showToast('নতুন ইউজারনেম কমপক্ষে ৩ অক্ষরের হতে হবে', 'error');
      return;
    }
    try {
      setIsUpdatingCredentials(true);
      triggerHaptic('medium');
      const res = await api.adminChangeCredentials({
        currentPassword: currentAdminPassword,
        newUsername: cleanUsername || undefined,
        newPassword: cleanPassword || undefined,
      });
      if (res.success) {
        showToast(res.message || 'ইউজারনেম ও পাসওয়ার্ড সফলভাবে আপডেট হয়েছে', 'success');
        if (res.username) {
          updateAdminUsername(res.username);
        }
        setCurrentAdminPassword('');
        setNewAdminUsername('');
        setNewAdminPassword('');
        setConfirmAdminPassword('');
      }
    } catch (err: any) {
      showToast(err.message || 'ক্রেডেনশিয়াল আপডেট ব্যর্থ হয়েছে', 'error');
    } finally {
      setIsUpdatingCredentials(false);
    }
  };

  // Perform Admin Login
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoggingIn(true);
    setLoginError(null);
    try {
      const res = await api.adminLogin({ username, password });
      if (res.success) {
        handleAdminLoginSuccess(res.token, res.admin);
        setCurrentTab('dashboard');
        loadTabContent('dashboard');
      }
    } catch (err: any) {
      setLoginError(err.message || 'Invalid credentials');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const loadTabContent = async (tab: AdminTab) => {
    try {
      setLoading(true);
      if (tab === 'dashboard') {
        const res = await api.adminGetDashboard();
        if (res.success) setStats(res.stats);
      } else if (tab === 'tasks') {
        const res = await api.adminGetTasks();
        if (res.success) setTasks(res.tasks);
      } else if (tab === 'withdrawals') {
        const res = await api.adminGetWithdrawals();
        if (res.success) setWithdrawals(res.withdrawals);
      } else if (tab === 'users') {
        const res = await api.adminGetUsers(userSearch);
        if (res.success) setUsersList(res.users);
      } else if (tab === 'ads') {
        const [settingsRes, adsRes] = await Promise.all([
          api.adminGetSettings(),
          api.adminGetVideoAds(),
        ]);
        if (settingsRes.success) {
          setAdminSettings(settingsRes.settings);
        }
        if (adsRes.success) {
          setVideoAdsList(adsRes.ads);
        }
      } else if (tab === 'rewards' || tab === 'global') {
        const res = await api.adminGetSettings();
        if (res.success) {
          setAdminSettings(res.settings);
          setSpinOptions(res.spinOptions);
        }
      } else if (tab === 'audit') {
        const res = await api.adminGetAuditLogs();
        if (res.success) setAuditLogs(res.logs);
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to fetch admin data', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAdminOpen && adminUser) {
      loadTabContent(currentTab);
    }
  }, [isAdminOpen, adminUser, currentTab]);

  // Handle Withdrawal Action
  const handleConfirmWithdrawalAction = async () => {
    if (!selectedWithdrawal || !actionType) return;
    try {
      triggerHaptic('medium');
      const res = await api.adminActionWithdrawal(selectedWithdrawal.id, {
        action: actionType,
        payoutReference: payoutReference || undefined,
        rejectionReason: rejectionReason || undefined,
      });

      if (res.success) {
        showToast(`Withdrawal marked as ${actionType}`, 'success');
        setSelectedWithdrawal(null);
        setActionType(null);
        setPayoutReference('');
        setRejectionReason('');
        loadTabContent('withdrawals');
      }
    } catch (err: any) {
      showToast(err.message || 'Action failed', 'error');
    }
  };

  // Handle Save Task
  const handleSaveTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTask) return;
    try {
      triggerHaptic('medium');
      if (editingTask.id) {
        await api.adminUpdateTask(editingTask.id, editingTask);
        showToast('Task updated successfully', 'success');
      } else {
        await api.adminCreateTask({
          title: editingTask.title || 'New Task',
          description: editingTask.description || '',
          instructions: editingTask.instructions || '',
          category: editingTask.category || 'youtube',
          targetUrl: editingTask.targetUrl || 'https://google.com',
          rewardBdt: Number(editingTask.rewardPoisha ? editingTask.rewardPoisha / 100 : 2),
          durationSeconds: editingTask.durationSeconds || 15,
          adCountdownSeconds: editingTask.adCountdownSeconds || 10,
          dailyLimit: editingTask.dailyLimit || 1,
        });
        showToast('Task created successfully', 'success');
      }
      setIsTaskModalOpen(false);
      setEditingTask(null);
      loadTabContent('tasks');
    } catch (err: any) {
      showToast(err.message || 'Failed to save task', 'error');
    }
  };

  // Handle Delete Task
  const handleDeleteTask = async (taskId: string) => {
    if (!confirm('Are you sure you want to delete this task?')) return;
    try {
      await api.adminDeleteTask(taskId);
      showToast('Task deleted', 'info');
      loadTabContent('tasks');
    } catch (err: any) {
      showToast(err.message || 'Failed to delete task', 'error');
    }
  };

  // Handle Balance Adjustment
  const handleConfirmBalanceAdjustment = async () => {
    if (!selectedUserForAdjustment || !adjustAmountBdt || !adjustReason) return;
    try {
      triggerHaptic('medium');
      const res = await api.adminAdjustBalance({
        telegramId: selectedUserForAdjustment.telegramId,
        amountBdt: Number(adjustAmountBdt),
        reason: adjustReason,
        operation: adjustOperation,
      });

      if (res.success) {
        showToast(res.message, 'success');
        setSelectedUserForAdjustment(null);
        setAdjustAmountBdt('');
        setAdjustReason('');
        loadTabContent('users');
      }
    } catch (err: any) {
      showToast(err.message || 'Adjustment failed', 'error');
    }
  };

  // Handle Toggle Block
  const handleToggleBlock = async (user: User) => {
    const action = user.isBlocked ? 'unblock' : 'block';
    if (!confirm(`Are you sure you want to ${action} user @${user.username}?`)) return;
    try {
      const res = await api.adminToggleBlock(user.telegramId, 'Admin manual action');
      if (res.success) {
        showToast(`User ${action}ed successfully`, 'info');
        loadTabContent('users');
      }
    } catch (err: any) {
      showToast(err.message || 'Toggle failed', 'error');
    }
  };

  // Handle Save Settings
  const handleSaveSettings = async (updates: Partial<AppSettings>) => {
    try {
      triggerHaptic('medium');
      const res = await api.adminUpdateSettings({ settings: updates });
      if (res.success) {
        setAdminSettings(res.settings);
        showToast('Settings saved to central database', 'success');
        await refreshSettings();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to save settings', 'error');
    }
  };

  // Video Ad Management Handlers
  const handleCreateVideoAd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAdTitle.trim()) return;
    try {
      triggerHaptic('medium');
      const res = await api.adminCreateVideoAd({
        title: newAdTitle.trim(),
        rewardBdt: parseFloat(newAdRewardBdt || '1'),
        durationSeconds: parseInt(newAdDuration || '15', 10),
        dailyLimit: parseInt(newAdDailyLimit || '10', 10),
        videoUrl: newAdUrl.trim() || undefined,
      });
      if (res.success) {
        showToast('Video ad added successfully', 'success');
        setIsVideoAdModalOpen(false);
        setNewAdTitle('');
        setNewAdRewardBdt('1.00');
        setNewAdDuration('15');
        setNewAdDailyLimit('10');
        setNewAdUrl('');
        const fresh = await api.adminGetVideoAds();
        if (fresh.success) setVideoAdsList(fresh.ads);
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to create video ad', 'error');
    }
  };

  const handleDeleteVideoAd = async (id: string) => {
    if (!confirm('Are you sure you want to delete this video ad? Users will no longer see it.')) return;
    try {
      triggerHaptic('medium');
      const res = await api.adminDeleteVideoAd(id);
      if (res.success) {
        showToast('Video ad deleted', 'success');
        setVideoAdsList((prev) => prev.filter((a) => a.id !== id));
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to delete video ad', 'error');
    }
  };

  const handleToggleVideoAdActive = async (ad: VideoAd) => {
    try {
      triggerHaptic('light');
      const res = await api.adminUpdateVideoAd(ad.id, { isActive: !ad.isActive });
      if (res.success) {
        showToast(`Ad status updated: ${!ad.isActive ? 'Active' : 'Paused'}`, 'info');
        setVideoAdsList((prev) =>
          prev.map((a) => (a.id === ad.id ? { ...a, isActive: !a.isActive } : a))
        );
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to update ad', 'error');
    }
  };

  // Download DB Backup
  const handleDownloadBackup = () => {
    window.open('/api/admin/backup', '_blank');
  };

  // Restore DB from file
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        const res = await api.adminRestoreBackup(json);
        if (res.success) {
          showToast('Database restored successfully from backup JSON', 'success');
          loadTabContent(currentTab);
        }
      } catch (err) {
        showToast('Invalid backup file JSON', 'error');
      }
    };
    reader.readAsText(file);
  };

  if (!isAdminOpen) return null;

  return (
    <div
      onClick={(e) => {
        if (e.target === e.currentTarget) handleCloseAdmin();
      }}
      className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/90 backdrop-blur-md animate-fadeIn"
    >
      <div className="w-full max-w-2xl h-[650px] bg-slate-900 border border-emerald-500/30 rounded-3xl flex flex-col shadow-2xl overflow-hidden">
        {/* Top Header */}
        <div className="bg-slate-850 px-5 py-3.5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-emerald-500 flex items-center justify-center text-slate-950 font-black shadow-md">
              <ShieldCheck className="w-5 h-5 text-slate-950" />
            </div>
            <div>
              <div className="flex items-center space-x-1.5">
                <h2 className="font-extrabold text-white text-sm">SmartCash BD Administration</h2>
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-950 text-amber-400 border border-amber-500/30 font-bold uppercase">
                  Server Verified
                </span>
              </div>
              <p className="text-[10px] text-slate-400">
                {adminUser ? `Logged in: ${adminUser.username} (${adminUser.role})` : 'Restricted Access'}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {adminUser && (
              <button
                onClick={handleCloseAdmin}
                className="text-[11px] font-semibold text-rose-400 hover:text-rose-300 bg-rose-950/50 px-2.5 py-1 rounded-lg border border-rose-500/30 transition"
              >
                Log Out
              </button>
            )}
            <button
              onClick={handleCloseAdmin}
              className="p-1 rounded-full bg-slate-800 text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Not Logged In -> Show Admin Login Form */}
        {!adminUser ? (
          <div className="flex-1 flex flex-col items-center justify-center p-6 text-center">
            <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center mb-4 shadow-inner">
              <Lock className="w-8 h-8" />
            </div>
            <h3 className="text-base font-extrabold text-white">Administrator Authentication</h3>
            <p className="text-xs text-slate-400 mt-1 max-w-xs mb-5">
              এডমিন প্যানেলে প্রবেশ করতে আপনার ইউজারনেম ও পাসওয়ার্ড প্রদান করুন।
            </p>

            <form onSubmit={handleLogin} className="w-full max-w-sm space-y-3.5 text-left">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">Username</label>
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="ইউজারনেম লিখুন (Enter Username)"
                  autoComplete="username"
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-none font-mono"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">Password</label>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="পাসওয়ার্ড লিখুন (Enter Password)"
                  autoComplete="current-password"
                  className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-none font-mono"
                />
              </div>

              {loginError && (
                <div className="p-2.5 rounded-xl bg-rose-950/80 border border-rose-500/40 text-rose-300 text-xs flex items-center space-x-1.5">
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>{loginError}</span>
                </div>
              )}

              <button
                type="submit"
                disabled={isLoggingIn}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-extrabold text-xs shadow-lg shadow-emerald-500/20 transition active:scale-95"
              >
                {isLoggingIn ? 'যাচাই করা হচ্ছে...' : 'লগইন করুন (Sign In)'}
              </button>
            </form>
          </div>
        ) : (
          /* Logged In -> Full Admin Portal */
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Admin Nav Tabs */}
            <div className="bg-slate-950 px-3 py-1.5 border-b border-slate-800 flex items-center space-x-1 overflow-x-auto scrollbar-none text-xs">
              {[
                { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-3.5 h-3.5" /> },
                { id: 'withdrawals', label: 'Withdrawals', icon: <Wallet className="w-3.5 h-3.5" /> },
                { id: 'tasks', label: 'Tasks', icon: <CheckSquare className="w-3.5 h-3.5" /> },
                { id: 'users', label: 'Users', icon: <Users className="w-3.5 h-3.5" /> },
                { id: 'rewards', label: 'Reward Rules', icon: <Settings className="w-3.5 h-3.5" /> },
                { id: 'ads', label: 'Ad Placements', icon: <Tv className="w-3.5 h-3.5" /> },
                { id: 'global', label: 'Global Config', icon: <Settings className="w-3.5 h-3.5" /> },
                { id: 'security', label: 'Security & Access', icon: <Lock className="w-3.5 h-3.5" /> },
                { id: 'audit', label: 'Audit Trail', icon: <FileText className="w-3.5 h-3.5" /> },
                { id: 'backup', label: 'Backups', icon: <Download className="w-3.5 h-3.5" /> },
              ].map((t) => (
                <button
                  key={t.id}
                  onClick={() => {
                    triggerHaptic('light');
                    setCurrentTab(t.id as AdminTab);
                  }}
                  className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg whitespace-nowrap font-medium transition ${
                    currentTab === t.id
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/40 font-bold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {t.icon}
                  <span>{t.label}</span>
                </button>
              ))}
            </div>

            {/* Admin Tab View Area */}
            <div className="flex-1 p-4 overflow-y-auto bg-slate-900/60 text-xs">
              {loading ? (
                <div className="py-16 text-center text-slate-500">Loading admin data...</div>
              ) : (
                <>
                  {/* TAB 1: DASHBOARD */}
                  {currentTab === 'dashboard' && stats && (
                    <div className="space-y-4">
                      <div className="grid grid-cols-3 gap-3">
                        <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800">
                          <span className="text-[10px] text-slate-400 block font-medium">Total Registered Users</span>
                          <span className="text-xl font-extrabold text-white">{stats.totalUsers}</span>
                          <span className="text-[10px] text-emerald-400 block mt-0.5">{stats.activeUsers24h} active in 24h</span>
                        </div>
                        <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800">
                          <span className="text-[10px] text-slate-400 block font-medium">Linked Telegram Accounts</span>
                          <span className="text-xl font-extrabold text-blue-400">{stats.linkedTelegramAccounts}</span>
                          <span className="text-[10px] text-slate-400 block mt-0.5">100% verified IDs</span>
                        </div>
                        <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800">
                          <span className="text-[10px] text-slate-400 block font-medium">Completed Tasks</span>
                          <span className="text-xl font-extrabold text-teal-400">{stats.completedTasks}</span>
                          <span className="text-[10px] text-slate-400 block mt-0.5">Verified on backend</span>
                        </div>
                        <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800">
                          <span className="text-[10px] text-slate-400 block font-medium">Total Rewards Issued</span>
                          <span className="text-xl font-extrabold text-emerald-400">৳{stats.totalRewardsIssuedBdt}</span>
                          <span className="text-[10px] text-slate-400 block mt-0.5">BDT in Circulation</span>
                        </div>
                        <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800">
                          <span className="text-[10px] text-slate-400 block font-medium">Pending Payouts</span>
                          <span className="text-xl font-extrabold text-amber-400">{stats.pendingWithdrawalsCount}</span>
                          <span className="text-[10px] text-amber-300 block mt-0.5">৳{stats.pendingWithdrawAmountBdt} BDT</span>
                        </div>
                        <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800">
                          <span className="text-[10px] text-slate-400 block font-medium">Paid Withdrawals</span>
                          <span className="text-xl font-extrabold text-purple-400">{stats.paidWithdrawalsCount}</span>
                          <span className="text-[10px] text-purple-300 block mt-0.5">৳{stats.paidWithdrawAmountBdt} BDT</span>
                        </div>
                      </div>

                      <div className="p-3.5 rounded-2xl bg-emerald-950/30 border border-emerald-500/30 flex items-center justify-between">
                        <div>
                          <h4 className="font-bold text-emerald-300">Telegram Bot Integration Health</h4>
                          <p className="text-[11px] text-slate-400">
                            Bot: <strong>@smartcashbd_bot</strong> • Webhook active & receiving updates.
                          </p>
                        </div>
                        <button
                          onClick={() => loadTabContent('dashboard')}
                          className="px-3 py-1.5 rounded-xl bg-emerald-500 text-slate-950 font-bold text-xs"
                        >
                          Refresh Stats
                        </button>
                      </div>
                    </div>
                  )}

                  {/* TAB 2: WITHDRAWALS */}
                  {currentTab === 'withdrawals' && (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <h3 className="font-bold text-white">bKash & Nagad Withdrawal Requests</h3>
                        <span className="text-[11px] text-slate-400">{withdrawals.length} Total</span>
                      </div>

                      {withdrawals.length === 0 ? (
                        <div className="py-12 text-center text-slate-500">No withdrawal requests found.</div>
                      ) : (
                        <div className="space-y-2">
                          {withdrawals.map((w) => {
                            const amt = (w.amountPoisha / 100).toFixed(2);
                            const net = (w.netAmountPoisha / 100).toFixed(2);
                            return (
                              <div
                                key={w.id}
                                className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-2"
                              >
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center space-x-2">
                                    <span
                                      className={`px-2 py-0.5 rounded text-[10px] font-black ${
                                        w.method === 'bKash'
                                          ? 'bg-pink-950 text-pink-400 border border-pink-500/30'
                                          : w.method === 'Rocket'
                                          ? 'bg-purple-950 text-purple-400 border border-purple-500/30'
                                          : 'bg-orange-950 text-orange-400 border border-orange-500/30'
                                      }`}
                                    >
                                      {w.method} ({w.accountType})
                                    </span>
                                    <span className="font-mono text-white font-bold">{w.accountNumber}</span>
                                    <span className="text-slate-400">({w.userName})</span>
                                  </div>

                                  <span
                                    className={`px-2 py-0.5 rounded text-[10px] font-extrabold uppercase ${
                                      w.status === 'Paid'
                                        ? 'bg-emerald-950 text-emerald-400'
                                        : w.status === 'Approved'
                                        ? 'bg-blue-950 text-blue-400'
                                        : w.status === 'Rejected'
                                        ? 'bg-rose-950 text-rose-400'
                                        : 'bg-amber-950 text-amber-400'
                                    }`}
                                  >
                                    {w.status}
                                  </span>
                                </div>

                                <div className="flex items-center justify-between text-slate-400 text-[11px]">
                                  <span>Amount: <strong>৳{amt}</strong> • Net Payout: <strong className="text-emerald-400">৳{net} BDT</strong></span>
                                  <span>{new Date(w.createdAt).toLocaleString()}</span>
                                </div>

                                {w.payoutReference && (
                                  <div className="text-[10px] font-mono text-emerald-300">
                                    Payment Reference: {w.payoutReference}
                                  </div>
                                )}

                                {w.status === 'Pending' && (
                                  <div className="pt-2 border-t border-slate-800/80 flex items-center justify-end space-x-2">
                                    <button
                                      onClick={() => {
                                        setSelectedWithdrawal(w);
                                        setActionType('Approve');
                                      }}
                                      className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-[10px]"
                                    >
                                      Approve
                                    </button>
                                    <button
                                      onClick={() => {
                                        setSelectedWithdrawal(w);
                                        setActionType('Paid');
                                      }}
                                      className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[10px]"
                                    >
                                      Mark Paid
                                    </button>
                                    <button
                                      onClick={() => {
                                        setSelectedWithdrawal(w);
                                        setActionType('Reject');
                                      }}
                                      className="px-2.5 py-1 rounded-lg bg-rose-900 hover:bg-rose-800 text-rose-200 font-bold text-[10px]"
                                    >
                                      Reject & Refund
                                    </button>
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  )}

                  {/* TAB 3: TASKS */}
                  {currentTab === 'tasks' && (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <h3 className="font-bold text-white">Task Marketplace Items</h3>
                        <button
                          onClick={() => {
                            setEditingTask({
                              category: 'youtube',
                              rewardPoisha: 200,
                              durationSeconds: 15,
                              adCountdownSeconds: 10,
                              dailyLimit: 1,
                              isActive: true,
                            });
                            setIsTaskModalOpen(true);
                          }}
                          className="flex items-center space-x-1 px-3 py-1.5 rounded-xl bg-emerald-500 text-slate-950 font-bold text-xs"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>Add New Task</span>
                        </button>
                      </div>

                      <div className="space-y-2">
                        {tasks.map((t) => (
                          <div
                            key={t.id}
                            className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800 flex items-center justify-between"
                          >
                            <div className="flex-1 pr-3">
                              <div className="flex items-center space-x-2">
                                <span className="px-1.5 py-0.2 rounded text-[9px] font-bold uppercase bg-slate-800 text-slate-300">
                                  {t.category}
                                </span>
                                <span className={`px-1.5 py-0.2 rounded text-[9px] font-bold ${t.isActive ? 'bg-emerald-950 text-emerald-400' : 'bg-rose-950 text-rose-400'}`}>
                                  {t.isActive ? 'Active' : 'Disabled'}
                                </span>
                              </div>
                              <h4 className="font-bold text-white text-xs mt-1">{t.title}</h4>
                              <p className="text-[10px] text-slate-400">
                                Reward: ৳{(t.rewardPoisha / 100).toFixed(2)} • Timer: {t.durationSeconds}s • Ad: {t.adCountdownSeconds}s
                              </p>
                            </div>

                            <div className="flex items-center space-x-1.5">
                              <button
                                onClick={() => {
                                  setEditingTask(t);
                                  setIsTaskModalOpen(true);
                                }}
                                className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleDeleteTask(t.id)}
                                className="p-1.5 rounded-lg bg-rose-950 text-rose-400 hover:text-rose-300"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* TAB 4: USERS */}
                  {currentTab === 'users' && (
                    <div className="space-y-3">
                      <div className="flex items-center space-x-2">
                        <div className="relative flex-1">
                          <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
                          <input
                            type="text"
                            placeholder="Search by Telegram ID, username, or referral code..."
                            value={userSearch}
                            onChange={(e) => setUserSearch(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && loadTabContent('users')}
                            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-2 text-xs text-white placeholder-slate-600 focus:outline-none"
                          />
                        </div>
                        <button
                          onClick={() => loadTabContent('users')}
                          className="px-3 py-2 rounded-xl bg-slate-800 text-slate-200 text-xs font-bold"
                        >
                          Search
                        </button>
                      </div>

                      <div className="space-y-2">
                        {usersList.map((u) => {
                          const bal = (u.balancePoisha / 100).toFixed(2);
                          return (
                            <div
                              key={u.telegramId}
                              className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800 flex items-center justify-between"
                            >
                              <div>
                                <div className="flex items-center space-x-2">
                                  <span className="font-bold text-white">{u.firstName} {u.lastName}</span>
                                  <span className="text-[11px] text-slate-400 font-mono">@{u.username}</span>
                                  {u.isBlocked && (
                                    <span className="px-1.5 py-0.2 rounded bg-rose-950 text-rose-400 font-bold text-[9px]">
                                      Blocked
                                    </span>
                                  )}
                                </div>
                                <div className="text-[10px] text-slate-400 mt-0.5 space-x-2">
                                  <span>TG ID: <strong className="text-slate-300">{u.telegramId}</strong></span>
                                  <span>Ref Code: <strong className="text-emerald-400">{u.referralCode}</strong></span>
                                  <span>Referrals: <strong>{u.referralsCount}</strong></span>
                                </div>
                              </div>

                              <div className="flex items-center space-x-2 text-right">
                                <div>
                                  <span className="text-sm font-black text-emerald-400 block">৳{bal}</span>
                                  <span className="text-[9px] text-slate-500">Available</span>
                                </div>
                                <button
                                  onClick={() => setSelectedUserForAdjustment(u)}
                                  className="px-2 py-1 rounded-lg bg-emerald-950 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold"
                                >
                                  Adjust ৳
                                </button>
                                <button
                                  onClick={() => handleToggleBlock(u)}
                                  className={`px-2 py-1 rounded-lg text-[10px] font-bold ${
                                    u.isBlocked
                                      ? 'bg-emerald-900 text-emerald-200'
                                      : 'bg-rose-950 text-rose-400 border border-rose-500/30'
                                  }`}
                                >
                                  {u.isBlocked ? 'Unblock' : 'Block'}
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* TAB 5: REWARD RULES */}
                  {currentTab === 'rewards' && adminSettings && (
                    <div className="space-y-4">
                      <h3 className="font-bold text-white">Central Reward & Commission Configuration</h3>

                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <label className="text-[11px] text-slate-400">Referral Reward (BDT)</label>
                          <input
                            type="number"
                            value={adminSettings.referralRewardPoisha / 100}
                            onChange={(e) =>
                              setAdminSettings({
                                ...adminSettings,
                                referralRewardPoisha: Math.round(Number(e.target.value) * 100),
                              })
                            }
                            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-bold"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[11px] text-slate-400">Video Ad Reward (BDT)</label>
                          <input
                            type="number"
                            value={adminSettings.adRewardPoisha / 100}
                            onChange={(e) =>
                              setAdminSettings({
                                ...adminSettings,
                                adRewardPoisha: Math.round(Number(e.target.value) * 100),
                              })
                            }
                            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-bold"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[11px] text-slate-400">Minimum Withdrawal (BDT)</label>
                          <input
                            type="number"
                            value={adminSettings.minWithdrawalPoisha / 100}
                            onChange={(e) =>
                              setAdminSettings({
                                ...adminSettings,
                                minWithdrawalPoisha: Math.round(Number(e.target.value) * 100),
                              })
                            }
                            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-bold"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[11px] text-slate-400">Withdrawal Gateway Fee (%)</label>
                          <input
                            type="number"
                            value={adminSettings.withdrawalFeePercent}
                            onChange={(e) =>
                              setAdminSettings({
                                ...adminSettings,
                                withdrawalFeePercent: Number(e.target.value),
                              })
                            }
                            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-bold"
                          />
                        </div>
                      </div>

                      <button
                        onClick={() => handleSaveSettings(adminSettings)}
                        className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs"
                      >
                        Save Reward Configuration
                      </button>
                    </div>
                  )}

                  {/* TAB 6: VIDEO ADS MANAGER */}
                  {currentTab === 'ads' && adminSettings && (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-bold text-white text-sm">ভিডিও অ্যাড পরিচালনা (Video Ads Manager)</h3>
                          <p className="text-[11px] text-slate-400">
                            যত ইচ্ছা তত ভিডিও অ্যাড তৈরি ও মুছে ফেলার সম্পূর্ণ নিয়ন্ত্রণ
                          </p>
                        </div>
                        <button
                          onClick={() => setIsVideoAdModalOpen(!isVideoAdModalOpen)}
                          className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-md shadow-emerald-500/20 transition cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>{isVideoAdModalOpen ? 'Cancel' : '+ নতুন অ্যাড যোগ করুন'}</span>
                        </button>
                      </div>

                      {/* Add Video Ad Form Modal/Inline */}
                      {isVideoAdModalOpen && (
                        <form
                          onSubmit={handleCreateVideoAd}
                          className="bg-slate-950/90 border border-emerald-500/40 rounded-2xl p-4 space-y-3 shadow-xl"
                        >
                          <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center space-x-1">
                            <Plus className="w-3.5 h-3.5" />
                            <span>নতুন ভিডিও অ্যাড তৈরি করুন (New Video Ad)</span>
                          </h4>

                          <div className="space-y-1">
                            <label className="text-[11px] text-slate-300">অ্যাড শিরোনাম (Ad Title) *</label>
                            <input
                              type="text"
                              required
                              placeholder="e.g. Sponsor Video Ad #1"
                              value={newAdTitle}
                              onChange={(e) => setNewAdTitle(e.target.value)}
                              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                            />
                          </div>

                          <div className="grid grid-cols-3 gap-2.5">
                            <div className="space-y-1">
                              <label className="text-[11px] text-slate-300">রিওয়ার্ড (BDT ৳) *</label>
                              <input
                                type="number"
                                step="0.1"
                                min="0.1"
                                required
                                value={newAdRewardBdt}
                                onChange={(e) => setNewAdRewardBdt(e.target.value)}
                                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-bold focus:outline-none focus:border-emerald-500"
                              />
                            </div>
                            <div className="space-y-1">
                              <label className="text-[11px] text-slate-300">সময় (সেকেন্ড) *</label>
                              <input
                                type="number"
                                min="5"
                                max="180"
                                required
                                value={newAdDuration}
                                onChange={(e) => setNewAdDuration(e.target.value)}
                                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-bold focus:outline-none focus:border-emerald-500"
                              />
                            </div>
                            <div className="space-y-1">
                              <label className="text-[11px] text-slate-300">দৈনিক লিমিট *</label>
                              <input
                                type="number"
                                min="1"
                                max="100"
                                required
                                value={newAdDailyLimit}
                                onChange={(e) => setNewAdDailyLimit(e.target.value)}
                                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-bold focus:outline-none focus:border-emerald-500"
                              />
                            </div>
                          </div>

                          <div className="space-y-1">
                            <label className="text-[11px] text-slate-300">ভিডিও URL (ঐচ্ছিক / Optional)</label>
                            <input
                              type="url"
                              placeholder="https://... (mp4 or stream link)"
                              value={newAdUrl}
                              onChange={(e) => setNewAdUrl(e.target.value)}
                              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                            />
                          </div>

                          <div className="flex justify-end space-x-2 pt-1">
                            <button
                              type="button"
                              onClick={() => setIsVideoAdModalOpen(false)}
                              className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-700 cursor-pointer"
                            >
                              বাতিল (Cancel)
                            </button>
                            <button
                              type="submit"
                              className="px-4 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold shadow-md cursor-pointer"
                            >
                              অ্যাড সেভ করুন (Add Ad)
                            </button>
                          </div>
                        </form>
                      )}

                      {/* Video Ads List */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-xs text-slate-400">
                          <span>মোট সক্রিয় অ্যাড: {videoAdsList.length} টি</span>
                        </div>

                        {videoAdsList.length === 0 ? (
                          <div className="text-center py-6 bg-slate-950/40 rounded-xl border border-slate-800 text-xs text-slate-500">
                            কোনো ভিডিও অ্যাড যোগ করা হয়নি। উপরের বাটনে ক্লিক করে নতুন অ্যাড তৈরি করুন।
                          </div>
                        ) : (
                          <div className="space-y-2">
                            {videoAdsList.map((ad) => (
                              <div
                                key={ad.id}
                                className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3 flex items-center justify-between hover:border-slate-700 transition"
                              >
                                <div className="space-y-1">
                                  <div className="flex items-center space-x-2">
                                    <span className="font-bold text-white text-xs">{ad.title}</span>
                                    <span
                                      className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                                        ad.isActive
                                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30'
                                          : 'bg-slate-800 text-slate-400'
                                      }`}
                                    >
                                      {ad.isActive ? 'সক্রিয় (Active)' : 'বন্ধ (Paused)'}
                                    </span>
                                  </div>
                                  <div className="flex items-center space-x-3 text-[10px] text-slate-400">
                                    <span className="text-emerald-400 font-semibold font-mono">
                                      ৳{(ad.rewardPoisha / 100).toFixed(2)} BDT
                                    </span>
                                    <span>• {ad.durationSeconds}s প্লে</span>
                                    <span>• দৈনিক {ad.dailyLimit} বার</span>
                                  </div>
                                </div>

                                <div className="flex items-center space-x-1.5">
                                  <button
                                    onClick={() => handleToggleVideoAdActive(ad)}
                                    title={ad.isActive ? 'Pause Ad' : 'Activate Ad'}
                                    className={`p-2 rounded-lg text-xs transition cursor-pointer ${
                                      ad.isActive
                                        ? 'bg-amber-950/70 text-amber-300 hover:bg-amber-900 border border-amber-500/30'
                                        : 'bg-emerald-950/70 text-emerald-300 hover:bg-emerald-900 border border-emerald-500/30'
                                    }`}
                                  >
                                    {ad.isActive ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                                  </button>
                                  <button
                                    onClick={() => handleDeleteVideoAd(ad.id)}
                                    title="Delete Ad"
                                    className="p-2 rounded-lg bg-rose-950/60 hover:bg-rose-900 text-rose-300 border border-rose-500/30 text-xs transition cursor-pointer"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* General Video Ads Configuration */}
                      <div className="pt-3 border-t border-slate-800 space-y-3">
                        <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                          সার্বজনীন অ্যাড সেটিংস (General Ad Rules)
                        </h4>

                        <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-1">
                            <label className="text-[11px] text-slate-400">ইউজার প্রতি মোট দৈনিক লিমিট</label>
                            <input
                              type="number"
                              value={adminSettings.dailyAdLimit}
                              onChange={(e) =>
                                setAdminSettings({ ...adminSettings, dailyAdLimit: Number(e.target.value) })
                              }
                              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-bold"
                            />
                          </div>

                          <div className="space-y-1">
                            <label className="text-[11px] text-slate-400">অ্যাড কুলডাউন (সেকেন্ড)</label>
                            <input
                              type="number"
                              value={adminSettings.adCooldownSeconds}
                              onChange={(e) =>
                                setAdminSettings({
                                  ...adminSettings,
                                  adCooldownSeconds: Number(e.target.value),
                                })
                              }
                              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-bold"
                            />
                          </div>
                        </div>

                        <div className="flex items-center space-x-2 pt-1">
                          <input
                            type="checkbox"
                            id="ads_enabled"
                            checked={adminSettings.adsEnabled}
                            onChange={(e) =>
                              setAdminSettings({ ...adminSettings, adsEnabled: e.target.checked })
                            }
                            className="w-4 h-4 rounded text-emerald-500 cursor-pointer"
                          />
                          <label htmlFor="ads_enabled" className="text-xs text-slate-200 font-semibold cursor-pointer">
                            ভিডিও অ্যাড সিস্টেম চালু রাখুন (Enable Video Ads Platform)
                          </label>
                        </div>

                        <button
                          onClick={() => handleSaveSettings(adminSettings)}
                          className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs cursor-pointer shadow-md transition"
                        >
                          সেটিংস সেভ করুন (Save Ad Rules)
                        </button>
                      </div>
                    </div>
                  )}

                  {/* TAB 7: GLOBAL CONFIG */}
                  {currentTab === 'global' && adminSettings && (
                    <div className="space-y-4">
                      <h3 className="font-bold text-white text-sm">সাপোর্ট ও গ্লোবাল কনফিগারেশন (Support & Global Settings)</h3>

                      <div className="space-y-3">
                        <div className="space-y-1">
                          <label className="text-[11px] text-slate-400">অ্যাপ্লিকেশনের নাম (App Name)</label>
                          <input
                            type="text"
                            value={adminSettings.appName}
                            onChange={(e) =>
                              setAdminSettings({ ...adminSettings, appName: e.target.value })
                            }
                            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                          />
                        </div>

                        {/* Support Channels Configuration as requested */}
                        <div className="p-3 bg-emerald-950/20 border border-emerald-500/30 rounded-xl space-y-3">
                          <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
                            সাপোর্ট লিঙ্ক ও আইডি সেটআপ (Support Channels Setup)
                          </h4>

                          <div className="space-y-1">
                            <label className="text-[11px] text-slate-300">
                              হোয়াটসঅ্যাপ সাপোর্ট লিঙ্ক / নম্বর (WhatsApp Support Link or Phone)
                            </label>
                            <input
                              type="text"
                              placeholder="e.g. +8801700000000 or https://wa.me/8801700000000"
                              value={adminSettings.whatsappSupport || ''}
                              onChange={(e) =>
                                setAdminSettings({ ...adminSettings, whatsappSupport: e.target.value })
                              }
                              className="w-full bg-slate-950 border border-slate-750 rounded-xl px-3 py-2 text-white font-mono text-xs"
                            />
                            <p className="text-[10px] text-slate-400">
                              ইউজার সাপোর্ট পেজে WhatsApp এ ট্যাপ করলে এই নম্বরে সরাসরি চ্যাট ওপেন হবে।
                            </p>
                          </div>

                          <div className="space-y-1">
                            <label className="text-[11px] text-slate-300">
                              ইমো সাপোর্ট আইডি / নম্বর (IMO Support Number or ID)
                            </label>
                            <input
                              type="text"
                              placeholder="e.g. +8801700000000 or imo id"
                              value={adminSettings.imoSupport || ''}
                              onChange={(e) =>
                                setAdminSettings({ ...adminSettings, imoSupport: e.target.value })
                              }
                              className="w-full bg-slate-950 border border-slate-750 rounded-xl px-3 py-2 text-white font-mono text-xs"
                            />
                            <p className="text-[10px] text-slate-400">
                              IMO সাপোর্ট নম্বরে ইউজার সরাসরি যোগাযোগ করতে পারবে।
                            </p>
                          </div>

                          <div className="space-y-1">
                            <label className="text-[11px] text-slate-300">
                              অফিসিয়াল টেলিগ্রাম চ্যানেল লিঙ্ক (Official Telegram Channel Link)
                            </label>
                            <input
                              type="text"
                              placeholder="e.g. https://t.me/smartcashbd_channel or @smartcashbd_channel"
                              value={adminSettings.telegramChannel || ''}
                              onChange={(e) =>
                                setAdminSettings({ ...adminSettings, telegramChannel: e.target.value })
                              }
                              className="w-full bg-slate-950 border border-slate-750 rounded-xl px-3 py-2 text-white font-mono text-xs"
                            />
                            <p className="text-[10px] text-slate-400">
                              ইউজার টেলিগ্রাম চ্যানেল অপশনে চাপ দিলে এই চ্যানেলে নিয়ে যাবে।
                            </p>
                          </div>
                        </div>

                        <div className="space-y-1">
                          <label className="text-[11px] text-slate-400">টেলিগ্রাম বট ইউজারনেম (Telegram Bot)</label>
                          <input
                            type="text"
                            value={adminSettings.telegramBotUsername}
                            onChange={(e) =>
                              setAdminSettings({ ...adminSettings, telegramBotUsername: e.target.value })
                            }
                            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono text-xs"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[11px] text-slate-400">টেলিগ্রাম সাপোর্ট ইউজারনেম (Telegram Support Username)</label>
                          <input
                            type="text"
                            value={adminSettings.supportTelegram}
                            onChange={(e) =>
                              setAdminSettings({ ...adminSettings, supportTelegram: e.target.value })
                            }
                            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono text-xs"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[11px] text-slate-400">ঘোষণা ব্যানার লেখা (Announcement Banner Text)</label>
                          <textarea
                            rows={2}
                            value={adminSettings.announcementText}
                            onChange={(e) =>
                              setAdminSettings({ ...adminSettings, announcementText: e.target.value })
                            }
                            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white text-xs"
                          />
                        </div>

                        <div className="flex items-center space-x-2 pt-1">
                          <input
                            type="checkbox"
                            id="maintenance_mode"
                            checked={adminSettings.maintenanceMode}
                            onChange={(e) =>
                              setAdminSettings({ ...adminSettings, maintenanceMode: e.target.checked })
                            }
                            className="w-4 h-4 rounded text-rose-500 cursor-pointer"
                          />
                          <label htmlFor="maintenance_mode" className="text-xs text-rose-300 font-semibold cursor-pointer">
                            রক্ষণাবেক্ষণ মোড (Maintenance Mode)
                          </label>
                        </div>
                      </div>

                      <button
                        onClick={() => handleSaveSettings(adminSettings)}
                        className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs cursor-pointer shadow-md transition"
                      >
                        সকল সেটিংস সংরক্ষণ করুন (Save All Settings)
                      </button>
                    </div>
                  )}

                  {/* TAB: SECURITY & CREDENTIALS (USERNAME & PASSWORD CHANGE) */}
                  {currentTab === 'security' && (
                    <div className="space-y-4">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div>
                          <h3 className="font-extrabold text-white text-sm">
                            এডমিন সিকিউরিটি ও ক্রেডেনশিয়াল (Admin Security & Credentials)
                          </h3>
                          <p className="text-[11px] text-slate-400 mt-0.5">
                            এডমিন প্যানেলে প্রবেশ করার ইউজারনেম ও পাসওয়ার্ড নিরাপদভাবে এখান থেকে পরিবর্তন করুন।
                          </p>
                        </div>
                        <div className="flex items-center space-x-2 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs shrink-0 self-start sm:self-auto">
                          <span className="text-slate-400 text-[11px]">বর্তমান ইউজার:</span>
                          <span className="font-mono font-bold text-emerald-400 text-xs">
                            {adminUser?.username || 'Admin'}
                          </span>
                        </div>
                      </div>

                      <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-4">
                        <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-start space-x-2.5">
                          <Lock className="w-4 h-4 mt-0.5 shrink-0 text-amber-400" />
                          <div className="text-[11px] leading-relaxed">
                            <span className="font-bold text-amber-200">নিরাপত্তা নীতিমালা:</span> এডমিন প্যানেলে প্রবেশ করার সময় প্রতিবার পাসওয়ার্ড দিয়ে প্রবেশ করতে হবে। ইউজারনেম বা পাসওয়ার্ড পরিবর্তন করতে চাইলে আপনার বর্তমান পাসওয়ার্ড প্রদান করে নিচের ফর্মটি পূরণ করুন।
                          </div>
                        </div>

                        <form onSubmit={handleUpdateCredentials} className="space-y-4">
                          <div>
                            <label className="text-xs font-semibold text-slate-200 block mb-1">
                              বর্তমান পাসওয়ার্ড (Current Password) <span className="text-rose-400">*</span>
                            </label>
                            <input
                              type="password"
                              required
                              value={currentAdminPassword}
                              onChange={(e) => setCurrentAdminPassword(e.target.value)}
                              placeholder="আপনার বর্তমান পাসওয়ার্ড প্রদান করুন"
                              autoComplete="current-password"
                              className="w-full bg-slate-900 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-none"
                            />
                            <p className="text-[10px] text-slate-500 mt-1">
                              ইউজারনেম বা পাসওয়ার্ড পরিবর্তনের জন্য বর্তমান পাসওয়ার্ড আবশ্যক
                            </p>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-1">
                            <div>
                              <label className="text-xs font-semibold text-slate-200 block mb-1">
                                নতুন ইউজারনেম (New Username)
                              </label>
                              <input
                                type="text"
                                value={newAdminUsername}
                                onChange={(e) => setNewAdminUsername(e.target.value)}
                                placeholder="নতুন ইউজারনেম (ঐচ্ছিক)"
                                autoComplete="off"
                                className="w-full bg-slate-900 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-none font-mono"
                              />
                              <p className="text-[10px] text-slate-500 mt-1">
                                পরিবর্তন না করতে চাইলে খালি রাখুন (কমপক্ষে ৩ অক্ষর)
                              </p>
                            </div>

                            <div>
                              <label className="text-xs font-semibold text-slate-200 block mb-1">
                                নতুন পাসওয়ার্ড (New Password)
                              </label>
                              <input
                                type="password"
                                value={newAdminPassword}
                                onChange={(e) => setNewAdminPassword(e.target.value)}
                                placeholder="নতুন পাসওয়ার্ড (ঐচ্ছিক)"
                                autoComplete="new-password"
                                className="w-full bg-slate-900 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-none"
                              />
                              <p className="text-[10px] text-slate-500 mt-1">
                                পরিবর্তন না করতে চাইলে খালি রাখুন (কমপক্ষে ৪ অক্ষর)
                              </p>
                            </div>
                          </div>

                          {newAdminPassword && (
                            <div>
                              <label className="text-xs font-semibold text-slate-200 block mb-1">
                                নতুন পাসওয়ার্ড নিশ্চিতকরণ (Confirm New Password) <span className="text-rose-400">*</span>
                              </label>
                              <input
                                type="password"
                                required={Boolean(newAdminPassword)}
                                value={confirmAdminPassword}
                                onChange={(e) => setConfirmAdminPassword(e.target.value)}
                                placeholder="নতুন পাসওয়ার্ডটি পুনরায় লিখুন"
                                autoComplete="new-password"
                                className="w-full bg-slate-900 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-none"
                              />
                            </div>
                          )}

                          <div className="pt-2 flex items-center space-x-3">
                            <button
                              type="submit"
                              disabled={isUpdatingCredentials}
                              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-extrabold text-xs shadow-lg shadow-emerald-500/20 transition active:scale-95 disabled:opacity-50 cursor-pointer"
                            >
                              {isUpdatingCredentials ? 'আপডেট হচ্ছে...' : 'ইউজারনেম ও পাসওয়ার্ড পরিবর্তন করুন (Save)'}
                            </button>
                            {(currentAdminPassword || newAdminUsername || newAdminPassword) && (
                              <button
                                type="button"
                                onClick={() => {
                                  setCurrentAdminPassword('');
                                  setNewAdminUsername('');
                                  setNewAdminPassword('');
                                  setConfirmAdminPassword('');
                                }}
                                className="px-3 py-2 text-xs text-slate-400 hover:text-white transition"
                              >
                                রিসেট
                              </button>
                            )}
                          </div>
                        </form>
                      </div>
                    </div>
                  )}

                  {/* TAB 8: AUDIT TRAIL */}
                  {currentTab === 'audit' && (
                    <div className="space-y-3">
                      <h3 className="font-bold text-white">Immutable Administrative Audit Log</h3>
                      <div className="space-y-2">
                        {auditLogs.map((log) => (
                          <div
                            key={log.id}
                            className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800 text-[11px]"
                          >
                            <div className="flex items-center justify-between">
                              <span className="font-extrabold text-amber-400">{log.action}</span>
                              <span className="text-[10px] text-slate-500">
                                {new Date(log.createdAt).toLocaleString()}
                              </span>
                            </div>
                            <p className="text-slate-300 mt-0.5">{log.details}</p>
                            <span className="text-[9px] text-slate-500">
                              By: <strong>{log.adminUsername}</strong> {log.ip ? `• IP: ${log.ip}` : ''}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* TAB 9: BACKUPS */}
                  {currentTab === 'backup' && (
                    <div className="space-y-4">
                      <h3 className="font-bold text-white">Permanent Database Backup & Recovery</h3>
                      <p className="text-slate-400 text-xs">
                        SmartCash BD persists all user balances, referrals, and withdrawal records in a durable store. You can export a snapshot anytime or restore from a JSON file.
                      </p>

                      <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                        <h4 className="font-bold text-slate-200">1. Download Full JSON Backup</h4>
                        <p className="text-[11px] text-slate-400">
                          Exports all collections: users, transactions, withdrawal requests, tasks, audit logs, and settings.
                        </p>
                        <button
                          onClick={handleDownloadBackup}
                          className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md"
                        >
                          <Download className="w-4 h-4" />
                          <span>Export Database JSON</span>
                        </button>
                      </div>

                      <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                        <h4 className="font-bold text-slate-200">2. Restore Database from JSON</h4>
                        <p className="text-[11px] text-slate-400">
                          Upload a previously exported SmartCash BD backup JSON file to restore the entire system.
                        </p>
                        <input
                          type="file"
                          accept=".json"
                          onChange={handleFileUpload}
                          className="text-xs text-slate-400 file:mr-3 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:bg-slate-800 file:text-white file:text-xs"
                        />
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        )}

        {/* Modal: Task Add/Edit */}
        {isTaskModalOpen && editingTask && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
            <div className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-3xl p-5 shadow-2xl space-y-3 text-xs">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <h4 className="font-bold text-white text-sm">
                  {editingTask.id ? 'Edit Task' : 'Create New Task'}
                </h4>
                <button onClick={() => setIsTaskModalOpen(false)} className="text-slate-400 hover:text-white">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleSaveTask} className="space-y-3">
                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Title</label>
                  <input
                    type="text"
                    required
                    value={editingTask.title || ''}
                    onChange={(e) => setEditingTask({ ...editingTask, title: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Category</label>
                  <select
                    value={editingTask.category || 'youtube'}
                    onChange={(e) => setEditingTask({ ...editingTask, category: e.target.value as any })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                  >
                    <option value="youtube">YouTube</option>
                    <option value="telegram">Telegram</option>
                    <option value="facebook">Facebook</option>
                    <option value="visit">Web Visit</option>
                  </select>
                </div>

                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Target URL</label>
                  <input
                    type="url"
                    required
                    value={editingTask.targetUrl || ''}
                    onChange={(e) => setEditingTask({ ...editingTask, targetUrl: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                  />
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="text-[10px] text-slate-400 block mb-1">Reward (BDT)</label>
                    <input
                      type="number"
                      step="0.5"
                      value={editingTask.rewardPoisha ? editingTask.rewardPoisha / 100 : 2}
                      onChange={(e) =>
                        setEditingTask({ ...editingTask, rewardPoisha: Math.round(Number(e.target.value) * 100) })
                      }
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-white font-bold"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400 block mb-1">Task Timer (s)</label>
                    <input
                      type="number"
                      value={editingTask.durationSeconds || 15}
                      onChange={(e) =>
                        setEditingTask({ ...editingTask, durationSeconds: Number(e.target.value) })
                      }
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-white font-bold"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400 block mb-1">Ad Countdown (s)</label>
                    <input
                      type="number"
                      value={editingTask.adCountdownSeconds || 10}
                      onChange={(e) =>
                        setEditingTask({ ...editingTask, adCountdownSeconds: Number(e.target.value) })
                      }
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-white font-bold"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Instructions</label>
                  <textarea
                    rows={2}
                    value={editingTask.instructions || ''}
                    onChange={(e) => setEditingTask({ ...editingTask, instructions: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="task_active"
                    checked={editingTask.isActive}
                    onChange={(e) => setEditingTask({ ...editingTask, isActive: e.target.checked })}
                    className="w-4 h-4 rounded text-emerald-500"
                  />
                  <label htmlFor="task_active" className="text-xs text-white font-semibold">
                    Task is Active & Visible
                  </label>
                </div>

                <div className="pt-2 flex justify-end space-x-2">
                  <button
                    type="button"
                    onClick={() => setIsTaskModalOpen(false)}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-400"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-xl bg-emerald-500 text-slate-950 font-bold"
                  >
                    Save Task
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Modal: User Balance Adjustment */}
        {selectedUserForAdjustment && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
            <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-3xl p-5 shadow-2xl space-y-3 text-xs">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <h4 className="font-bold text-white text-sm">
                  Adjust Balance: {selectedUserForAdjustment.firstName}
                </h4>
                <button
                  onClick={() => setSelectedUserForAdjustment(null)}
                  className="text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <button
                    type="button"
                    onClick={() => setAdjustOperation('credit')}
                    className={`flex-1 py-1.5 rounded-xl font-bold border transition ${
                      adjustOperation === 'credit'
                        ? 'bg-emerald-950 border-emerald-500 text-emerald-300'
                        : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    + Credit BDT
                  </button>
                  <button
                    type="button"
                    onClick={() => setAdjustOperation('debit')}
                    className={`flex-1 py-1.5 rounded-xl font-bold border transition ${
                      adjustOperation === 'debit'
                        ? 'bg-rose-950 border-rose-500 text-rose-300'
                        : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    - Debit BDT
                  </button>
                </div>

                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Amount in BDT (৳)</label>
                  <input
                    type="number"
                    step="0.5"
                    required
                    value={adjustAmountBdt}
                    onChange={(e) => setAdjustAmountBdt(e.target.value)}
                    placeholder="e.g. 50"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-bold"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Audit Reason (Required)</label>
                  <input
                    type="text"
                    required
                    value={adjustReason}
                    onChange={(e) => setAdjustReason(e.target.value)}
                    placeholder="e.g. Compensation for contest winner"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                  />
                </div>

                <div className="pt-2 flex justify-end space-x-2">
                  <button
                    type="button"
                    onClick={() => setSelectedUserForAdjustment(null)}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-400"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={handleConfirmBalanceAdjustment}
                    className="px-4 py-1.5 rounded-xl bg-emerald-500 text-slate-950 font-bold"
                  >
                    Apply Adjustment
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Modal: Withdrawal Action */}
        {selectedWithdrawal && actionType && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
            <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-3xl p-5 shadow-2xl space-y-3 text-xs">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <h4 className="font-bold text-white text-sm">
                  {actionType} Withdrawal (#{selectedWithdrawal.id})
                </h4>
                <button
                  onClick={() => {
                    setSelectedWithdrawal(null);
                    setActionType(null);
                  }}
                  className="text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <div>User: <strong>{selectedWithdrawal.userName}</strong></div>
                <div>Method: <strong>{selectedWithdrawal.method} ({selectedWithdrawal.accountType})</strong></div>
                <div>Account: <strong className="font-mono text-emerald-400">{selectedWithdrawal.accountNumber}</strong></div>
                <div>Amount: <strong className="text-white">৳{(selectedWithdrawal.amountPoisha / 100).toFixed(2)} BDT</strong></div>
              </div>

              {actionType === 'Paid' && (
                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">
                    bKash / Nagad TrxID Reference
                  </label>
                  <input
                    type="text"
                    required
                    value={payoutReference}
                    onChange={(e) => setPayoutReference(e.target.value)}
                    placeholder="e.g. 9J4K2L1M99"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
                  />
                </div>
              )}

              {actionType === 'Reject' && (
                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">
                    Rejection Reason (Refunds BDT back to user)
                  </label>
                  <input
                    type="text"
                    required
                    value={rejectionReason}
                    onChange={(e) => setRejectionReason(e.target.value)}
                    placeholder="e.g. Number inactive or fake activity detected"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white"
                  />
                </div>
              )}

              <div className="pt-2 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedWithdrawal(null);
                    setActionType(null);
                  }}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-400"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleConfirmWithdrawalAction}
                  className={`px-4 py-1.5 rounded-xl font-bold ${
                    actionType === 'Reject'
                      ? 'bg-rose-600 hover:bg-rose-500 text-white'
                      : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950'
                  }`}
                >
                  Confirm {actionType}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
