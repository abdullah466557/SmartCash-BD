import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Wallet, ShieldCheck, Bot, RefreshCw, Send, CheckCircle2 } from 'lucide-react';

export const Navbar: React.FC = () => {
  const { user, settings, setActiveTab, setIsAdminOpen, setIsSimulatorOpen, adminUser, refreshUser, triggerHaptic } = useApp();
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleManualRefresh = async () => {
    setIsRefreshing(true);
    triggerHaptic('light');
    await refreshUser();
    setTimeout(() => setIsRefreshing(false), 500);
  };

  const balanceBdt = user ? (user.balancePoisha / 100).toFixed(2) : '0.00';

  return (
    <header className="sticky top-0 z-40 w-full bg-slate-900/90 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-md mx-auto px-4 h-15 flex items-center justify-between">
        {/* Brand */}
        <div className="flex items-center space-x-2.5 cursor-pointer" onClick={() => setActiveTab('home')}>
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 via-emerald-500 to-teal-400 flex items-center justify-center shadow-lg shadow-emerald-500/20 text-white font-black text-lg">
            ৳
          </div>
          <div>
            <div className="flex items-center space-x-1">
              <span className="font-extrabold text-base tracking-tight text-white">SmartCash</span>
              <span className="text-emerald-400 font-extrabold text-sm px-1 py-0.2 rounded bg-emerald-950/80 border border-emerald-500/30">BD</span>
            </div>
            <div className="flex items-center text-[10px] text-slate-400 font-medium">
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse mr-1"></span>
              @smartcashbd_bot
            </div>
          </div>
        </div>

        {/* Right Action Controls */}
        <div className="flex items-center space-x-2">
          {/* Balance Pill */}
          <div
            onClick={() => setActiveTab('wallet')}
            className="flex items-center space-x-1.5 bg-gradient-to-r from-emerald-950/80 to-slate-900 px-3 py-1.5 rounded-full border border-emerald-500/40 text-emerald-300 font-bold text-xs shadow-inner cursor-pointer hover:border-emerald-400 transition"
          >
            <span className="text-emerald-400 font-black">৳</span>
            <span>{balanceBdt}</span>
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleManualRefresh();
              }}
              className="text-slate-400 hover:text-emerald-300 transition p-0.5 ml-0.5"
              title="Refresh Balance"
            >
              <RefreshCw className={`w-3 h-3 ${isRefreshing ? 'animate-spin text-emerald-400' : ''}`} />
            </button>
          </div>

          {/* Telegram Bot Simulator Launcher */}
          <button
            onClick={() => {
              triggerHaptic('medium');
              setIsSimulatorOpen(true);
            }}
            className="p-1.5 rounded-lg bg-blue-950/60 hover:bg-blue-900/70 border border-blue-500/30 text-blue-400 transition relative"
            title="Open Telegram Bot Chat Simulator"
          >
            <Bot className="w-4 h-4" />
            <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-blue-400 ring-2 ring-slate-900"></span>
          </button>

          {/* Admin Panel Launcher */}
          <button
            onClick={() => {
              triggerHaptic('medium');
              setIsAdminOpen(true);
            }}
            className={`p-1.5 rounded-lg border transition relative ${
              adminUser
                ? 'bg-amber-950/60 border-amber-500/50 text-amber-300'
                : 'bg-slate-800/80 border-slate-700 text-slate-400 hover:text-slate-200'
            }`}
            title="Admin Panel"
          >
            <ShieldCheck className="w-4 h-4" />
            {adminUser && (
              <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-amber-400 ring-2 ring-slate-900"></span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
