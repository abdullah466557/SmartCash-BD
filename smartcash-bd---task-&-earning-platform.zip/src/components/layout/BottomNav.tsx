import React from 'react';
import { useApp, NavTab } from '../../context/AppContext';
import { Home, Users, Headphones, Wallet, User as UserIcon } from 'lucide-react';

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab, t, triggerHaptic } = useApp();

  // Exactly 5 buttons in requested order:
  // Left: Support, Refer
  // Center: Home
  // Right: Wallet, Profile
  const navItems: { id: NavTab; label: string; icon: React.ReactNode; isCenter?: boolean; badge?: string }[] = [
    { id: 'support', label: t.navSupport, icon: <Headphones className="w-5 h-5" /> },
    { id: 'refer', label: t.navRefer, icon: <Users className="w-5 h-5" />, badge: '৳10' },
    { id: 'home', label: t.navHome, icon: <Home className="w-5 h-5" />, isCenter: true },
    { id: 'wallet', label: t.navWallet, icon: <Wallet className="w-5 h-5" /> },
    { id: 'profile', label: t.navProfile, icon: <UserIcon className="w-5 h-5" /> },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-slate-900/95 backdrop-blur-md border-t border-slate-800 pb-[env(safe-area-inset-bottom)]">
      <div className="max-w-md mx-auto px-2 flex items-center justify-between h-16">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;

          if (item.isCenter) {
            return (
              <button
                key={item.id}
                onClick={() => {
                  triggerHaptic('medium');
                  setActiveTab(item.id);
                }}
                className="relative -top-3 flex flex-col items-center justify-center group focus:outline-none"
              >
                <div
                  className={`w-13 h-13 rounded-2xl flex items-center justify-center transition-all duration-300 shadow-xl ${
                    isActive
                      ? 'bg-gradient-to-tr from-emerald-600 via-emerald-500 to-teal-400 text-slate-950 ring-4 ring-slate-950 shadow-emerald-500/40 scale-105'
                      : 'bg-slate-850 hover:bg-slate-800 text-emerald-400 border border-slate-700/80 ring-4 ring-slate-950'
                  }`}
                >
                  <Home className="w-6 h-6 stroke-[2.2]" />
                </div>
                <span
                  className={`text-[10px] mt-1 font-bold tracking-tight transition ${
                    isActive ? 'text-emerald-400 font-extrabold' : 'text-slate-400 group-hover:text-slate-200'
                  }`}
                >
                  {item.label}
                </span>
              </button>
            );
          }

          return (
            <button
              key={item.id}
              onClick={() => {
                triggerHaptic('light');
                setActiveTab(item.id);
              }}
              className={`relative flex flex-col items-center justify-center flex-1 py-1 transition-all duration-200 group ${
                isActive ? 'text-emerald-400 font-bold scale-105' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {item.badge && (
                <span className="absolute -top-1 px-1.5 py-0.2 rounded-full text-[9px] font-extrabold uppercase leading-none bg-emerald-500 text-slate-950 font-black">
                  {item.badge}
                </span>
              )}
              <div
                className={`p-1.5 rounded-xl transition ${
                  isActive
                    ? 'bg-emerald-950/70 text-emerald-400 shadow-sm shadow-emerald-500/20'
                    : 'group-hover:bg-slate-800/50'
                }`}
              >
                {item.icon}
              </div>
              <span className="text-[10px] mt-0.5 tracking-tight font-medium">
                {item.label}
              </span>
              {isActive && (
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-0.5"></span>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
