import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { WithdrawalRequest, Transaction } from '../../types';
import {
  Wallet,
  ArrowDownLeft,
  ArrowUpRight,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  HelpCircle,
  ShieldCheck,
  Send,
} from 'lucide-react';

export const WalletView: React.FC = () => {
  const { user, settings, refreshUser, showToast, triggerHaptic, t } = useApp();

  const [activeTab, setActiveTab] = useState<'withdraw' | 'withdrawals' | 'transactions'>('withdraw');
  const [method, setMethod] = useState<'bKash' | 'Nagad' | 'Rocket'>('bKash');
  const [accountType, setAccountType] = useState<'Personal' | 'Merchant'>('Personal');
  const [accountNumber, setAccountNumber] = useState<string>('');
  const [amountBdt, setAmountBdt] = useState<string>('50');
  const [submitting, setSubmitting] = useState<boolean>(false);

  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loadingHistory, setLoadingHistory] = useState<boolean>(false);

  const minWithdrawalBdt = settings ? (settings.minWithdrawalPoisha / 100).toFixed(2) : '50.00';
  const feePercent = settings?.withdrawalFeePercent || 2;

  const numAmount = Number(amountBdt) || 0;
  const calculatedFee = (numAmount * feePercent) / 100;
  const netPayout = Math.max(0, numAmount - calculatedFee);

  const balanceBdt = user ? (user.balancePoisha / 100).toFixed(2) : '0.00';
  const pendingBdt = user ? (user.pendingWithdrawPoisha / 100).toFixed(2) : '0.00';
  const totalEarnedBdt = user ? (user.totalEarnedPoisha / 100).toFixed(2) : '0.00';

  const loadHistory = async () => {
    try {
      setLoadingHistory(true);
      const [wRes, tRes] = await Promise.all([
        api.getMyWithdrawals(),
        api.getUserTransactions(),
      ]);
      if (wRes.success) setWithdrawals(wRes.withdrawals);
      if (tRes.success) setTransactions(tRes.transactions);
    } catch (err) {
      console.error('Failed to load wallet data:', err);
    } finally {
      setLoadingHistory(false);
    }
  };

  useEffect(() => {
    loadHistory();
  }, [activeTab]);

  const handleSubmitWithdrawal = async (e: React.FormEvent) => {
    e.preventDefault();
    triggerHaptic('medium');

    const cleanNum = accountNumber.replace(/\D/g, '');
    if (!/^01[3-9]\d{8,9}$/.test(cleanNum)) {
      showToast('অনুগ্রহ করে সঠিক ১১ বা ১২ ডিজিটের মোবাইল নম্বর দিন (যেমন: 01819234567)', 'error');
      return;
    }

    if (numAmount < Number(minWithdrawalBdt)) {
      showToast(`Minimum withdrawal is ৳${minWithdrawalBdt} BDT`, 'error');
      return;
    }

    if (user && numAmount * 100 > user.balancePoisha) {
      showToast('Insufficient wallet balance', 'error');
      return;
    }

    try {
      setSubmitting(true);
      const res = await api.createWithdrawal({
        method,
        accountType,
        accountNumber: cleanNum,
        amountBdt: numAmount,
      });

      if (res.success) {
        triggerHaptic('success');
        showToast(res.message, 'success');
        setAccountNumber('');
        await refreshUser();
        await loadHistory();
        setActiveTab('withdrawals');
      }
    } catch (err: any) {
      showToast(err.message || 'Withdrawal request failed', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Wallet Balance Hero Card */}
      <div className="rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950 border border-emerald-500/30 p-5 shadow-2xl">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            BDT Financial Wallet
          </span>
          <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold">
            bKash & Nagad Verified
          </span>
        </div>

        <div className="flex items-baseline space-x-1.5 my-1">
          <span className="text-3xl font-black text-emerald-400">৳</span>
          <span className="text-4xl font-black tracking-tight text-white">{balanceBdt}</span>
          <span className="text-xs font-bold text-slate-400 ml-1">BDT AVAILABLE</span>
        </div>

        {/* Detailed Breakdown Grid */}
        <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-slate-800 text-center">
          <div className="bg-slate-950/60 rounded-xl p-2 border border-slate-800">
            <span className="text-[10px] text-slate-400 block font-medium">Pending Payout</span>
            <span className="text-xs font-bold text-amber-400">৳{pendingBdt}</span>
          </div>
          <div className="bg-slate-950/60 rounded-xl p-2 border border-slate-800">
            <span className="text-[10px] text-slate-400 block font-medium">Lifetime Earned</span>
            <span className="text-xs font-bold text-emerald-400">৳{totalEarnedBdt}</span>
          </div>
          <div className="bg-slate-950/60 rounded-xl p-2 border border-slate-800">
            <span className="text-[10px] text-slate-400 block font-medium">Task Income</span>
            <span className="text-xs font-bold text-teal-300">
              ৳{user ? (user.taskEarnedPoisha / 100).toFixed(2) : '0.00'}
            </span>
          </div>
        </div>
      </div>

      {/* Sub Tabs */}
      <div className="grid grid-cols-3 gap-1 bg-slate-900 p-1 rounded-2xl border border-slate-800">
        <button
          onClick={() => {
            triggerHaptic('light');
            setActiveTab('withdraw');
          }}
          className={`py-2 text-xs font-bold rounded-xl transition cursor-pointer ${
            activeTab === 'withdraw'
              ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          {t.withdrawTab}
        </button>
        <button
          onClick={() => {
            triggerHaptic('light');
            setActiveTab('withdrawals');
          }}
          className={`py-2 text-xs font-bold rounded-xl transition cursor-pointer ${
            activeTab === 'withdrawals'
              ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          {t.requestsTab} ({withdrawals.length})
        </button>
        <button
          onClick={() => {
            triggerHaptic('light');
            setActiveTab('transactions');
          }}
          className={`py-2 text-xs font-bold rounded-xl transition cursor-pointer ${
            activeTab === 'transactions'
              ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          {t.ledgerTab}
        </button>
      </div>

      {/* TAB 1: Request Withdrawal */}
      {activeTab === 'withdraw' && (
        <form onSubmit={handleSubmitWithdrawal} className="bg-slate-900/90 rounded-2xl border border-slate-800 p-4 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white">{t.selectGateway}</h3>
            <span className="text-[11px] text-slate-400">Min: ৳{minWithdrawalBdt} BDT</span>
          </div>

          {/* Payment Method Selector (bKash, Nagad, Rocket) */}
          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => {
                triggerHaptic('light');
                setMethod('bKash');
              }}
              className={`p-2.5 rounded-2xl border flex flex-col items-center justify-center space-y-1.5 transition ${
                method === 'bKash'
                  ? 'bg-pink-950/50 border-pink-500 text-white shadow-lg shadow-pink-500/20'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="w-8 h-8 rounded-xl bg-pink-600 flex items-center justify-center text-white font-black text-xs shadow-md">
                bK
              </div>
              <div className="text-center">
                <span className="text-xs font-extrabold block text-pink-400">bKash</span>
                <span className="text-[9px] text-slate-400">বিকাশ</span>
              </div>
            </button>

            <button
              type="button"
              onClick={() => {
                triggerHaptic('light');
                setMethod('Nagad');
              }}
              className={`p-2.5 rounded-2xl border flex flex-col items-center justify-center space-y-1.5 transition ${
                method === 'Nagad'
                  ? 'bg-orange-950/50 border-orange-500 text-white shadow-lg shadow-orange-500/20'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="w-8 h-8 rounded-xl bg-orange-600 flex items-center justify-center text-white font-black text-xs shadow-md">
                ন
              </div>
              <div className="text-center">
                <span className="text-xs font-extrabold block text-orange-400">Nagad</span>
                <span className="text-[9px] text-slate-400">নগদ</span>
              </div>
            </button>

            <button
              type="button"
              onClick={() => {
                triggerHaptic('light');
                setMethod('Rocket');
              }}
              className={`p-2.5 rounded-2xl border flex flex-col items-center justify-center space-y-1.5 transition ${
                method === 'Rocket'
                  ? 'bg-purple-950/50 border-purple-500 text-white shadow-lg shadow-purple-500/20'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="w-8 h-8 rounded-xl bg-purple-600 flex items-center justify-center text-white font-black text-xs shadow-md">
                র
              </div>
              <div className="text-center">
                <span className="text-xs font-extrabold block text-purple-400">Rocket</span>
                <span className="text-[9px] text-slate-400">রকেট DBBL</span>
              </div>
            </button>
          </div>

          {/* Account Type Toggle */}
          <div className="flex items-center space-x-2">
            <button
              type="button"
              onClick={() => setAccountType('Personal')}
              className={`flex-1 py-1.5 rounded-xl text-xs font-bold border transition ${
                accountType === 'Personal'
                  ? 'bg-slate-800 border-emerald-500/50 text-emerald-400'
                  : 'bg-slate-950 border-slate-800 text-slate-400'
              }`}
            >
              {t.personalAccount}
            </button>
            <button
              type="button"
              onClick={() => setAccountType('Merchant')}
              className={`flex-1 py-1.5 rounded-xl text-xs font-bold border transition ${
                accountType === 'Merchant'
                  ? 'bg-slate-800 border-emerald-500/50 text-emerald-400'
                  : 'bg-slate-950 border-slate-800 text-slate-400'
              }`}
            >
              {t.merchantAccount}
            </button>
          </div>

          {/* Account Number Input */}
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-300">
              {method} {method === 'Rocket' ? 'অ্যাকাউন্ট নম্বর (১১ বা ১২ ডিজিট)' : 'মোবাইল নম্বর (১১ ডিজিট)'}
            </label>
            <input
              type="tel"
              required
              maxLength={method === 'Rocket' ? 12 : 11}
              value={accountNumber}
              onChange={(e) => setAccountNumber(e.target.value)}
              placeholder={method === 'Rocket' ? 'যেমন: 01819234567 বা 018192345678' : 'যেমন: 01819234567'}
              className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-none font-mono"
            />
          </div>

          {/* Amount Input */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-300">Amount in BDT (৳)</label>
              <button
                type="button"
                onClick={() => setAmountBdt(String(Math.floor(Number(balanceBdt))))}
                className="text-[10px] text-emerald-400 font-bold hover:underline"
              >
                Use Max (৳{balanceBdt})
              </button>
            </div>
            <input
              type="number"
              required
              min={Number(minWithdrawalBdt)}
              step="1"
              value={amountBdt}
              onChange={(e) => setAmountBdt(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-base font-bold text-white placeholder-slate-600 focus:outline-none"
            />

            {/* Quick Amount Pills */}
            <div className="flex items-center space-x-1.5 pt-1">
              {['50', '100', '200', '500'].map((val) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => setAmountBdt(val)}
                  className={`px-2.5 py-1 rounded-lg text-[10px] font-bold border transition ${
                    amountBdt === val
                      ? 'bg-emerald-950 border-emerald-500 text-emerald-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  ৳{val}
                </button>
              ))}
            </div>
          </div>

          {/* Payout Calculation Card */}
          <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800 space-y-1.5 text-xs">
            <div className="flex justify-between text-slate-400">
              <span>Requested Amount:</span>
              <span className="text-white font-medium">৳{numAmount.toFixed(2)} BDT</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>Gateway Fee ({feePercent}%):</span>
              <span className="text-rose-400 font-medium">-৳{calculatedFee.toFixed(2)} BDT</span>
            </div>
            <div className="flex justify-between text-slate-200 font-bold pt-1.5 border-t border-slate-800 text-sm">
              <span>Net Payout You Receive:</span>
              <span className="text-emerald-400 font-black">৳{netPayout.toFixed(2)} BDT</span>
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={submitting || (user ? numAmount * 100 > user.balancePoisha : true)}
            className={`w-full py-3 rounded-xl font-extrabold text-xs flex items-center justify-center space-x-2 transition shadow-lg ${
              user && numAmount * 100 > user.balancePoisha
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                : 'bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 shadow-emerald-500/20 active:scale-95'
            }`}
          >
            <Send className="w-4 h-4" />
            <span>{submitting ? 'Submitting Request...' : `Submit ৳${numAmount.toFixed(2)} BDT Withdrawal`}</span>
          </button>

          <p className="text-[10px] text-slate-400 text-center">
            🔒 Payout requests are verified by administrators and paid within 1-24 hours directly to your {method} account.
          </p>
        </form>
      )}

      {/* TAB 2: Withdrawal Requests */}
      {activeTab === 'withdrawals' && (
        <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-4 space-y-3">
          <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
            Your Withdrawal History
          </h3>

          {loadingHistory ? (
            <div className="py-8 text-center text-xs text-slate-500">Loading requests...</div>
          ) : withdrawals.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-500">
              No withdrawal requests submitted yet.
            </div>
          ) : (
            <div className="space-y-2.5">
              {withdrawals.map((w) => {
                const amount = (w.amountPoisha / 100).toFixed(2);
                const net = (w.netAmountPoisha / 100).toFixed(2);
                return (
                  <div
                    key={w.id}
                    className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80 space-y-2 text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-black ${
                            w.method === 'bKash'
                              ? 'bg-pink-950 text-pink-400 border border-pink-500/30'
                              : w.method === 'Rocket'
                              ? 'bg-purple-950 text-purple-400 border border-purple-500/30'
                              : 'bg-orange-950 text-orange-400 border border-orange-500/30'
                          }`}
                        >
                          {w.method}
                        </span>
                        <span className="font-mono text-white font-medium">{w.accountNumber}</span>
                      </div>
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                          w.status === 'Paid'
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/40'
                            : w.status === 'Approved'
                            ? 'bg-blue-950 text-blue-400 border border-blue-500/40'
                            : w.status === 'Rejected'
                            ? 'bg-rose-950 text-rose-400 border border-rose-500/40'
                            : 'bg-amber-950 text-amber-400 border border-amber-500/40'
                        }`}
                      >
                        {w.status}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-slate-400 text-[11px]">
                      <span>Amount: <strong className="text-white">৳{amount}</strong> (Net: ৳{net})</span>
                      <span>{new Date(w.createdAt).toLocaleDateString()}</span>
                    </div>

                    {w.payoutReference && (
                      <div className="p-1.5 rounded bg-slate-900 border border-slate-800 text-[10px] font-mono text-emerald-300">
                        TXN REF: {w.payoutReference}
                      </div>
                    )}

                    {w.rejectionReason && (
                      <div className="p-1.5 rounded bg-rose-950/60 border border-rose-500/30 text-[10px] text-rose-300">
                        Reason: {w.rejectionReason} (Amount has been refunded to your wallet)
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 3: Full Ledger */}
      {activeTab === 'transactions' && (
        <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-4 space-y-3">
          <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
            Transaction Ledger
          </h3>

          {loadingHistory ? (
            <div className="py-8 text-center text-xs text-slate-500">Loading ledger...</div>
          ) : transactions.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-500">No transactions recorded yet.</div>
          ) : (
            <div className="space-y-2">
              {transactions.map((t) => {
                const isPositive = t.amountPoisha > 0;
                const formattedAmt = (Math.abs(t.amountPoisha) / 100).toFixed(2);
                return (
                  <div
                    key={t.id}
                    className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs"
                  >
                    <div>
                      <div className="font-bold text-white">{t.description}</div>
                      <div className="text-[10px] text-slate-400">
                        {new Date(t.createdAt).toLocaleString()}
                      </div>
                    </div>
                    <div className="text-right">
                      <span
                        className={`font-black text-xs block ${
                          isPositive ? 'text-emerald-400' : 'text-rose-400'
                        }`}
                      >
                        {isPositive ? '+' : '-'}৳{formattedAmt} BDT
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        Bal: ৳{(t.balanceAfterPoisha / 100).toFixed(2)}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
