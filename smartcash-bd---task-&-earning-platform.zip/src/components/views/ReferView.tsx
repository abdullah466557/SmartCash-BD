import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { Users, Copy, Check, Share2, Gift, ShieldCheck, ArrowRight, Sparkles } from 'lucide-react';

export const ReferView: React.FC = () => {
  const { user, settings, showToast, triggerHaptic } = useApp();
  const [copied, setCopied] = useState(false);
  const [referrals, setReferrals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const botUsername = (settings?.telegramBotUsername || '@smartcashbd_bot').replace('@', '');
  const referralCode = user?.referralCode || 'SCBD8801';
  const referralLink = `https://t.me/${botUsername}?start=${referralCode}`;
  const referralRewardBdt = settings ? (settings.referralRewardPoisha / 100).toFixed(2) : '10.00';

  useEffect(() => {
    async function loadReferrals() {
      try {
        setLoading(true);
        const res = await api.getMyReferrals();
        if (res.success) {
          setReferrals(res.referrals);
        }
      } catch (err) {
        console.error('Failed to load referrals:', err);
      } finally {
        setLoading(false);
      }
    }
    loadReferrals();
  }, []);

  const handleCopy = () => {
    navigator.clipboard.writeText(referralLink);
    setCopied(true);
    triggerHaptic('success');
    showToast('Referral link copied to clipboard!', 'success');
    setTimeout(() => setCopied(false), 2500);
  };

  const handleTelegramShare = () => {
    triggerHaptic('medium');
    const shareText = `🚀 Join SmartCash BD on Telegram and earn daily BDT!\n\n🎁 Get instant ৳5.00 BDT sign-up bonus.\n💸 Daily spin & micro-tasks with fast bKash & Nagad withdrawals.\n\nStart now:`;
    const shareUrl = `https://t.me/share/url?url=${encodeURIComponent(referralLink)}&text=${encodeURIComponent(shareText)}`;
    window.open(shareUrl, '_blank');
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-purple-950 via-slate-900 to-emerald-950 border border-purple-500/30 p-5 shadow-2xl">
        <div className="flex items-start justify-between">
          <div>
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-purple-400 px-2 py-0.5 rounded bg-purple-900/60 border border-purple-500/30">
              Instant Referral Program
            </span>
            <h1 className="text-xl font-black text-white mt-2">
              Invite Friends & Earn <span className="text-emerald-400">৳{referralRewardBdt}</span> BDT
            </h1>
            <p className="text-xs text-slate-300 mt-1 max-w-xs">
              Every time a friend opens the bot with your link, your account is instantly credited with ৳{referralRewardBdt} BDT!
            </p>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-purple-600/30 border border-purple-400/40 flex items-center justify-center text-purple-300 shadow-inner">
            <Gift className="w-6 h-6 animate-bounce" />
          </div>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-2 gap-3 mt-4 pt-4 border-t border-slate-800">
          <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-800">
            <span className="text-[10px] text-slate-400 block font-medium">Invited Friends</span>
            <span className="text-lg font-extrabold text-white">
              {user?.referralsCount || 0} users
            </span>
          </div>
          <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-800">
            <span className="text-[10px] text-slate-400 block font-medium">Total Referral Income</span>
            <span className="text-lg font-extrabold text-emerald-400">
              ৳{user ? (user.referralEarnedPoisha / 100).toFixed(2) : '0.00'} BDT
            </span>
          </div>
        </div>
      </div>

      {/* Unique Link Box */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-4 space-y-3">
        <div className="flex items-center justify-between">
          <label className="text-xs font-bold text-slate-200">Your Official Telegram Deep Link</label>
          <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-500/30">
            Code: {referralCode}
          </span>
        </div>

        <div className="flex items-center space-x-2">
          <input
            type="text"
            readOnly
            value={referralLink}
            className="flex-1 bg-slate-950 border border-slate-800 text-xs text-slate-300 px-3 py-2.5 rounded-xl font-mono focus:outline-none"
          />
          <button
            onClick={handleCopy}
            className={`px-3 py-2.5 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition ${
              copied
                ? 'bg-emerald-500 text-slate-950'
                : 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700'
            }`}
          >
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>
        </div>

        {/* Share Button */}
        <button
          onClick={handleTelegramShare}
          className="w-full flex items-center justify-center space-x-2 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-lg shadow-blue-600/20 active:scale-95 transition"
        >
          <Share2 className="w-4 h-4" />
          <span>Share Link on Telegram</span>
        </button>
      </div>

      {/* How it works */}
      <div className="bg-slate-900/60 rounded-2xl border border-slate-800 p-4 space-y-3">
        <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center space-x-1.5">
          <Sparkles className="w-4 h-4 text-emerald-400" />
          <span>How Referral Earning Works</span>
        </h3>

        <div className="space-y-2.5 text-xs text-slate-300">
          <div className="flex items-start space-x-2.5">
            <span className="w-5 h-5 rounded-full bg-slate-800 text-emerald-400 flex items-center justify-center shrink-0 font-bold text-[11px]">
              1
            </span>
            <p>Share your personalized deep link with your Telegram contacts, groups, and channels.</p>
          </div>
          <div className="flex items-start space-x-2.5">
            <span className="w-5 h-5 rounded-full bg-slate-800 text-emerald-400 flex items-center justify-center shrink-0 font-bold text-[11px]">
              2
            </span>
            <p>Friend presses Start on @{botUsername}. Their account is created instantly without filling forms.</p>
          </div>
          <div className="flex items-start space-x-2.5">
            <span className="w-5 h-5 rounded-full bg-slate-800 text-emerald-400 flex items-center justify-center shrink-0 font-bold text-[11px]">
              3
            </span>
            <p>You automatically receive <strong>৳{referralRewardBdt} BDT</strong> credited to your wallet balance!</p>
          </div>
        </div>
      </div>

      {/* Referred Friends History */}
      <div className="bg-slate-900/80 rounded-2xl border border-slate-800 p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
            Referred Friends History
          </h3>
          <span className="text-[11px] text-slate-400">{referrals.length} Total</span>
        </div>

        {loading ? (
          <div className="py-6 text-center text-xs text-slate-500">Loading referral list...</div>
        ) : referrals.length === 0 ? (
          <div className="py-6 text-center text-xs text-slate-500">
            No friends invited yet. Share your link above to get started!
          </div>
        ) : (
          <div className="space-y-2">
            {referrals.map((r, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs"
              >
                <div>
                  <div className="font-bold text-white">{r.referredName || 'Telegram User'}</div>
                  <div className="text-[10px] text-slate-400">ID: {r.referredTelegramId}</div>
                </div>
                <div className="text-right">
                  <span className="font-extrabold text-emerald-400 block">
                    +৳{(r.rewardPoisha / 100).toFixed(2)} BDT
                  </span>
                  <span className="text-[10px] text-emerald-500 font-semibold uppercase">Completed</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
