import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  User as UserIcon,
  ShieldCheck,
  Send,
  HelpCircle,
  Smartphone,
  ExternalLink,
  RefreshCw,
  LogOut,
  Sliders,
  CheckCircle2,
  Globe,
} from 'lucide-react';

export const ProfileView: React.FC = () => {
  const { user, settings, switchUser, showToast, triggerHaptic, language, setLanguage, t, setIsAdminOpen } = useApp();
  const [customTgId, setCustomTgId] = useState('');
  const [customName, setCustomName] = useState('');

  const botUsername = settings?.telegramBotUsername || '@smartcashbd_bot';
  const supportTelegram = settings?.supportTelegram || '@smartcashbd_support';

  const handleTestAccountSwitch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customTgId.trim()) return;

    triggerHaptic('medium');
    await switchUser({
      id: customTgId.trim(),
      first_name: customName.trim() || `User_${customTgId.slice(-4)}`,
      username: customName ? customName.toLowerCase().replace(/\s+/g, '_') : `tg_${customTgId.slice(-4)}`,
    });
    setCustomTgId('');
    setCustomName('');
  };

  const handleLanguageChange = (lang: 'en' | 'bn' | 'hi') => {
    triggerHaptic('light');
    setLanguage(lang);
    showToast(
      lang === 'bn' ? 'ভাষা বাংলায় পরিবর্তিত হয়েছে' : lang === 'hi' ? 'भाषा हिन्दी में बदली गई' : 'Language changed to English',
      'success'
    );
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Language Selector (English / বাংলা / हिन्दी) */}
      <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-4 shadow-xl">
        <div className="flex items-center space-x-2 mb-3">
          <Globe className="w-4 h-4 text-emerald-400" />
          <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
            {t.selectLanguage}
          </h3>
        </div>
        <div className="grid grid-cols-3 gap-2">
          <button
            onClick={() => handleLanguageChange('en')}
            className={`py-2 px-3 rounded-xl text-xs font-bold transition flex flex-col items-center justify-center space-y-0.5 border ${
              language === 'en'
                ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 shadow-md shadow-emerald-500/10'
                : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-950'
            }`}
          >
            <span className="text-sm">🇺🇸</span>
            <span>English</span>
          </button>
          <button
            onClick={() => handleLanguageChange('bn')}
            className={`py-2 px-3 rounded-xl text-xs font-bold transition flex flex-col items-center justify-center space-y-0.5 border ${
              language === 'bn'
                ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 shadow-md shadow-emerald-500/10'
                : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-950'
            }`}
          >
            <span className="text-sm">🇧🇩</span>
            <span>বাংলা</span>
          </button>
          <button
            onClick={() => handleLanguageChange('hi')}
            className={`py-2 px-3 rounded-xl text-xs font-bold transition flex flex-col items-center justify-center space-y-0.5 border ${
              language === 'hi'
                ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 shadow-md shadow-emerald-500/10'
                : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-950'
            }`}
          >
            <span className="text-sm">🇮🇳</span>
            <span>हिन्दी</span>
          </button>
        </div>
      </div>
      {/* Profile Card */}
      <div className="rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950 border border-emerald-500/30 p-5 shadow-2xl">
        <div className="flex items-center space-x-3.5">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 p-0.5 shadow-lg shadow-emerald-500/20">
            {user?.photoUrl ? (
              <img src={user.photoUrl} alt="Avatar" className="w-full h-full rounded-2xl object-cover" />
            ) : (
              <div className="w-full h-full rounded-2xl bg-slate-900 flex items-center justify-center text-emerald-400 font-black text-xl">
                {user?.firstName?.charAt(0) || 'U'}
              </div>
            )}
          </div>

          <div className="flex-1">
            <div className="flex items-center space-x-1.5">
              <h2 className="text-base font-extrabold text-white">
                {user?.firstName} {user?.lastName || ''}
              </h2>
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-xs text-slate-400 font-mono">
              @{user?.username || 'telegram_user'}
            </div>
            <div className="mt-1 flex items-center space-x-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-500/30">
                Telegram ID: {user?.telegramId}
              </span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 mt-4 pt-4 border-t border-slate-800 text-xs">
          <div>
            <span className="text-[10px] text-slate-400 block font-medium">Joined On</span>
            <span className="text-slate-200 font-semibold">
              {user ? new Date(user.createdAt).toLocaleDateString() : 'N/A'}
            </span>
          </div>
          <div>
            <span className="text-[10px] text-slate-400 block font-medium">Referral Code</span>
            <span className="text-emerald-400 font-bold font-mono">{user?.referralCode}</span>
          </div>
        </div>
      </div>

      {/* Admin Panel Access Button */}
      <button
        onClick={() => {
          triggerHaptic('medium');
          setIsAdminOpen(true);
        }}
        className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-gradient-to-r from-slate-900 to-amber-950/40 hover:from-slate-850 hover:to-amber-950/60 border border-amber-500/30 text-amber-300 text-xs font-bold transition shadow-lg active:scale-98 cursor-pointer"
      >
        <div className="flex items-center space-x-2.5">
          <div className="w-7 h-7 rounded-lg bg-amber-500/20 flex items-center justify-center text-amber-400">
            <ShieldCheck className="w-4 h-4" />
          </div>
          <div className="text-left">
            <span className="font-extrabold text-white block">এডমিন প্যানেল (Admin Panel)</span>
            <span className="text-[10px] text-slate-400">ম্যানেজমেন্ট ও সিকিউরিটি কন্ট্রোল</span>
          </div>
        </div>
        <span className="text-[10px] px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/30 font-semibold">
          পাসওয়ার্ড আবশ্যক
        </span>
      </button>

      {/* Support & Community Links */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-4 space-y-2.5">
        <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider mb-2">
          Help & Official Support
        </h3>

        <a
          href={`https://t.me/${supportTelegram.replace('@', '')}`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center justify-between p-3 rounded-xl bg-slate-950/60 hover:bg-slate-950 border border-slate-800 text-xs text-slate-300 transition"
        >
          <div className="flex items-center space-x-2.5">
            <Send className="w-4 h-4 text-blue-400" />
            <div>
              <span className="font-bold text-white block">Official Telegram Support</span>
              <span className="text-[10px] text-slate-400">{supportTelegram}</span>
            </div>
          </div>
          <ExternalLink className="w-4 h-4 text-slate-500" />
        </a>

        <a
          href={`https://t.me/${botUsername.replace('@', '')}`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center justify-between p-3 rounded-xl bg-slate-950/60 hover:bg-slate-950 border border-slate-800 text-xs text-slate-300 transition"
        >
          <div className="flex items-center space-x-2.5">
            <Send className="w-4 h-4 text-emerald-400" />
            <div>
              <span className="font-bold text-white block">Official Bot Channel</span>
              <span className="text-[10px] text-slate-400">{botUsername}</span>
            </div>
          </div>
          <ExternalLink className="w-4 h-4 text-slate-500" />
        </a>
      </div>

      {/* System & Device Meta */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-4 space-y-2 text-xs text-slate-400">
        <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center space-x-1.5 mb-2">
          <Smartphone className="w-4 h-4 text-emerald-400" />
          <span>{language === 'bn' ? 'সিকিউরিটি ও ডিভাইস তথ্য' : 'Security & Device Information'}</span>
        </h3>

        <div className="flex justify-between py-1 border-b border-slate-800/60">
          <span>{t.accountStatus}:</span>
          <span className="text-emerald-400 font-bold flex items-center space-x-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>{t.activeGoodStanding}</span>
          </span>
        </div>
        <div className="flex justify-between py-1 border-b border-slate-800/60">
          <span>{t.clientEnv}:</span>
          <span className="text-slate-300 font-medium">Telegram Mini App / Android</span>
        </div>
        <div className="flex justify-between py-1 border-b border-slate-800/60">
          <span>{t.currencySystem}:</span>
          <span className="text-slate-300 font-medium">{language === 'bn' ? 'বাংলাদেশি টাকা (BDT / ৳)' : 'BDT (Bangladeshi Taka / ৳)'}</span>
        </div>
        <div className="flex justify-between py-1">
          <span>{language === 'bn' ? 'সর্বশেষ সক্রিয়:' : 'Last Active:'}</span>
          <span className="text-slate-300 font-medium">
            {user ? new Date(user.lastActiveAt).toLocaleTimeString() : (language === 'bn' ? 'এইমাত্র' : 'Now')}
          </span>
        </div>
      </div>

      {/* Developer & Reviewer Account Switcher */}
      <div className="bg-slate-900/60 rounded-2xl border border-slate-800 p-4 space-y-3">
        <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center space-x-1.5">
          <Sliders className="w-4 h-4 text-teal-400" />
          <span>Test Different Telegram Identities</span>
        </h3>
        <p className="text-[11px] text-slate-400">
          Switch account or test auto account creation with any simulated Telegram ID.
        </p>

        <form onSubmit={handleTestAccountSwitch} className="space-y-2">
          <div className="grid grid-cols-2 gap-2">
            <input
              type="text"
              required
              placeholder="Telegram ID (e.g. 8801999999)"
              value={customTgId}
              onChange={(e) => setCustomTgId(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-600 focus:outline-none"
            />
            <input
              type="text"
              placeholder="First Name (e.g. Rahim)"
              value={customName}
              onChange={(e) => setCustomName(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-600 focus:outline-none"
            />
          </div>

          <button
            type="submit"
            className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs transition"
          >
            Switch to This Telegram Account
          </button>
        </form>

        {/* Quick presets */}
        <div className="flex items-center space-x-2 pt-1">
          <span className="text-[10px] text-slate-500">Presets:</span>
          <button
            onClick={() => switchUser({ id: '8801900123', first_name: 'Tanvir', username: 'tanvir_hasan' })}
            className="text-[10px] bg-slate-950 px-2 py-0.5 rounded border border-slate-800 text-slate-300 hover:text-white"
          >
            Tanvir (Demo #1)
          </button>
          <button
            onClick={() => switchUser({ id: '8801700999', first_name: 'Sakib', username: 'sakib_bd' }, user?.referralCode)}
            className="text-[10px] bg-slate-950 px-2 py-0.5 rounded border border-slate-800 text-slate-300 hover:text-white"
          >
            Sakib (Referred User)
          </button>
        </div>
      </div>
    </div>
  );
};
