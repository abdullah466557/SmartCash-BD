import React from 'react';
import { useApp } from '../../context/AppContext';
import { MessageCircle, PhoneCall, Send, ShieldCheck, Clock, ExternalLink, Headphones } from 'lucide-react';

export const SupportView: React.FC = () => {
  const { settings, t, triggerHaptic } = useApp();

  const whatsappLink = settings.whatsappSupport
    ? (settings.whatsappSupport.startsWith('http') ? settings.whatsappSupport : `https://wa.me/${settings.whatsappSupport.replace(/\D/g, '')}`)
    : 'https://wa.me/8801819234567';

  const imoLink = settings.imoSupport
    ? (settings.imoSupport.startsWith('http') ? settings.imoSupport : `tel:${settings.imoSupport}`)
    : 'tel:+8801819234567';

  const telegramChannelLink = settings.telegramChannel
    ? (settings.telegramChannel.startsWith('http') ? settings.telegramChannel : `https://t.me/${settings.telegramChannel.replace('@', '')}`)
    : 'https://t.me/smartcashbd_channel';

  return (
    <div className="space-y-4 pb-20">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-emerald-950 via-slate-900 to-teal-950 border border-emerald-500/40 p-5 shadow-2xl">
        <div className="flex items-start justify-between">
          <div>
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-emerald-400 px-2 py-0.5 rounded bg-emerald-900/60 border border-emerald-500/30">
              {t.supportHours}
            </span>
            <h1 className="text-xl font-black text-white mt-2">
              {t.supportHeaderTitle}
            </h1>
            <p className="text-xs text-slate-300 mt-1 max-w-xs">
              {t.supportHeaderDesc}
            </p>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-300 shadow-inner">
            <Headphones className="w-6 h-6 animate-pulse" />
          </div>
        </div>
      </div>

      {/* 3 Official Support Channels */}
      <div className="space-y-3">
        {/* 1. WhatsApp Support */}
        <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-4 space-y-3 hover:border-emerald-500/50 transition">
          <div className="flex items-start space-x-3.5">
            <div className="w-11 h-11 rounded-2xl bg-emerald-950 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shrink-0 shadow-md">
              <MessageCircle className="w-6 h-6 fill-emerald-500/20" />
            </div>
            <div className="flex-1">
              <div className="flex items-center space-x-2">
                <h3 className="text-sm font-bold text-white">{t.whatsappSupportTitle}</h3>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">
                {t.whatsappSupportSub}
              </p>
              <div className="text-[11px] font-mono text-emerald-400 mt-1">
                {settings.whatsappSupport || '+880 1819-234567'}
              </div>
            </div>
          </div>

          <a
            href={whatsappLink}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => triggerHaptic('medium')}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center justify-center space-x-2 shadow-md shadow-emerald-600/20 transition active:scale-95"
          >
            <MessageCircle className="w-4 h-4" />
            <span>{t.chatOnWhatsapp}</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>

        {/* 2. IMO Support */}
        <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-4 space-y-3 hover:border-blue-500/50 transition">
          <div className="flex items-start space-x-3.5">
            <div className="w-11 h-11 rounded-2xl bg-blue-950 border border-blue-500/40 flex items-center justify-center text-blue-400 shrink-0 shadow-md">
              <PhoneCall className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <div className="flex items-center space-x-2">
                <h3 className="text-sm font-bold text-white">{t.imoSupportTitle}</h3>
                <span className="w-2 h-2 rounded-full bg-blue-400"></span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">
                {t.imoSupportSub}
              </p>
              <div className="text-[11px] font-mono text-blue-400 mt-1">
                {settings.imoSupport || '+880 1819-234567'}
              </div>
            </div>
          </div>

          <a
            href={imoLink}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => triggerHaptic('medium')}
            className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center space-x-2 shadow-md shadow-blue-600/20 transition active:scale-95"
          >
            <PhoneCall className="w-4 h-4" />
            <span>{t.contactOnImo}</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>

        {/* 3. Official Telegram Channel */}
        <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-4 space-y-3 hover:border-sky-500/50 transition">
          <div className="flex items-start space-x-3.5">
            <div className="w-11 h-11 rounded-2xl bg-sky-950 border border-sky-500/40 flex items-center justify-center text-sky-400 shrink-0 shadow-md">
              <Send className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <div className="flex items-center space-x-2">
                <h3 className="text-sm font-bold text-white">{t.telegramChannelTitle}</h3>
                <span className="w-2 h-2 rounded-full bg-sky-400"></span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">
                {t.telegramChannelSub}
              </p>
              <div className="text-[11px] font-mono text-sky-400 mt-1">
                {settings.telegramChannel || '@smartcashbd_channel'}
              </div>
            </div>
          </div>

          <a
            href={telegramChannelLink}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => triggerHaptic('medium')}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-500 hover:to-blue-500 text-white font-bold text-xs flex items-center justify-center space-x-2 shadow-md shadow-sky-600/20 transition active:scale-95"
          >
            <Send className="w-4 h-4" />
            <span>{t.joinTelegramChannel}</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>

      {/* Security & Verification Notice */}
      <div className="bg-slate-900/60 rounded-2xl border border-slate-800 p-4 space-y-2 text-xs text-slate-300">
        <div className="flex items-center space-x-1.5 font-bold text-emerald-400">
          <ShieldCheck className="w-4 h-4" />
          <span>{t.supportNotice}</span>
        </div>
        <p className="text-[11px] text-slate-400">
          Our official representatives will never ask for your passwords, two-factor codes, or fees to process withdrawals.
        </p>
      </div>
    </div>
  );
};
