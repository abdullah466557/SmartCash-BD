import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { VideoAd } from '../../types';
import confetti from 'canvas-confetti';
import { PlaySquare, Clock, ShieldCheck, CheckCircle2, Play, Eye, Sparkles } from 'lucide-react';

export const VideoAdsView: React.FC = () => {
  const { user, refreshUser, showToast, triggerHaptic, t } = useApp();
  const [ads, setAds] = useState<VideoAd[]>([]);
  const [adsCompletedToday, setAdsCompletedToday] = useState<number>(0);
  const [dailyLimit, setDailyLimit] = useState<number>(15);
  const [cooldownRemaining, setCooldownRemaining] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(true);

  // Active Ad Player state
  const [currentPlayingAd, setCurrentPlayingAd] = useState<VideoAd | null>(null);
  const [adPlaybackSeconds, setAdPlaybackSeconds] = useState<number>(15);

  const fetchAds = async () => {
    try {
      setLoading(true);
      const res = await api.getVideoAds();
      if (res.success) {
        setAds(res.ads || []);
        setAdsCompletedToday(res.adsCompletedToday || 0);
        setDailyLimit(res.dailyLimit || 15);
        setCooldownRemaining(res.cooldownRemainingSeconds || 0);
      }
    } catch (err: any) {
      console.error('Failed to get video ads:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAds();
  }, []);

  // Cooldown countdown timer
  useEffect(() => {
    let timer: any = null;
    if (cooldownRemaining > 0) {
      timer = setInterval(() => {
        setCooldownRemaining((prev) => (prev > 0 ? prev - 1 : 0));
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [cooldownRemaining]);

  // Video playback countdown
  useEffect(() => {
    let timer: any = null;
    if (currentPlayingAd && adPlaybackSeconds > 0) {
      timer = setInterval(() => {
        setAdPlaybackSeconds((prev) => prev - 1);
      }, 1000);
    } else if (currentPlayingAd && adPlaybackSeconds <= 0) {
      handleAdRewardClaim(currentPlayingAd.id);
    }
    return () => clearInterval(timer);
  }, [currentPlayingAd, adPlaybackSeconds]);

  const handleStartAd = (ad: VideoAd) => {
    if (cooldownRemaining > 0) {
      showToast(`${t.cooldownActive}: ${cooldownRemaining}s`, 'error');
      return;
    }
    if (adsCompletedToday >= dailyLimit) {
      showToast(`${t.dailyLimitReached} (${dailyLimit}/${dailyLimit})`, 'error');
      return;
    }

    triggerHaptic('medium');
    setCurrentPlayingAd(ad);
    setAdPlaybackSeconds(ad.durationSeconds || 15);
  };

  const handleAdRewardClaim = async (adId: string) => {
    try {
      setCurrentPlayingAd(null);
      const res = await api.claimVideoAd(adId);
      if (res.success) {
        triggerHaptic('success');
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.6 },
        });
        showToast(`+৳${res.rewardBdt} BDT Credited!`, 'success');
        await refreshUser();
        await fetchAds();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to claim ad reward', 'error');
      fetchAds();
    }
  };

  const totalAdEarnedBdt = user ? (user.adEarnedPoisha / 100).toFixed(2) : '0.00';

  return (
    <div className="space-y-4 pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-amber-950/60 to-slate-900 border border-amber-500/30 rounded-2xl p-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-base font-extrabold text-white flex items-center space-x-1.5">
              <PlaySquare className="w-5 h-5 text-amber-400" />
              <span>{t.watchVideoAds}</span>
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              {t.videoAdsHeaderDesc}
            </p>
          </div>
          <div className="text-right">
            <span className="text-[10px] text-slate-400 block font-medium">{t.totalEarned}</span>
            <span className="text-sm font-bold text-amber-400">৳{totalAdEarnedBdt}</span>
          </div>
        </div>
      </div>

      {/* Progress & Limit Card */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-4 space-y-3">
        <div className="flex items-center justify-between text-xs">
          <span className="text-slate-300 font-semibold">{t.todayAdQuota}</span>
          <span className="font-extrabold text-white">
            {adsCompletedToday} / {dailyLimit} {t.watched}
          </span>
        </div>

        {/* Progress bar */}
        <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
          <div
            className="bg-gradient-to-r from-amber-500 to-emerald-400 h-full rounded-full transition-all duration-500"
            style={{ width: `${Math.min(100, (adsCompletedToday / dailyLimit) * 100)}%` }}
          ></div>
        </div>

        {cooldownRemaining > 0 && (
          <div className="p-2 rounded-xl bg-amber-950/40 border border-amber-500/30 text-[11px] text-amber-300 flex items-center space-x-2">
            <Clock className="w-3.5 h-3.5 animate-spin" />
            <span>{t.cooldownActive}: {cooldownRemaining}s</span>
          </div>
        )}
      </div>

      {/* Available Ads List */}
      <div className="space-y-3">
        <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center space-x-1.5">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>{t.waysToEarn}</span>
        </h3>

        {loading ? (
          <div className="py-10 text-center text-xs text-slate-500">Loading video ads...</div>
        ) : ads.length === 0 ? (
          <div className="py-10 text-center text-xs text-slate-500 bg-slate-900/50 rounded-2xl border border-slate-800 p-4">
            {t.noAdsAvailable}
          </div>
        ) : (
          ads.map((ad) => {
            const rewardBdt = (ad.rewardPoisha / 100).toFixed(2);
            const isCooldown = cooldownRemaining > 0;
            const isLimit = adsCompletedToday >= dailyLimit;

            return (
              <div
                key={ad.id}
                className="bg-slate-900/90 rounded-2xl border border-slate-800 p-4 hover:border-amber-500/40 transition shadow-lg space-y-3"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1 pr-3">
                    <div className="flex items-center space-x-2 mb-1">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-amber-950 text-amber-300 border border-amber-500/30">
                        {ad.durationSeconds}s
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {ad.viewsCount} views
                      </span>
                    </div>
                    <h4 className="text-sm font-bold text-white">{ad.title}</h4>
                    {ad.description && (
                      <p className="text-xs text-slate-400 mt-1">{ad.description}</p>
                    )}
                  </div>

                  <div className="text-right shrink-0">
                    <div className="text-sm font-black text-emerald-400">৳{rewardBdt}</div>
                    <span className="text-[10px] text-slate-500">BDT</span>
                  </div>
                </div>

                <button
                  disabled={isCooldown || isLimit}
                  onClick={() => handleStartAd(ad)}
                  className={`w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition ${
                    isCooldown || isLimit
                      ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                      : 'bg-gradient-to-r from-amber-500 to-emerald-400 hover:from-amber-400 hover:to-emerald-300 text-slate-950 shadow-md shadow-amber-500/20 active:scale-95'
                  }`}
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>{t.watchAdBtn} (৳{rewardBdt})</span>
                </button>
              </div>
            );
          })
        )}
      </div>

      {/* Video Ad Player Modal */}
      {currentPlayingAd && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-fadeIn">
          <div className="w-full max-w-sm bg-slate-900 border border-amber-500/40 rounded-3xl p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-[10px] font-extrabold uppercase tracking-widest text-amber-400">
                {currentPlayingAd.title}
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-slate-800 text-emerald-400 text-xs font-mono font-bold">
                {adPlaybackSeconds}s remaining
              </span>
            </div>

            {/* Video mockup view */}
            <div className="relative aspect-video rounded-2xl bg-slate-950 border border-slate-800 overflow-hidden flex flex-col items-center justify-center p-4 text-center">
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-slate-950/60 pointer-events-none"></div>
              <div className="relative z-10 space-y-2">
                <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-bold">
                  Sponsor Stream Active
                </span>
                <h4 className="text-sm font-bold text-white">{currentPlayingAd.title}</h4>
                <p className="text-[11px] text-slate-400">
                  Rewarding Bangladesh digital earners since 2026.
                </p>
              </div>

              {/* Progress bar at bottom */}
              <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-slate-800">
                <div
                  className="h-full bg-amber-400 transition-all duration-1000"
                  style={{
                    width: `${((currentPlayingAd.durationSeconds - adPlaybackSeconds) / currentPlayingAd.durationSeconds) * 100}%`,
                  }}
                ></div>
              </div>
            </div>

            <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800 text-[11px] text-slate-300 text-center">
              {t.adNotice} <strong>৳{(currentPlayingAd.rewardPoisha / 100).toFixed(2)} BDT</strong> will be credited automatically!
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
