import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { Task } from '../../types';
import { api } from '../../services/api';
import confetti from 'canvas-confetti';
import {
  CheckSquare,
  Clock,
  ExternalLink,
  ShieldAlert,
  Flame,
  CheckCircle2,
  X,
  Play,
  AlertTriangle,
  Award,
} from 'lucide-react';

export const TasksView: React.FC = () => {
  const { user, refreshUser, showToast, triggerHaptic, language, t } = useApp();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [loading, setLoading] = useState<boolean>(true);

  // Active Task Execution Modal state
  const [activeTask, setActiveTask] = useState<Task | null>(null);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [phase, setPhase] = useState<'idle' | 'ad_countdown' | 'in_progress' | 'claiming' | 'completed'>('idle');
  const [adSecondsRemaining, setAdSecondsRemaining] = useState<number>(10);
  const [taskSecondsRemaining, setTaskSecondsRemaining] = useState<number>(15);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const fetchTasks = async () => {
    try {
      setLoading(true);
      const res = await api.getTasks();
      if (res.success) {
        setTasks(res.tasks);
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to load tasks', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  // Filter tasks
  const filteredTasks = tasks.filter((t) => {
    if (selectedCategory === 'all') return true;
    return t.category === selectedCategory;
  });

  // Step 1: User clicks "Start Task"
  const handleStartTask = async (task: Task) => {
    try {
      triggerHaptic('medium');
      setErrorMsg(null);
      setActiveTask(task);
      setPhase('ad_countdown');
      setAdSecondsRemaining(task.adCountdownSeconds || 10);
      setTaskSecondsRemaining(task.durationSeconds || 15);

      const res = await api.startTask(task.id);
      if (res.success) {
        setSessionId(res.sessionId);
        setAdSecondsRemaining(res.adCountdownSeconds);
        setTaskSecondsRemaining(res.taskDurationSeconds);
      }
    } catch (err: any) {
      showToast(err.message || 'Could not start task session', 'error');
      closeTaskModal();
    }
  };

  // Ad Countdown Timer (Mandatory 10s)
  useEffect(() => {
    let timer: any = null;
    if (phase === 'ad_countdown' && adSecondsRemaining > 0) {
      timer = setInterval(() => {
        setAdSecondsRemaining((prev) => prev - 1);
      }, 1000);
    } else if (phase === 'ad_countdown' && adSecondsRemaining <= 0 && sessionId) {
      // Confirm ad countdown with backend
      api.confirmAdCountdown(sessionId)
        .then(() => {
          setPhase('in_progress');
          triggerHaptic('success');
        })
        .catch((err) => {
          setErrorMsg(err.message || 'Ad countdown verification failed');
        });
    }
    return () => clearInterval(timer);
  }, [phase, adSecondsRemaining, sessionId, triggerHaptic]);

  // Task Duration Timer
  useEffect(() => {
    let timer: any = null;
    if (phase === 'in_progress' && taskSecondsRemaining > 0) {
      timer = setInterval(() => {
        setTaskSecondsRemaining((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [phase, taskSecondsRemaining]);

  // Early cancel if user closes during ad countdown
  const handleCancelDuringCountdown = () => {
    triggerHaptic('error');
    showToast('Task cancelled: You must finish the 10-second sponsor ad countdown!', 'error');
    closeTaskModal();
  };

  // Step 3: Claim Reward
  const handleClaimReward = async () => {
    if (!sessionId) return;
    try {
      setPhase('claiming');
      triggerHaptic('medium');
      const res = await api.claimTask(sessionId);
      if (res.success) {
        setPhase('completed');
        triggerHaptic('success');
        confetti({
          particleCount: 60,
          spread: 70,
          origin: { y: 0.6 },
        });
        showToast(`Reward Claimed! +৳${res.rewardBdt} BDT`, 'success');
        await refreshUser();
        await fetchTasks();
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to claim task reward');
      setPhase('in_progress');
    }
  };

  const closeTaskModal = () => {
    setActiveTask(null);
    setSessionId(null);
    setPhase('idle');
    setErrorMsg(null);
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-emerald-950/60 to-slate-900 border border-emerald-500/30 rounded-2xl p-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-base font-extrabold text-white flex items-center space-x-1.5">
              <CheckSquare className="w-5 h-5 text-emerald-400" />
              <span>{t.tasksTitle}</span>
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              {language === 'bn'
                ? 'সহজ মাইক্রো-টাস্ক সম্পন্ন করুন এবং সরাসরি ওয়ালেটে টাকা নিন।'
                : 'Complete simple digital tasks and get instant BDT credited to your wallet.'}
            </p>
          </div>
          <div className="text-right">
            <span className="text-[10px] text-slate-400 block font-medium">
              {language === 'bn' ? 'টাস্ক থেকে মোট আয়' : 'Your Task Income'}
            </span>
            <span className="text-sm font-bold text-emerald-400">
              ৳{user ? (user.taskEarnedPoisha / 100).toFixed(2) : '0.00'}
            </span>
          </div>
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-1 scrollbar-none">
        {[
          { id: 'all', label: language === 'bn' ? 'সব টাস্ক' : 'All Tasks' },
          { id: 'youtube', label: 'YouTube' },
          { id: 'telegram', label: 'Telegram' },
          { id: 'facebook', label: 'Facebook' },
          { id: 'visit', label: language === 'bn' ? 'ওয়েব ভিজিট' : 'Web Visit' },
        ].map((cat) => (
          <button
            key={cat.id}
            onClick={() => {
              triggerHaptic('light');
              setSelectedCategory(cat.id);
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
              selectedCategory === cat.id
                ? 'bg-emerald-500 text-slate-950 font-bold shadow-md shadow-emerald-500/20'
                : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Tasks List */}
      {loading ? (
        <div className="py-12 text-center text-slate-500 text-xs">
          {language === 'bn' ? 'টাস্ক লোড হচ্ছে...' : 'Loading available tasks...'}
        </div>
      ) : filteredTasks.length === 0 ? (
        <div className="py-12 text-center text-slate-500 text-xs">
          {language === 'bn' ? 'এই ক্যাটাগরিতে কোনো সক্রিয় টাস্ক নেই।' : 'No active tasks in this category.'}
        </div>
      ) : (
        <div className="space-y-3">
          {filteredTasks.map((task) => {
            const rewardBdt = (task.rewardPoisha / 100).toFixed(2);
            return (
              <div
                key={task.id}
                className="bg-slate-900/90 rounded-2xl border border-slate-800 p-4 hover:border-emerald-500/40 transition shadow-lg"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1 pr-3">
                    <div className="flex items-center space-x-2 mb-1">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-slate-800 text-slate-300 border border-slate-700">
                        {task.category}
                      </span>
                      <span className="text-[10px] text-slate-400 flex items-center space-x-1">
                        <Clock className="w-3 h-3 text-slate-400" />
                        <span>{task.durationSeconds}s {language === 'bn' ? 'সময়' : 'timer'}</span>
                      </span>
                    </div>
                    <h3 className="text-sm font-bold text-white leading-snug">{task.title}</h3>
                    <p className="text-xs text-slate-400 mt-1 line-clamp-2">{task.description}</p>
                  </div>

                  <div className="text-right shrink-0">
                    <div className="text-sm font-black text-emerald-400">৳{rewardBdt}</div>
                    <span className="text-[10px] text-slate-500">BDT</span>
                  </div>
                </div>

                <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between">
                  <div className="text-[11px] text-slate-400">
                    <span className="text-slate-300 font-semibold">{task.completedCount}</span>{' '}
                    {language === 'bn' ? 'জন সম্পন্ন করেছে' : 'completed'}
                  </div>
                  <button
                    onClick={() => handleStartTask(task)}
                    className="flex items-center space-x-1 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs px-3.5 py-1.5 rounded-xl shadow-md shadow-emerald-600/20 active:scale-95 transition"
                  >
                    <span>{language === 'bn' ? 'টাস্ক শুরু করুন' : 'Start Task'}</span>
                    <Play className="w-3 h-3 fill-current" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Task Execution Modal */}
      {activeTask && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl relative overflow-hidden">
            {/* Top Close (allowed with penalty warning during ad countdown) */}
            <button
              onClick={phase === 'ad_countdown' ? handleCancelDuringCountdown : closeTaskModal}
              className="absolute top-4 right-4 p-1 rounded-full bg-slate-800 text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>

            {/* PHASE 1: Mandatory 10-Second Sponsor Ad Countdown */}
            {phase === 'ad_countdown' && (
              <div className="text-center py-2 space-y-4">
                <div className="inline-flex p-3 rounded-2xl bg-amber-950/60 border border-amber-500/40 text-amber-400 animate-pulse">
                  <ShieldAlert className="w-8 h-8" />
                </div>
                <div>
                  <span className="text-[10px] font-extrabold uppercase tracking-widest text-amber-400 px-2 py-0.5 rounded bg-amber-950/80 border border-amber-500/30">
                    {language === 'bn' ? 'স্পন্সর বিজ্ঞাপন যাচাইকরণ' : 'Sponsor Ad Verification'}
                  </span>
                  <h3 className="text-base font-bold text-white mt-2">
                    {language === 'bn' ? '১০ সেকেন্ডের স্পন্সর অ্যাড' : 'Mandatory Ad Countdown'}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">
                    {language === 'bn'
                      ? 'বিজ্ঞাপন শেষ হওয়া পর্যন্ত অপেক্ষা করুন। উইন্ডো বন্ধ করলে টাস্ক বাতিল হয়ে যাবে।'
                      : 'Please hold on while we verify the sponsor link. Closing this modal early will cancel the task.'}
                  </p>
                </div>

                {/* Animated Circular Countdown */}
                <div className="relative w-24 h-24 mx-auto flex items-center justify-center">
                  <div className="absolute inset-0 rounded-full border-4 border-slate-800"></div>
                  <div
                    className="absolute inset-0 rounded-full border-4 border-emerald-400 transition-all duration-1000"
                    style={{
                      clipPath: `polygon(50% 50%, 50% 0%, ${100 - (adSecondsRemaining / (activeTask.adCountdownSeconds || 10)) * 100}% 0%, 100% 100%, 0% 100%)`,
                    }}
                  ></div>
                  <span className="text-3xl font-black text-emerald-400">{adSecondsRemaining}s</span>
                </div>

                <div className="bg-slate-950/70 p-2.5 rounded-xl border border-slate-800 text-[11px] text-slate-300">
                  {language === 'bn'
                    ? '⚠️ কাউন্টডাউন শূন্য হলে স্বয়ংক্রিয়ভাবে মূল টাস্ক চালু হবে।'
                    : '⚠️ Task will automatically unlock once the 10-second timer hits zero.'}
                </div>
              </div>
            )}

            {/* PHASE 2: In Progress Task Execution */}
            {phase === 'in_progress' && (
              <div className="space-y-4 py-2">
                <div className="flex items-center space-x-2">
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-emerald-950 text-emerald-300 border border-emerald-500/30">
                    {activeTask.category}
                  </span>
                  <span className="text-xs font-bold text-emerald-400">
                    {language === 'bn' ? 'রিওয়ার্ড' : 'Reward'}: ৳{(activeTask.rewardPoisha / 100).toFixed(2)} BDT
                  </span>
                </div>

                <div>
                  <h3 className="text-base font-bold text-white">{activeTask.title}</h3>
                  <p className="text-xs text-slate-400 mt-1">{activeTask.instructions}</p>
                </div>

                {/* Action Link Button */}
                <a
                  href={activeTask.targetUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center space-x-2 w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg shadow-blue-600/20 transition"
                >
                  <span>{language === 'bn' ? 'টাস্ক লিংক ওপেন করুন' : 'Open Task Link'}</span>
                  <ExternalLink className="w-4 h-4" />
                </a>

                {/* Task Timer & Claim Button */}
                <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800 text-center space-y-2">
                  <div className="flex items-center justify-center space-x-1.5 text-xs text-slate-300 font-semibold">
                    <Clock className="w-4 h-4 text-emerald-400" />
                    <span>
                      {taskSecondsRemaining > 0
                        ? (language === 'bn' ? `কাজের নির্ধারিত সময় বাকি: ${taskSecondsRemaining} সেকেন্ড` : `Required work timer: ${taskSecondsRemaining}s remaining`)
                        : (language === 'bn' ? 'টাস্ক সময় সম্পন্ন হয়েছে!' : 'Task timer completed!')}
                    </span>
                  </div>

                  <button
                    disabled={taskSecondsRemaining > 0}
                    onClick={handleClaimReward}
                    className={`w-full py-2.5 rounded-xl font-bold text-xs transition ${
                      taskSecondsRemaining > 0
                        ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                        : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-lg shadow-emerald-500/30'
                    }`}
                  >
                    {taskSecondsRemaining > 0
                      ? (language === 'bn' ? `দাবি করতে ${taskSecondsRemaining} সেকেন্ড অপেক্ষা করুন` : `Wait ${taskSecondsRemaining}s to Claim`)
                      : (language === 'bn' ? `ভেরিফাই ও ৳${(activeTask.rewardPoisha / 100).toFixed(2)} BDT ক্লেইম করুন` : `Verify & Claim ৳${(activeTask.rewardPoisha / 100).toFixed(2)} BDT`)}
                  </button>
                </div>

                {errorMsg && (
                  <div className="p-2 rounded-lg bg-rose-950/80 border border-rose-500/40 text-[11px] text-rose-300 flex items-center space-x-1.5">
                    <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                    <span>{errorMsg}</span>
                  </div>
                )}
              </div>
            )}

            {/* PHASE 3: Claiming */}
            {phase === 'claiming' && (
              <div className="py-8 text-center space-y-3">
                <div className="w-12 h-12 rounded-full border-4 border-emerald-500 border-t-transparent animate-spin mx-auto"></div>
                <h4 className="text-sm font-bold text-white">
                  {language === 'bn' ? 'সার্ভারে যাচাই করা হচ্ছে...' : 'Verifying on Server...'}
                </h4>
                <p className="text-xs text-slate-400">
                  {language === 'bn' ? 'ওয়ালেটে টাকা যোগ হচ্ছে।' : 'Crediting BDT to your wallet ledger.'}
                </p>
              </div>
            )}

            {/* PHASE 4: Completed */}
            {phase === 'completed' && (
              <div className="py-6 text-center space-y-3">
                <div className="w-14 h-14 rounded-full bg-emerald-500/20 border border-emerald-500 text-emerald-400 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h4 className="text-base font-extrabold text-white">
                  {language === 'bn' ? 'টাকা সফলভাবে যোগ হয়েছে!' : 'Reward Credited!'}
                </h4>
                <p className="text-xs text-emerald-300">
                  {language === 'bn'
                    ? `৳${(activeTask.rewardPoisha / 100).toFixed(2)} BDT আপনার ব্যালেন্সে যুক্ত করা হয়েছে।`
                    : `৳${(activeTask.rewardPoisha / 100).toFixed(2)} BDT has been credited to your balance.`}
                </p>
                <button
                  onClick={closeTaskModal}
                  className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition mt-2"
                >
                  {language === 'bn' ? 'সম্পন্ন ও টাস্কে ফিরুন' : 'Done & Back to Tasks'}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
