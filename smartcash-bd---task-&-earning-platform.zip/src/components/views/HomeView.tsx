import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Wallet,
  ArrowUpRight,
  Sparkles,
  Users,
  PlaySquare,
  CheckSquare,
  Flame,
  ShieldCheck,
  ChevronRight,
  TrendingUp,
  Gift,
  AlertCircle,
  ExternalLink,
} from 'lucide-react';

export const HomeView: React.FC = () => {
  const { user, settings, setActiveTab, setIsSimulatorOpen, triggerHaptic, t, language } = useApp();

  const balanceBdt = user ? (user.balancePoisha / 100).toFixed(2) : '0.00';
  const lifetimeBdt = user ? (user.totalEarnedPoisha / 100).toFixed(2) : '0.00';
  const pendingBdt = user ? (user.pendingWithdrawPoisha / 100).toFixed(2) : '0.00';
  const refIncomeBdt = user ? (user.referralEarnedPoisha / 100).toFixed(2) : '0.00';

  const recentPayouts = [
    { phone: '018****567', amount: '৳ 100.00', method: 'bKash', time: '৫ মি. আগে' },
    { phone: '017****890', amount: '৳ 250.00', method: 'Nagad', time: '১৪ মি. আগে' },
    { phone: '015****789', amount: '৳ 300.00', method: 'Rocket', time: '২৮ মি. আগে' },
    { phone: '019****321', amount: '৳ 150.00', method: 'bKash', time: '৩৫ মি. আগে' },
    { phone: '016****443', amount: '৳ 50.00', method: 'Nagad', time: '১ ঘণ্টা আগে' },
  ];

  return (
    <div className="space-y-4 pb-20">
      {/* Announcement Marquee */}
      {settings?.announcementText && (
        <div className="bg-gradient-to-r from-emerald-950/70 via-slate-900 to-emerald-950/70 border border-emerald-500/30 rounded-xl p-2.5 flex items-center space-x-2 text-xs text-emerald-300">
          <Flame className="w-4 h-4 text-emerald-400 shrink-0 animate-bounce" />
          <div className="overflow-hidden whitespace-nowrap">
            <span className="inline-block animate-marquee">{settings.announcementText}</span>
          </div>
        </div>
      )}

      {/* Hero Balance Card */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950 border border-emerald-500/40 p-5 shadow-2xl shadow-emerald-950/50">
        <div className="absolute top-0 right-0 -mr-6 -mt-6 w-32 h-32 rounded-full bg-emerald-500/10 blur-2xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 -ml-6 -mb-6 w-32 h-32 rounded-full bg-teal-500/10 blur-2xl pointer-events-none"></div>

        <div className="relative z-10">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center space-x-1">
              <span>{t.mainBalance}</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
            </span>
            <span className="px-2 py-0.5 rounded-full bg-emerald-900/60 border border-emerald-500/30 text-[10px] text-emerald-300 font-bold">
              {language === 'bn' ? 'ভেরিফায়েড অ্যাকাউন্ট' : 'Verified Account'}
            </span>
          </div>

          <div className="flex items-baseline space-x-1.5 my-1">
            <span className="text-3xl font-extrabold text-emerald-400">৳</span>
            <span className="text-4xl font-black tracking-tight text-white">{balanceBdt}</span>
            <span className="text-sm font-bold text-slate-400 ml-1">BDT</span>
          </div>

          <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-slate-800 text-center">
            <div className="bg-slate-950/40 rounded-lg p-1.5 border border-slate-800/60">
              <span className="text-[10px] text-slate-400 block">{t.pendingPayout}</span>
              <span className="text-xs font-bold text-amber-400">৳{pendingBdt}</span>
            </div>
            <div className="bg-slate-950/40 rounded-lg p-1.5 border border-slate-800/60">
              <span className="text-[10px] text-slate-400 block">{t.totalEarned}</span>
              <span className="text-xs font-bold text-emerald-400">৳{lifetimeBdt}</span>
            </div>
            <div className="bg-slate-950/40 rounded-lg p-1.5 border border-slate-800/60">
              <span className="text-[10px] text-slate-400 block">{t.referralIncome}</span>
              <span className="text-xs font-bold text-teal-300">৳{refIncomeBdt}</span>
            </div>
          </div>

          {/* Quick Action Buttons */}
          <div className="grid grid-cols-2 gap-2.5 mt-4">
            <button
              onClick={() => {
                triggerHaptic('medium');
                setActiveTab('wallet');
              }}
              className="flex items-center justify-center space-x-1.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-extrabold text-xs py-2.5 px-3 rounded-xl shadow-lg shadow-emerald-500/25 transition active:scale-95 cursor-pointer"
            >
              <Wallet className="w-4 h-4" />
              <span>{t.withdrawBdt}</span>
            </button>
            <button
              onClick={() => {
                triggerHaptic('light');
                setActiveTab('refer');
              }}
              className="flex items-center justify-center space-x-1.5 bg-slate-800 hover:bg-slate-700/80 text-white font-bold text-xs py-2.5 px-3 rounded-xl border border-slate-700 transition active:scale-95 cursor-pointer"
            >
              <Gift className="w-4 h-4 text-emerald-400" />
              <span>{t.inviteFriends}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Telegram Bot Live Integration Card */}
      <div className="bg-gradient-to-r from-blue-950/50 via-slate-900 to-indigo-950/50 border border-blue-500/30 rounded-2xl p-4">
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-500/30">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center space-x-1.5">
                <span>{t.tgConnected}</span>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              </h3>
              <p className="text-xs text-slate-400">
                Official Bot: <span className="text-blue-400 font-semibold">{settings?.telegramBotUsername || '@smartcashbd_bot'}</span>
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsSimulatorOpen(true)}
            className="text-[11px] font-bold text-blue-400 bg-blue-950 hover:bg-blue-900/80 border border-blue-500/40 px-2.5 py-1.5 rounded-lg transition cursor-pointer"
          >
            Test Bot 🤖
          </button>
        </div>
        <div className="mt-3 text-[11px] text-slate-300 bg-slate-950/50 p-2.5 rounded-lg border border-slate-800">
          ⚡ {t.zeroRegistrationTip}
        </div>
      </div>

      {/* Earn Section Grid */}
      <div>
        <div className="flex items-center justify-between mb-2.5">
          <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wider flex items-center space-x-1.5">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            <span>{t.waysToEarn}</span>
          </h2>
          <span className="text-[11px] text-emerald-400 font-semibold">{t.activeEarnings}</span>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {/* Daily Spin */}
          <div
            onClick={() => setActiveTab('spin')}
            className="bg-slate-900/90 hover:bg-slate-850 p-3.5 rounded-xl border border-slate-800 hover:border-emerald-500/50 cursor-pointer transition group"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="w-8 h-8 rounded-lg bg-emerald-950 text-emerald-400 flex items-center justify-center border border-emerald-500/30 group-hover:scale-110 transition">
                <Sparkles className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-900/50 text-emerald-300">
                Daily Free
              </span>
            </div>
            <h4 className="text-xs font-bold text-white group-hover:text-emerald-400 transition">{t.dailySpinTitle}</h4>
            <p className="text-[10px] text-slate-400 mt-0.5">{t.dailySpinDesc}</p>
          </div>

          {/* Micro Tasks */}
          <div
            onClick={() => setActiveTab('tasks')}
            className="bg-slate-900/90 hover:bg-slate-850 p-3.5 rounded-xl border border-slate-800 hover:border-emerald-500/50 cursor-pointer transition group"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="w-8 h-8 rounded-lg bg-teal-950 text-teal-400 flex items-center justify-center border border-teal-500/30 group-hover:scale-110 transition">
                <CheckSquare className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-teal-900/50 text-teal-300">
                Fast Payout
              </span>
            </div>
            <h4 className="text-xs font-bold text-white group-hover:text-teal-400 transition">{t.tasksTitle}</h4>
            <p className="text-[10px] text-slate-400 mt-0.5">{t.tasksDesc}</p>
          </div>

          {/* Video Ads */}
          <div
            onClick={() => setActiveTab('ads')}
            className="bg-slate-900/90 hover:bg-slate-850 p-3.5 rounded-xl border border-slate-800 hover:border-emerald-500/50 cursor-pointer transition group"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="w-8 h-8 rounded-lg bg-amber-950 text-amber-400 flex items-center justify-center border border-amber-500/30 group-hover:scale-110 transition">
                <PlaySquare className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-900/50 text-amber-300">
                Active
              </span>
            </div>
            <h4 className="text-xs font-bold text-white group-hover:text-amber-400 transition">{t.videoAdsTitle}</h4>
            <p className="text-[10px] text-slate-400 mt-0.5">{t.videoAdsDesc}</p>
          </div>

          {/* Refer & Earn */}
          <div
            onClick={() => setActiveTab('refer')}
            className="bg-slate-900/90 hover:bg-slate-850 p-3.5 rounded-xl border border-slate-800 hover:border-emerald-500/50 cursor-pointer transition group"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="w-8 h-8 rounded-lg bg-purple-950 text-purple-400 flex items-center justify-center border border-purple-500/30 group-hover:scale-110 transition">
                <Users className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-purple-900/50 text-purple-300">
                ৳10 Bonus
              </span>
            </div>
            <h4 className="text-xs font-bold text-white group-hover:text-purple-400 transition">{t.referTitle}</h4>
            <p className="text-[10px] text-slate-400 mt-0.5">{t.referDesc}</p>
          </div>
        </div>
      </div>

      {/* Live Payment Proofs / Ticker */}
      <div className="bg-slate-900/80 rounded-2xl border border-slate-800 p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
              {language === 'bn' ? 'সরাসরি বিকাশ, নগদ ও রকেট পেমেন্ট প্রুফ' : 'Live bKash, Nagad & Rocket Payouts'}
            </h3>
          </div>
          <span className="text-[10px] text-emerald-400 font-semibold">{language === 'bn' ? '১০০% রিয়েল পেমেন্ট' : '100% Real Payouts'}</span>
        </div>

        <div className="space-y-2">
          {recentPayouts.map((p, idx) => (
            <div
              key={idx}
              className="flex items-center justify-between p-2 rounded-lg bg-slate-950/60 border border-slate-800/80 text-xs"
            >
              <div className="flex items-center space-x-2">
                <span
                  className={`px-1.5 py-0.5 rounded text-[10px] font-black ${
                    p.method === 'bKash'
                      ? 'bg-pink-950 text-pink-400 border border-pink-500/30'
                      : p.method === 'Rocket'
                      ? 'bg-purple-950 text-purple-400 border border-purple-500/30'
                      : 'bg-orange-950 text-orange-400 border border-orange-500/30'
                  }`}
                >
                  {p.method}
                </span>
                <span className="font-mono text-slate-300">{p.phone}</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-emerald-400">{p.amount}</span>
                <span className="text-[10px] text-slate-500">{p.time}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
