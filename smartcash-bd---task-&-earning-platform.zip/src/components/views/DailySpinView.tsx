import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { SpinOption } from '../../types';
import confetti from 'canvas-confetti';
import { Sparkles, Disc, Clock, ShieldCheck, Award, AlertCircle } from 'lucide-react';

export const DailySpinView: React.FC = () => {
  const { user, refreshUser, showToast, triggerHaptic, language, t } = useApp();
  const [hasSpunToday, setHasSpunToday] = useState<boolean>(false);
  const [spinOptions, setSpinOptions] = useState<SpinOption[]>([]);
  const [isSpinning, setIsSpinning] = useState<boolean>(false);
  const [rotationAngle, setRotationAngle] = useState<number>(0);
  const [wonOption, setWonOption] = useState<SpinOption | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const fetchSpinStatus = async () => {
    try {
      setLoading(true);
      const res = await api.getSpinStatus();
      if (res.success) {
        setHasSpunToday(res.hasSpunToday);
        setSpinOptions(res.spinOptions);
      }
    } catch (err: any) {
      console.error('Failed to get spin status:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSpinStatus();
  }, []);

  // Draw the wheel onto HTML5 Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || spinOptions.length === 0) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const size = canvas.width;
    const center = size / 2;
    const radius = center - 8;
    const numOptions = spinOptions.length;
    const arcAngle = (2 * Math.PI) / numOptions;

    ctx.clearRect(0, 0, size, size);

    // Draw outer metallic rim
    ctx.beginPath();
    ctx.arc(center, center, radius + 4, 0, 2 * Math.PI);
    ctx.fillStyle = '#0f172a';
    ctx.fill();
    ctx.lineWidth = 4;
    ctx.strokeStyle = '#10B981';
    ctx.stroke();

    // Draw sectors
    for (let i = 0; i < numOptions; i++) {
      const option = spinOptions[i];
      const startAngle = i * arcAngle;
      const endAngle = startAngle + arcAngle;

      ctx.beginPath();
      ctx.moveTo(center, center);
      ctx.arc(center, center, radius, startAngle, endAngle);
      ctx.closePath();

      ctx.fillStyle = option.color || (i % 2 === 0 ? '#059669' : '#1e293b');
      ctx.fill();
      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Draw label text
      ctx.save();
      ctx.translate(center, center);
      ctx.rotate(startAngle + arcAngle / 2);
      ctx.textAlign = 'right';
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 13px Plus Jakarta Sans, sans-serif';
      ctx.fillText(option.label, radius - 20, 5);
      ctx.restore();
    }

    // Draw center pin
    ctx.beginPath();
    ctx.arc(center, center, 22, 0, 2 * Math.PI);
    ctx.fillStyle = '#0f172a';
    ctx.fill();
    ctx.lineWidth = 3;
    ctx.strokeStyle = '#34d399';
    ctx.stroke();

    // Center gold star icon
    ctx.fillStyle = '#fbbf24';
    ctx.font = '16px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('★', center, center);
  }, [spinOptions]);

  // Handle Spin Click
  const handleSpinClick = async () => {
    if (isSpinning || hasSpunToday) return;

    try {
      setIsSpinning(true);
      setWonOption(null);
      triggerHaptic('medium');

      // Call backend RNG
      const res = await api.playSpin();
      if (!res.success) {
        throw new Error('Spin failed on server');
      }

      const winningIndex = spinOptions.findIndex((opt) => opt.id === res.optionId);
      const targetIndex = winningIndex >= 0 ? winningIndex : 0;
      const numOptions = spinOptions.length;
      const sectorDegrees = 360 / numOptions;

      // Pointer is at the top (270 degrees in canvas coordinates)
      // Calculate target angle with 5-7 full spins (1800-2520 degrees)
      const fullRotations = 360 * 6;
      // The needle points at the top (270 deg)
      // Angle to land on center of target sector:
      const targetSectorCenter = (targetIndex * sectorDegrees) + (sectorDegrees / 2);
      const finalAngle = fullRotations + (270 - targetSectorCenter) + (Math.random() * 8 - 4);

      setRotationAngle(finalAngle);

      // Wait for spin animation (4.5s)
      setTimeout(async () => {
        setIsSpinning(false);
        setHasSpunToday(true);
        const awarded = spinOptions[targetIndex];
        setWonOption(awarded);

        if (awarded && awarded.rewardPoisha > 0) {
          triggerHaptic('success');
          confetti({
            particleCount: 80,
            spread: 80,
            origin: { y: 0.6 },
          });
          showToast(
            language === 'bn'
              ? `অভিনন্দন! আপনি জিতেছেন ${awarded.label} BDT!`
              : `Congratulations! You won ${awarded.label} BDT!`,
            'success'
          );
        } else {
          showToast(
            language === 'bn'
              ? 'আজকে ভাগ্য সহায় হয়নি! রাত ১২টায় আবার চেষ্টা করুন।'
              : 'Better luck tomorrow! Resets at midnight.',
            'info'
          );
        }

        await refreshUser();
      }, 4500);
    } catch (err: any) {
      setIsSpinning(false);
      showToast(err.message || (language === 'bn' ? 'স্পিন ব্যর্থ হয়েছে' : 'Spin failed'), 'error');
    }
  };

  const totalSpinEarnedBdt = user ? (user.spinEarnedPoisha / 100).toFixed(2) : '0.00';

  return (
    <div className="space-y-4 pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-emerald-950/60 to-slate-900 border border-emerald-500/30 rounded-2xl p-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-base font-extrabold text-white flex items-center space-x-1.5">
              <Sparkles className="w-5 h-5 text-emerald-400" />
              <span>{t.spinTitle}</span>
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              {language === 'bn'
                ? 'প্রতিদিন একবার ফ্রি স্পিন। রাত ১২:০০ টায় (বাংলাদেশ সময়) নতুন স্পিন আনলক হবে।'
                : 'One free spin every Bangladesh calendar day. Resets at midnight (Dhaka time).'}
            </p>
          </div>
          <div className="text-right">
            <span className="text-[10px] text-slate-400 block font-medium">
              {language === 'bn' ? 'স্পিন থেকে আয়' : 'Spin Earnings'}
            </span>
            <span className="text-sm font-bold text-emerald-400">৳{totalSpinEarnedBdt}</span>
          </div>
        </div>
      </div>

      {/* Wheel Card */}
      <div className="relative bg-slate-900/90 rounded-3xl border border-slate-800 p-6 flex flex-col items-center justify-center shadow-2xl overflow-hidden">
        <div className="absolute top-0 right-0 w-36 h-36 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>

        {/* Top Pointer Indicator */}
        <div className="relative z-20 -mb-4 flex flex-col items-center">
          <div className="w-0 h-0 border-l-[12px] border-l-transparent border-r-[12px] border-r-transparent border-t-[20px] border-t-amber-400 drop-shadow-md"></div>
        </div>

        {/* Canvas Wheel */}
        <div className="relative my-4">
          <canvas
            ref={canvasRef}
            width={300}
            height={300}
            style={{
              transform: `rotate(${rotationAngle}deg)`,
              transition: isSpinning ? 'transform 4.5s cubic-bezier(0.15, 0.9, 0.2, 1)' : 'none',
            }}
            className="rounded-full shadow-2xl drop-shadow-emerald"
          />
        </div>

        {/* Spin Action Button */}
        <div className="w-full max-w-xs mt-3 space-y-2">
          <button
            disabled={isSpinning || hasSpunToday || loading}
            onClick={handleSpinClick}
            className={`w-full py-3.5 rounded-2xl font-extrabold text-sm uppercase tracking-wider flex items-center justify-center space-x-2 transition shadow-xl ${
              hasSpunToday
                ? 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                : isSpinning
                ? 'bg-emerald-600 text-white cursor-wait'
                : 'bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-500 hover:from-emerald-400 hover:to-teal-300 text-slate-950 shadow-emerald-500/25 active:scale-95'
            }`}
          >
            {hasSpunToday ? (
              <>
                <Clock className="w-4 h-4" />
                <span>{t.comeBackTomorrow}</span>
              </>
            ) : isSpinning ? (
              <>
                <Disc className="w-4 h-4 animate-spin" />
                <span>{t.spinning}</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>{t.spinBtn}</span>
              </>
            )}
          </button>

          {hasSpunToday && (
            <div className="text-[11px] text-amber-400/90 text-center bg-amber-950/40 p-2 rounded-xl border border-amber-500/30">
              ⏳ {language === 'bn' ? 'পরবর্তী ফ্রি স্পিন রাত ১২:০০ টায় (বাংলাদেশ সময়) আনলক হবে।' : 'Next free spin activates at 12:00 AM (Asia/Dhaka timezone).'}
            </div>
          )}
        </div>
      </div>

      {/* Reward Summary Table */}
      <div className="bg-slate-900/80 rounded-2xl border border-slate-800 p-4 space-y-3">
        <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center space-x-1.5">
          <Award className="w-4 h-4 text-emerald-400" />
          <span>{language === 'bn' ? 'স্পিন রিওয়ার্ড তালিকা' : 'Wheel Rewards Table'}</span>
        </h3>

        <div className="grid grid-cols-2 gap-2 text-xs">
          {spinOptions.map((opt) => (
            <div
              key={opt.id}
              className="flex items-center justify-between p-2 rounded-xl bg-slate-950/60 border border-slate-800/80"
            >
              <div className="flex items-center space-x-2">
                <span className="w-3 h-3 rounded-full" style={{ backgroundColor: opt.color }}></span>
                <span className="font-bold text-white">{opt.label}</span>
              </div>
              <span className="text-[10px] text-slate-400">
                {opt.probabilityWeight > 20
                  ? (language === 'bn' ? 'সহজ' : 'High')
                  : opt.probabilityWeight > 10
                  ? (language === 'bn' ? 'মাঝারি' : 'Medium')
                  : (language === 'bn' ? 'জ্যাকপট' : 'Rare')}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
