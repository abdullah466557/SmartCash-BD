import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { X, Send, Bot, Check, ArrowRight, Sparkles, ExternalLink } from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  time: string;
  buttons?: any[];
}

export const TelegramSimulatorModal: React.FC = () => {
  const { user, settings, isSimulatorOpen, setIsSimulatorOpen, setActiveTab, showToast, triggerHaptic } = useApp();
  const [inputText, setInputText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const botUsername = settings?.telegramBotUsername || '@smartcashbd_bot';

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg_welcome',
      sender: 'bot',
      text: `👋 Hello! I am the official SmartCash BD Telegram Bot (${botUsername}).\n\nTry sending /start, /balance, /tasks, /refer, /withdraw, or /help to see my live responses!`,
      time: 'Just now',
      buttons: [
        [{ text: '🚀 Open SmartCash BD App', action: 'open_app' }],
        [
          { text: '💰 My Balance', command: '/balance' },
          { text: '👥 Invite & Earn', command: '/refer' },
        ],
      ],
    },
  ]);

  const handleSendCommand = async (textToSend: string) => {
    const trimmed = textToSend.trim();
    if (!trimmed || isProcessing) return;

    triggerHaptic('light');
    const userMsg: ChatMessage = {
      id: 'msg_' + Date.now(),
      sender: 'user',
      text: trimmed,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setIsProcessing(true);

    try {
      const parts = trimmed.split(' ');
      const command = parts[0];
      const startParam = parts[1] || '';

      const res = await api.simulateCommand(
        command,
        {
          id: user?.telegramId || '8801900123',
          first_name: user?.firstName || 'Tanvir',
          last_name: user?.lastName || 'Hasan',
          username: user?.username || 'tanvir_hasan',
        },
        startParam
      );

      if (res.success && res.replyText) {
        triggerHaptic('success');
        const botMsg: ChatMessage = {
          id: 'msg_bot_' + Date.now(),
          sender: 'bot',
          text: res.replyText,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          buttons: res.buttons,
        };
        setMessages((prev) => [...prev, botMsg]);
      }
    } catch (err: any) {
      showToast(err.message || 'Simulation error', 'error');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleButtonAction = (btn: any) => {
    if (btn.command) {
      handleSendCommand(btn.command);
    } else if (btn.web_app || btn.action === 'open_app') {
      setIsSimulatorOpen(false);
      showToast('Opening SmartCash BD Mini App', 'info');
      if (btn.web_app?.url?.includes('#wallet')) {
        setActiveTab('wallet');
      } else if (btn.web_app?.url?.includes('#tasks')) {
        setActiveTab('tasks');
      } else {
        setActiveTab('home');
      }
    } else if (btn.callback_data) {
      if (btn.callback_data === 'cmd_balance') handleSendCommand('/balance');
      else if (btn.callback_data === 'cmd_refer') handleSendCommand('/refer');
      else if (btn.callback_data === 'cmd_tasks') handleSendCommand('/tasks');
      else if (btn.callback_data === 'cmd_withdraw') handleSendCommand('/withdraw');
    } else if (btn.url) {
      window.open(btn.url, '_blank');
    }
  };

  if (!isSimulatorOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/85 backdrop-blur-sm animate-fadeIn">
      <div className="w-full max-w-md h-[580px] bg-slate-900 border border-slate-700 rounded-3xl flex flex-col shadow-2xl overflow-hidden">
        {/* Telegram Header */}
        <div className="bg-slate-850 px-4 py-3 border-b border-slate-700/80 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold shadow-md shadow-blue-500/20">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-1.5">
                <span className="font-bold text-white text-sm">SmartCash BD Bot</span>
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              </div>
              <span className="text-[11px] text-blue-400">{botUsername} • bot</span>
            </div>
          </div>
          <button
            onClick={() => setIsSimulatorOpen(false)}
            className="p-1 rounded-full bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Quick Command Bar */}
        <div className="bg-slate-950 px-3 py-1.5 border-b border-slate-800 flex items-center space-x-1.5 overflow-x-auto scrollbar-none">
          {['/start', '/balance', '/tasks', '/refer', '/withdraw', '/help'].map((cmd) => (
            <button
              key={cmd}
              onClick={() => handleSendCommand(cmd)}
              className="text-[11px] font-mono font-semibold px-2 py-0.5 rounded-md bg-slate-800 hover:bg-slate-750 text-blue-300 whitespace-nowrap transition"
            >
              {cmd}
            </button>
          ))}
          {user?.referralCode && (
            <button
              onClick={() => handleSendCommand(`/start ${user.referralCode}`)}
              className="text-[11px] font-mono font-semibold px-2 py-0.5 rounded-md bg-purple-950 hover:bg-purple-900 text-purple-300 border border-purple-500/30 whitespace-nowrap transition"
              title="Test deep-link registration"
            >
              /start {user.referralCode}
            </button>
          )}
        </div>

        {/* Message Stream */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-gradient-to-b from-slate-900 to-slate-950 text-xs">
          {messages.map((m) => {
            const isBot = m.sender === 'bot';
            return (
              <div key={m.id} className={`flex flex-col ${isBot ? 'items-start' : 'items-end'}`}>
                <div
                  className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 shadow-md leading-relaxed ${
                    isBot
                      ? 'bg-slate-800 text-slate-100 border border-slate-700/80 rounded-tl-sm'
                      : 'bg-blue-600 text-white rounded-tr-sm font-medium'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{m.text}</p>

                  {/* Inline Buttons rendered inside Bot response */}
                  {m.buttons && m.buttons.length > 0 && (
                    <div className="mt-3 pt-2 border-t border-slate-700/80 space-y-1.5">
                      {m.buttons.map((row: any[], rIdx: number) => (
                        <div key={rIdx} className="flex gap-1.5">
                          {row.map((btn: any, bIdx: number) => (
                            <button
                              key={bIdx}
                              onClick={() => handleButtonAction(btn)}
                              className="flex-1 py-1.5 px-2 bg-slate-900/90 hover:bg-blue-950 border border-blue-500/40 rounded-xl text-[11px] font-bold text-blue-300 transition text-center active:scale-95 flex items-center justify-center space-x-1"
                            >
                              <span>{btn.text}</span>
                              {btn.web_app && <ExternalLink className="w-3 h-3 text-blue-400" />}
                            </button>
                          ))}
                        </div>
                      ))}
                    </div>
                  )}

                  <span className="block text-[9px] text-right mt-1 opacity-60">{m.time}</span>
                </div>
              </div>
            );
          })}
          {isProcessing && (
            <div className="flex items-center space-x-1.5 text-slate-400 text-[11px]">
              <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse"></span>
              <span>Bot is typing...</span>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendCommand(inputText);
          }}
          className="p-3 bg-slate-850 border-t border-slate-800 flex items-center space-x-2"
        >
          <input
            type="text"
            placeholder="Type a command (e.g. /balance)..."
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 font-mono"
          />
          <button
            type="submit"
            disabled={!inputText.trim() || isProcessing}
            className="p-2 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white transition"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
