import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/layout/Navbar';
import { BottomNav } from './components/layout/BottomNav';
import { HomeView } from './components/views/HomeView';
import { TasksView } from './components/views/TasksView';
import { ReferView } from './components/views/ReferView';
import { VideoAdsView } from './components/views/VideoAdsView';
import { DailySpinView } from './components/views/DailySpinView';
import { WalletView } from './components/views/WalletView';
import { ProfileView } from './components/views/ProfileView';
import { SupportView } from './components/views/SupportView';
import { TelegramSimulatorModal } from './components/modals/TelegramSimulatorModal';
import { AdminPanelModal } from './components/admin/AdminPanelModal';
import { AlertTriangle, CheckCircle, Info, XCircle } from 'lucide-react';

const MainApp: React.FC = () => {
  const { activeTab, settings, adminUser, toasts, isLoading } = useApp();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-slate-100 p-4">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-slate-950 font-black text-2xl shadow-xl shadow-emerald-500/20 animate-bounce">
          ৳
        </div>
        <h2 className="text-base font-extrabold mt-3 tracking-tight">SmartCash BD</h2>
        <p className="text-xs text-slate-400 mt-1">Connecting Telegram Identity & BDT Wallet...</p>
      </div>
    );
  }

  // Maintenance mode screen
  if (settings?.maintenanceMode && !adminUser) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-slate-100 p-6 text-center">
        <div className="w-16 h-16 rounded-3xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center mb-4 shadow-inner">
          <AlertTriangle className="w-8 h-8" />
        </div>
        <h2 className="text-lg font-black text-white">System Maintenance in Progress</h2>
        <p className="text-xs text-slate-400 mt-1.5 max-w-xs">
          SmartCash BD is upgrading server nodes for faster bKash and Nagad payout processing. Please check back shortly.
        </p>
        <div className="mt-4 text-[11px] text-slate-500">
          Support Telegram: {settings.supportTelegram}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-start">
      {/* Mobile / Telegram Mini App Viewport Container */}
      <div className="w-full max-w-md min-h-screen flex flex-col bg-slate-950 border-x border-slate-900/60 shadow-2xl relative">
        <Navbar />

        <main className="flex-1 px-4 pt-3 overflow-y-auto">
          {activeTab === 'home' && <HomeView />}
          {activeTab === 'tasks' && <TasksView />}
          {activeTab === 'refer' && <ReferView />}
          {activeTab === 'ads' && <VideoAdsView />}
          {activeTab === 'spin' && <DailySpinView />}
          {activeTab === 'wallet' && <WalletView />}
          {activeTab === 'profile' && <ProfileView />}
          {activeTab === 'support' && <SupportView />}
        </main>

        <BottomNav />

        {/* Telegram Bot Chat Simulator Modal */}
        <TelegramSimulatorModal />

        {/* Secure Admin Control Panel Modal */}
        <AdminPanelModal />

        {/* Toast Notifications */}
        <div className="fixed top-18 left-0 right-0 z-50 flex flex-col items-center pointer-events-none space-y-2 px-4">
          {toasts.map((t) => (
            <div
              key={t.id}
              className={`max-w-xs w-full py-2.5 px-3.5 rounded-2xl shadow-xl flex items-center space-x-2.5 text-xs font-semibold backdrop-blur-md pointer-events-auto transition-all animate-fadeIn ${
                t.type === 'success'
                  ? 'bg-emerald-950/90 border border-emerald-500/50 text-emerald-200 shadow-emerald-950/50'
                  : t.type === 'error'
                  ? 'bg-rose-950/90 border border-rose-500/50 text-rose-200 shadow-rose-950/50'
                  : 'bg-slate-900/90 border border-slate-700 text-slate-200 shadow-slate-950/50'
              }`}
            >
              {t.type === 'success' && <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />}
              {t.type === 'error' && <XCircle className="w-4 h-4 text-rose-400 shrink-0" />}
              {t.type === 'info' && <Info className="w-4 h-4 text-blue-400 shrink-0" />}
              <span className="flex-1 leading-tight">{t.message}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainApp />
    </AppProvider>
  );
}
