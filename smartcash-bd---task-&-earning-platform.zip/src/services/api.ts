import { User, AppSettings, Task, Transaction, WithdrawalRequest, SpinOption, AdminStats, AdminAuditLog, VideoAd } from '../types';

let currentTelegramId: string = '';
let currentAdminToken: string = '';

export function setApiTelegramId(telegramId: string) {
  currentTelegramId = telegramId;
}

export function setApiAdminToken(token: string) {
  currentAdminToken = token;
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const headers: Record<string, string> = {
    ...(options.headers as Record<string, string> || {}),
  };

  if (options.body && !headers['Content-Type']) {
    headers['Content-Type'] = 'application/json';
  }

  if (currentTelegramId && !headers['x-telegram-id']) {
    headers['x-telegram-id'] = currentTelegramId;
  }

  if (currentAdminToken && !headers['Authorization']) {
    headers['Authorization'] = `Bearer ${currentAdminToken}`;
  }

  const res = await fetch(endpoint, {
    ...options,
    headers,
  });

  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Network request failed');
  }
  return data as T;
}

export const api = {
  // Telegram & Auth
  authOrRegister: (payload: { initData?: string; mockUser?: any; referralCode?: string }) =>
    request<{ success: boolean; user: User; isNew: boolean; token: string }>('/api/telegram/auth-or-register', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  simulateCommand: (command: string, telegramUser: any, startParam?: string) =>
    request<{ success: boolean; replyText: string; buttons?: any[] }>('/api/telegram/simulate-command', {
      method: 'POST',
      body: JSON.stringify({ command, telegramUser, startParam }),
    }),

  // User & Settings
  getUserMe: () => request<{ success: boolean; user: User }>('/api/user/me'),
  getUserTransactions: () => request<{ success: boolean; transactions: Transaction[] }>('/api/user/transactions'),
  getSettings: () => request<{ success: boolean; settings: AppSettings }>('/api/settings'),

  // Tasks
  getTasks: () => request<{ success: boolean; tasks: Task[] }>('/api/tasks'),
  startTask: (taskId: string) =>
    request<{ success: boolean; sessionId: string; adCountdownSeconds: number; taskDurationSeconds: number }>('/api/tasks/start', {
      method: 'POST',
      body: JSON.stringify({ taskId }),
    }),
  confirmAdCountdown: (sessionId: string) =>
    request<{ success: boolean; message: string }>('/api/tasks/ad-countdown-complete', {
      method: 'POST',
      body: JSON.stringify({ sessionId }),
    }),
  claimTask: (sessionId: string) =>
    request<{ success: boolean; rewardPoisha: number; rewardBdt: string; newBalanceBdt: string }>('/api/tasks/claim', {
      method: 'POST',
      body: JSON.stringify({ sessionId }),
    }),

  // Daily Spin
  getSpinStatus: () => request<{ success: boolean; hasSpunToday: boolean; dhakaToday: string; spinOptions: SpinOption[] }>('/api/spin/status'),
  playSpin: () =>
    request<{ success: boolean; optionId: number; label: string; rewardPoisha: number; rewardBdt: string; newBalanceBdt: string }>('/api/spin/play', {
      method: 'POST',
    }),

  // Video Ads (Provider-neutral, Admin-managed)
  getVideoAds: () =>
    request<{
      success: boolean;
      ads: VideoAd[];
      adsCompletedToday: number;
      dailyLimit: number;
      adRewardPoisha: number;
      cooldownRemainingSeconds: number;
      adsEnabled: boolean;
    }>('/api/video-ads'),
  claimVideoAd: (adId: string) =>
    request<{ success: boolean; rewardPoisha: number; rewardBdt: string; newBalanceBdt: string }>('/api/video-ads/claim', {
      method: 'POST',
      body: JSON.stringify({ adId }),
    }),
  getAdStatus: () =>
    request<{
      success: boolean;
      adsCompletedToday: number;
      dailyLimit: number;
      rewardPoisha: number;
      cooldownRemainingSeconds: number;
      adsEnabled: boolean;
    }>('/api/video-ads'),
  claimAd: (provider?: any) =>
    request<{ success: boolean; rewardPoisha: number; rewardBdt: string; newBalanceBdt: string }>('/api/ads/claim', {
      method: 'POST',
      body: JSON.stringify({ provider: 'Direct' }),
    }),

  // Withdrawals & Referrals
  createWithdrawal: (payload: { method: 'bKash' | 'Nagad' | 'Rocket'; accountType: 'Personal' | 'Merchant'; accountNumber: string; amountBdt: number }) =>
    request<{ success: boolean; withdrawal: WithdrawalRequest; message: string }>('/api/withdrawals/create', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  getMyWithdrawals: () => request<{ success: boolean; withdrawals: WithdrawalRequest[] }>('/api/withdrawals/my'),
  getMyReferrals: () =>
    request<{ success: boolean; referralCode: string; referralsCount: number; referralEarnedPoisha: number; botUsername: string; referrals: any[] }>('/api/referrals/my'),

  // Admin APIs
  adminLogin: (credentials: { username: string; password: string }) =>
    request<{ success: boolean; token: string; admin: { username: string; role: string; lastLoginAt: string } }>('/api/admin/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    }),
  adminGetDashboard: () => request<{ success: boolean; stats: AdminStats }>('/api/admin/dashboard'),
  adminGetUsers: (search?: string) => request<{ success: boolean; users: User[] }>(`/api/admin/users?search=${encodeURIComponent(search || '')}`),
  adminAdjustBalance: (payload: { telegramId: string; amountBdt: number; reason: string; operation: 'credit' | 'debit' }) =>
    request<{ success: boolean; user: User; message: string }>('/api/admin/users/adjust-balance', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  adminToggleBlock: (telegramId: string, reason?: string) =>
    request<{ success: boolean; isBlocked: boolean }>('/api/admin/users/toggle-block', {
      method: 'POST',
      body: JSON.stringify({ telegramId, reason }),
    }),
  adminGetTasks: () => request<{ success: boolean; tasks: Task[] }>('/api/admin/tasks'),
  adminCreateTask: (task: Partial<Task> & { rewardBdt: number }) =>
    request<{ success: boolean; task: Task }>('/api/admin/tasks', {
      method: 'POST',
      body: JSON.stringify(task),
    }),
  adminUpdateTask: (id: string, updates: any) =>
    request<{ success: boolean; task: Task }>(`/api/admin/tasks/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    }),
  adminDeleteTask: (id: string) =>
    request<{ success: boolean; message: string }>(`/api/admin/tasks/${id}`, {
      method: 'DELETE',
    }),
  adminGetVideoAds: () => request<{ success: boolean; ads: VideoAd[] }>('/api/admin/video-ads'),
  adminCreateVideoAd: (ad: { title: string; description?: string; rewardBdt: number; durationSeconds: number; videoUrl?: string; dailyLimit?: number }) =>
    request<{ success: boolean; ad: VideoAd }>('/api/admin/video-ads', {
      method: 'POST',
      body: JSON.stringify(ad),
    }),
  adminUpdateVideoAd: (id: string, updates: any) =>
    request<{ success: boolean; ad: VideoAd }>(`/api/admin/video-ads/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    }),
  adminDeleteVideoAd: (id: string) =>
    request<{ success: boolean; message: string }>(`/api/admin/video-ads/${id}`, {
      method: 'DELETE',
    }),
  adminGetWithdrawals: () => request<{ success: boolean; withdrawals: WithdrawalRequest[] }>('/api/admin/withdrawals'),
  adminActionWithdrawal: (id: string, payload: { action: 'Approve' | 'Paid' | 'Reject'; payoutReference?: string; rejectionReason?: string; adminNote?: string }) =>
    request<{ success: boolean; withdrawal: WithdrawalRequest }>(`/api/admin/withdrawals/${id}/action`, {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  adminGetSettings: () => request<{ success: boolean; settings: AppSettings; spinOptions: SpinOption[] }>('/api/admin/settings'),
  adminUpdateSettings: (payload: { settings?: Partial<AppSettings>; spinOptions?: SpinOption[] }) =>
    request<{ success: boolean; settings: AppSettings; spinOptions: SpinOption[] }>('/api/admin/settings', {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),
  adminGetAuditLogs: () => request<{ success: boolean; logs: AdminAuditLog[] }>('/api/admin/audit-logs'),
  adminRestoreBackup: (backupData: any) =>
    request<{ success: boolean; message: string }>('/api/admin/restore', {
      method: 'POST',
      body: JSON.stringify({ backupData }),
    }),
  adminChangePassword: (payload: { currentPassword: string; newPassword: string }) =>
    request<{ success: boolean; message: string }>('/api/admin/change-password', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  adminChangeCredentials: (payload: { currentPassword: string; newUsername?: string; newPassword?: string }) =>
    request<{ success: boolean; message: string; username?: string }>('/api/admin/change-credentials', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
};
